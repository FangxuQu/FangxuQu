create view ASSETPLANDETAIL_VIEW as
select
  -- ????/????
  v.in_asset_code,
  -- ??????
  'C10847' as pub_org_code,
  -- ??/????
  v.assetdb_type,
  -- ??????
  v.curr_place,
  -- ??
  c.reserve3,
  -- ??????
  case when v.asset_kind = '01' then v.fund_depo_bank else '' end as fund_depo_bank,
  -- ????
  case when v.asset_kind = '01' then v.deposit_amount else 0 end as deposit_amount,
  -- ???
  case when v.asset_kind = '01' then v.value_date else 0 end as value_date,
  -- ???
  case when v.asset_kind = '01' then v.end_date else 0 end as end_date,
  -- ???%
  case when v.asset_kind = '01' then v.rate_year else 0 end as rate_year,
  -- ????
  case when v.asset_kind = '01' then
  (case when v.base_interest = '1' then '02 ACT/360'
  when v.base_interest = '2' then '03 ACT/365'
  when v.base_interest = '3' then '04 ACT/ACT' else v.base_interest end)
  else '' end as base_interest,
  -- ????????
  case when v.asset_kind = '01' then v.is_structure_deposit else '' end as is_structure_deposit,
  -- ???????????
  v.structure_deposit_type as structure_deposit_type,
  -- ?????????
  v.structure_deposit_object as structure_deposit_object,
  -- ??
  case when v.asset_code is null then '' else substr(v.asset_code, 0, instr(v.asset_code, '.', 1, 1) -1) end as asset_code,
  -- ??
  case when v.asset_kind = '02' then v.asset_name else '' end as asset_name,
  -- ????
  v.bond_detail_type as bond_detail_type,
  -- ????
  v.publish_type as publish_type,
  -- ????
  v.body_appraise as body_appraise,
  -- ?????????????
  case when v.asset_kind = '02' then v.scale_type else '' end as scale_type,
  -- ???????????????
  case when v.asset_kind = '02' then v.trade_type else '' end as trade_type,
  -- ???????????????
  case when v.asset_kind = '02' then v.economy_type else '' end as economy_type,
  -- ????????
  case when v.asset_kind = '02' then v.pub_org_detail else '' end as pub_org_detail,
  -- ??????
  v.reg_trust_org as reg_trust_org,
  -- ????????
  v.trustee_org_memo,
  -- ???
  case when v.asset_kind = '03' then v.value_date else 0 end as value_date_1,
  -- ???
  case when v.asset_kind = '03' then v.end_date else 0 end as end_date_1,
  -- ???
  case when v.asset_kind = '03' then v.trans_rival else '' end as trans_riva,
  -- ???%
  case when v.asset_kind = '03' then v.rate_year else 0 end as rate_year_1,
  -- ????
  case when v.asset_kind = '03' then
  (case when v.base_interest = '1' then '02 ACT/360'
  when v.base_interest = '2' then '03 ACT/365'
  when v.base_interest = '3' then '04 ACT/ACT' else v.base_interest end)
  else '' end as base_interest_1,
  -- ??????
  v.hg_asset_type as hg_asset_type,
  -- ??????
  case when v.asset_kind = '03' then v.hg_asset_amount else 0 end as hg_asset_amount,
  -- ?/?????
  v.benefit_right_type as benefit_right_type,
  -- ????????
  case when v.asset_kind = '04' then v.buy_back_flag else '' end as buy_back_flag,
  -- ??
  case when v.asset_kind = '04' then v.asset_name else '' end as asset_name_1,
  -- ??
  case when v.asset_kind = '04' then v.amount else 0 end as amount,
  -- ???
  case when v.asset_kind = '04' then v.value_date else 0 end as value_date_2,
  -- ???
  case when v.asset_kind = '04' then v.end_date else 0 end as end_date_2,
  -- ????
  '' as pro_days,
  -- ????????
  case when v.asset_kind = '04' then v.expect_yield_flag else '' end as expect_yield_flag,
  -- ?????????%
  case when v.asset_kind = '04' then v.interest_rate else 0 end as interest_rate,
  -- ???????/??
  case when v.asset_kind = '04' then v.fx_frequency else '' end as fx_frequency,
  -- ????????
  v.hbfx_explain as hbfx_explain,
  -- ????
  case when v.asset_kind = '04' then
  (case when v.base_interest = '1' then '02 ACT/360'
  when v.base_interest = '2' then '03 ACT/365'
  when v.base_interest = '3' then '04 ACT/ACT' else v.base_interest end)
  else '' end as base_interest_2,
  -- ??????
  v.base_rate_type as base_rate_type,
  -- ?????%?
  case when v.asset_kind = '04' then v.float_factor else 0 end as float_factor,
  -- ??(BP)
  case when v.asset_kind = '04' then v.splot else 0 end as splot,
  -- ???
  case when v.asset_kind = '04' then v.fin_user else '' end as fin_user,
  -- ?????????
  v.borrower_score as borrower_score,
  -- ?????????????????
  case when v.asset_kind = '04' then v.branch_org_out else '' end as branch_org_out,
  -- ????????????
  case when v.asset_kind = '04' then v.scale_type else '' end as scale_type_1,
  -- ??????????????
  case when v.asset_kind = '04' then v.trade_type else '' end as trade_type_1,
  -- ??????????????
  case when v.asset_kind = '04' then v.economy_type else '' end as economy_type_1,
  -- ????
  case when v.asset_kind = '04' then v.fin_project else '' end as fin_project,
  -- ???????
  case when v.asset_kind = '04' then v.guar_detail else '' end as guar_detail,
  -- ???????????????
  case when v.asset_kind = '04' then v.key_mon_tra_flag else '' end as key_mon_tra_flag,
  -- ???????????
  case when v.asset_kind = '04' then v.key_mon_tra_type else '' end as key_mon_tra_type,
  -- ?????????????
  case when v.asset_kind = '04' then v.key_mon_tra_exp else '' end as key_mon_tra_exp,
  -- ????
  v.guar_form as guar_form,
  -- ??????
  case when v.asset_kind = '04' then v.guar_explain else '' end as guar_explain,
  -- ???????
  v.guar_body_score as guar_body_score,
  -- ??????
  v.asset_inner_score as asset_inner_score,
  -- ??????
  v.asset_out_score as asset_out_score,
  -- ???
  v.choose_power as choose_power,
  -- ??????
  v.power_explain as power_explain,
  -- ???????
  v.guar_area as guar_area,
  -- ???????????????
  case when v.asset_kind = '04' then v.guar_org_code else '' end as guar_org_code,
  -- ?????%
  case when v.asset_kind = '04' then v.fin_pro_feerate else 0 end as fin_pro_feerate,
  -- ????????
  case when v.asset_kind = '04' then v.fin_pro_detail else '' end as fin_pro_detail,
  -- ????/???
  v.benefit_right_flag as benefit_right_flag,
  -- ????????
  case when v.asset_kind = '05' then v.buy_back_flag else '' end as buy_back_flag_1,
  -- ??
  v.credit_type as credit_type,
  -- ??
  case when v.asset_kind = '05' then v.publish_amt else 0 end as publish_amt,
  -- ????
  case when v.asset_kind = '05' then v.total_amount else 0 end as total_amount,
  -- ?????????
  case when v.asset_kind = '05' then v.bill_weight_days else 0 end as bill_weight_days,
  -- ?????????
  case when v.asset_kind = '05' then v.bill_most_days else '' end as bill_most_days,
  -- ?????????
  case when v.asset_kind = '05' then v.bill_least_days else '' end as bill_least_days,
  -- ???
  case when v.asset_kind = '05' then v.value_date else 0 end as value_date_3,
  -- ???
  case when v.asset_kind = '05' then v.end_date else 0 end as end_date_3,
  -- ??
  case when v.asset_kind = '05' then v.industry_detail else '' end as industry_detail,
  -- ?????%?
  case when v.asset_kind = '05' then v.cash_rate else 0 end as cash_rate,
  -- ????
  v.stock_code as stock_code,
  -- ??/????
  v.stock_name as stock_name,
  -- ????
  v.stock_type as stock_type,
  -- ??
  v.industry_detail as industry_detail_1,
  -- ????
  case when v.asset_kind = '06' then v.invest_period else '' end as invest_period,
  -- ???????????
  case when v.asset_kind = '06' then v.scale_type else '' end as scale_type_2,
  -- ?????????????
  case when v.asset_kind = '06' then v.trade_type else '' end as trade_type_2,
  -- ?????????????
  case when v.asset_kind = '06' then v.economy_type else '' end as economy_type_2,
  -- ???????
  case when v.asset_kind = '06' then v.pledge_fin_flag else '' end as pledge_fin_flag,
  -- ??
  case when v.asset_kind = '07' then v.asset_name else '' end as asset_name_2,
  -- ????
  case when v.asset_kind = '07' then v.asset_shares else 0 end as asset_shares,
  -- ????
  v.ysp_asset_type as ysp_asset_type,
  -- ???????
  case when v.asset_kind = '08' then v.country_area else '' end as country_area,
  -- ????
  v.bond_name as bond_name,
  -- ????
  v.bond_code as bond_code,
  -- ????
  case when v.asset_kind = '08' then v.issuer_org else '' end as issuer_org,
  -- ????????
  case when v.asset_kind = '08' then v.pub_org_detail else '' end as pub_org_detail_1,
  -- ???
  case when v.asset_kind = '08' then v.value_date else 0 end as value_date_4,
  -- ???
  case when v.asset_kind = '08' then v.end_date else 0 end as end_date_4,
  -- ?????
  v.asset_month as asset_month,
  -- ??????????
  v.org_body_score as org_body_score,
  -- ??????
  v.bond_score_type as bond_score_type,
  -- ????%
  case when v.asset_kind = '08' then v.bill_rate else 0 end as bill_rate,
  -- ???????/??
  case when v.asset_kind = '08' then v.fx_frequency else '' end as fx_frequency_1,
  -- ??????
  case when v.asset_kind = '08' then v.guar_explain else '' end as guar_explain_1,
  -- ?????????????
  v.hq_flag_memo as hq_flag_memo,
  -- ???????
  case when v.asset_kind = '09' then v.country_area else '' end as country_area_1,
  -- ???
  case when v.asset_kind = '09' then v.value_date else 0 end as value_date_5,
  -- ???
  case when v.asset_kind = '09' then v.end_date else 0 end as end_date_5,
  -- ???
  case when v.asset_kind = '09' then v.trans_rival else '' end as trans_rival_1,
  -- ???%
  case when v.asset_kind = '09' then v.rate_year else 0 end as rate_year_2,
  -- ????
  case when v.asset_kind = '09' then
  (case when v.base_interest = '1' then '02 ACT/360'
  when v.base_interest = '2' then '03 ACT/365'
  when v.base_interest = '3' then '04 ACT/ACT' else v.base_interest end)
  else '' end as base_interest_3,
  -- ???????
  case when v.asset_kind = '10' then v.country_area else '' end as country_area_2,
  -- ??/????
  v.bond_fund_code as  bond_fund_code,
  -- ??/????
  v.bond_fund_name as bond_fund_name,
  -- ????
  case when v.asset_kind = '10' then v.issuer_org else '' end as issuer_org_1,
  -- ??
  case when v.asset_kind = '10' then v.industry_detail else '' end as industry_detail_2,
  -- ???????
  case when v.asset_kind = '11' then v.country_area else '' end as country_area_3,
  -- ????
  v.agrement_name as agrement_name,
  -- ???
  case when v.asset_kind = '11' then v.value_date else 0 end as value_date_6,
  -- ???
  case when v.asset_kind = '11' then v.end_date else 0 end as end_date_6,
  -- ????%
  case when v.asset_kind = '11' then v.bill_rate else 0 end as bill_rate_1,
  -- ???????/??
  case when v.asset_kind = '11' then v.fx_frequency else '' end as fx_frequency_2,
  -- ??????????(%)
  case when v.asset_kind = '11' then v.strb_gdsy else 0 end as strb_gdsy,
  -- ??????????(%)
  case when v.asset_kind = '11' then v.strb_ysjr else 0 end as strb_ysjr,
  -- ????????????
  case when v.asset_kind = '11' then v.strb_ysjr_type else '' end as strb_ysjr_type,
  -- ?????????????
  v.strb_ysjr_asset as strb_ysjr_asset,
  -- ??????
  v.fx_mode as fx_mode,
  -- ??????
  v.hq_memo as hq_memo,
  -- ??????????%
  case when v.asset_kind = '11' then v.strb_high_rate else 0 end as strb_high_rate,
  -- ??????????%
  case when v.asset_kind = '11' then v.strb_low_rate else 0 end as strb_low_rate,
  -- ??????????
  case when v.asset_kind = '11' then v.strb_base_price else 0 end as strb_base_price,
  -- ???????????
  case when v.asset_kind = '11' then v.strb_asset_price else 0 end as strb_asset_price,
  -- ???
  v.strb_fee as strb_fee,
  -- ??????
  case when v.asset_kind = '12' then v.intrust_name else '' end as intrust_name,
  -- ???????????
  case when v.asset_kind = '12' then v.intr_pub_org_code else '' end as intr_pub_org_code,
  -- ????????
  case when v.asset_kind = '12' then v.intrust_code else '' end as intrust_code,
  -- ???
  case when v.asset_kind = '12' then v.intrust_manager else '' end as intrust_manager,
  -- ???
  case when v.asset_kind = '12' then v.trustee_org else '' end as trustee_org,
  -- ??
  case when v.asset_kind = '12' then v.amount else 0 end as amount_1,
  -- ??????
  case when v.asset_kind = '12' then v.fund_invest_area else '' end as fund_invest_area,
  -- ??????
  case when v.asset_kind = '12' then v.fund_apply_type else '' end as fund_apply_type,
  -- ??????
  case when v.asset_kind = '12' then v.fund_detail else '' end as fund_detail,
  -- ????????
  case when v.asset_kind = '12' then v.intrust_setdate else 0 end as intrust_setdate,
  -- ????????
  case when v.asset_kind = '12' then v.intrust_enddate else 0 end as intrust_enddate,
  -- ??????
  case when v.asset_kind = '12' then v.intrust_nature else '' end as intrust_nature,
  -- ????????
  case when v.asset_kind = '12' then v.expect_yield_flag else '' end as expect_yield_flag_1,
  -- ???????%
  case when v.asset_kind = '12' then v.high_expected_yield else 0 end as high_expected_yield,
  -- ???????%
  case when v.asset_kind = '12' then v.low_expected_yield else 0 end as low_expected_yield,
  -- ????
  case when v.asset_kind = '12' then v.intr_buy_struct else '' end as intr_buy_struct,
  -- ????
  case when v.asset_kind = '12' then v.intr_manage_style else '' end as intr_manage_style,
  -- ????????????
  case when v.asset_kind = '12' then v.ctr_in_asset_flag else '' end as ctr_in_asset_flag,
  -- ????%
  case when v.asset_kind = '12' then v.manage_fee_rate else '' end as manage_fee_rate,
  -- ????%
  case when v.asset_kind = '12' then v.truship_rate else '' end as truship_rate,
  -- ????????%
  case when v.asset_kind = '12' then v.deal_fee_rate else '' end as deal_fee_rate,
  -- ??????????%
  case when v.asset_kind = '12' then v.serv_org_fee_rate else '' end as serv_org_fee_rate,
  -- ??????%
  case when v.asset_kind = '12' then v.other_fee_rate else '' end as other_fee_rate,
  -- ???????
  case when v.asset_kind = '13' then v.country_area else '' end as country_area_4,
  -- ??
  case when v.asset_kind = '13' then v.asset_name else '' end as asset_name_3,
  -- ?????
  case when v.asset_kind = '13' then v.asset_days else '' end as asset_days,
  -- ????
  case when v.asset_kind = '13' then v.market_price else 0 end as market_price,
  -- ?????%
  case when v.asset_kind = '13' then v.asset_rate else 0 end as asset_rate,
  -- ??
  case when v.asset_kind = '14' then v.asset_name else '' end as asset_name_4,
  -- ??????
  v.bank_asset_type as bank_asset_type,
  -- ????????
  v.asset_type_info as asset_type_info,
  -- ??
    case when v.asset_kind = '14' then v.amount else 0 end as amount_2,
  -- ???
    case when v.asset_kind = '14' then v.value_date else 0 end as value_date_7,
  -- ???
    case when v.asset_kind = '14' then v.end_date else 0 end as end_date_7,
  -- ????
  '' as pro_days_1,
  -- ???????
  case when v.asset_kind = '14' then v.country_area else '' end as country_area_5,
  -- ????????
  case when v.asset_kind = '14' then v.expect_yield_flag else '' end as expect_yield_flag_2,
  -- ?????????%
  case when v.asset_kind = '14' then v.interest_rate else 0 end as interest_rate_1,
  -- ???????/??
  case when v.asset_kind = '14' then v.fx_frequency else '' end as fx_frequency_3,
  -- ???
  case when v.asset_kind = '14' then v.fin_user else '' end as fin_user_1,
  -- ???????????????
  case when v.asset_kind = '14' then v.guar_org_code else '' end as guar_org_code_1,
  -- ?????????????????
  case when v.asset_kind = '14' then v.branch_org_out else '' end as branch_org_out_1,
  -- ????????????
  case when v.asset_kind = '14' then v.scale_type else '' end as scale_type_3,
  -- ??????????????
  case when v.asset_kind = '14' then v.trade_type else '' end as trade_type_3,
  -- ??????????????
  case when v.asset_kind = '14' then v.economy_type else '' end as economy_type_3,
  -- ????
  case when v.asset_kind = '14' then v.fin_project else '' end as fin_project_1,
  -- ???????
  '' as ex,
  -- ????????
  case when v.asset_kind = '14' then v.fin_pro_detail else '' end as fin_pro_detail_1,
  -- ???????????????
  case when v.asset_kind = '14' then v.key_mon_tra_flag else '' end as key_mon_tra_flag_1,
  -- ???????????
  case when v.asset_kind = '14' then v.key_mon_tra_type else '' end as key_mon_tra_type_1,
  -- ?????????????
  case when v.asset_kind = '14' then v.key_mon_tra_exp else '' end as key_mon_tra_exp_1,
  -- ????????
  case when v.asset_kind = '14' then v.dy_out_score else '' end as dy_out_score,
  -- ???????
  case when v.asset_kind = '15' then v.country_area else '' end as country_area_6,
  -- ??
  case when v.asset_kind = '15' then v.asset_name else '' end as asset_name_5,
  -- ???
  case when v.asset_kind = '15' then v.value_date else 0 end as value_date_8,
  -- ???
  case when v.asset_kind = '15' then v.end_date else 0 end as end_date_8,
  -- ????
  case when v.asset_kind = '15' then v.market_price else 0 end as market_price_1,
  -- ?????%
  case when v.asset_kind = '15' then v.asset_rate else 0 end as asset_rate_1,
  -- ????
  v.fund_code as fund_code,
  -- ????
  v.fund_name as fund_name,
  -- ??
  case when v.asset_kind = '15' then v.industry_detail else '' end as industry_detail_3,
  -- ??????
  case when v.asset_kind = '15' then v.public_fund_org else '' end as public_fund_org,
  -- ??????????
  v.indu_invest_fund as indu_invest_fund,
  -- ????????
  v.fund_manager as fund_manager,
  -- ????????
  v.fund_trust_org as fund_trust_org,
  -- ????
  case when v.asset_kind = '16' then v.invest_period else '' end as invest_period_1,
  -- ?????????????
  case when v.asset_kind = '16' then v.scale_type else '' end as scale_type_4,
  -- ???????????????
  case when v.asset_kind = '16' then v.trade_type else '' end as trade_type_4,
  -- ???????????????
  case when v.asset_kind = '16' then v.economy_type else '' end as economy_type_4,
  -- ??????
  v.fund_invest_asset as fund_invest_asset,
  -- ???????
  case when v.asset_kind = '18' then v.country_area else '' end as country_area_7,
  -- ??
  case when v.asset_kind = '18' then v.asset_name else '' end as asset_name_6,
  -- ?????
  case when v.asset_kind = '18' then v.asset_days else '' end as asset_days_1,
  -- ????
  case when v.asset_kind = '18' then v.debt_amount else 0 end as debt_amount,
  -- ??%
  case when v.asset_kind = '18' then v.rate else 0 end as rate,
  -- ?????
  g.init_date as init_date,
  -- ??
  v.memo as memo
from tbassetplandetailview v join tbassetelements e
on v.in_asset_code = e.in_asset_code join tbcurrency c on v.curr_type = c.curr_type
left join tbsysarg g on e.bank_no = g.bank_no
where e.bank_no = '001'
/

