create view AV_ORG_INFO_HB as
select s.cust_no c_org_id, --瀹㈡埛鍙�       s.cust_fullname c_org_name, -- 瀹㈡埛鍚嶇О
       s.taxpayer_reg_no c_nsr_code,-- 绾崇◣浜鸿瘑鍒彿/缁熶竴绀句細淇＄敤浠ｇ爜
       s.taxpayer_address c_address,-- 瀹㈡埛绋庡姟娉ㄥ唽鍦板潃
       s.taxpayer_phone c_tel,--瀹㈡埛绋庡姟娉ㄥ唽鐢佃瘽
       c.bank c_open_bank,--绾崇◣璐︽埛寮€鎴烽摱琛�       c.account c_tax_fund_acc,--绾崇◣璐︽埛閾惰璐﹀彿
       '01' c_nsr_type-- 绾崇◣浜虹被鍨嬨€愮晫闈㈤渶瑕佹坊鍔犳瀛楁01涓€鑸�02灏忚妯°€� from tbsyscustinfo s
 left join tbcustaccountinfo c on c.inter_cust_no = s.inter_cust_no and c.account_attribute = 'b'
/

comment on table AV_ORG_INFO_HB is '璧勭3.0鏈烘瀯淇℃伅瑙嗗浘'
/

comment on column AV_ORG_INFO_HB.C_ORG_ID is '瀹㈡埛鍙'
/

comment on column AV_ORG_INFO_HB.C_ORG_NAME is '瀹㈡埛鍚嶇О'
/

comment on column AV_ORG_INFO_HB.C_NSR_CODE is '绀句細缁熶竴淇＄敤浠ｇ爜'
/

comment on column AV_ORG_INFO_HB.C_ADDRESS is '鍦板潃'
/

comment on column AV_ORG_INFO_HB.C_TEL is '鑱旂郴鐢佃瘽'
/

comment on column AV_ORG_INFO_HB.C_OPEN_BANK is '寮€鎴疯'
/

comment on column AV_ORG_INFO_HB.C_TAX_FUND_ACC is '閾惰璐﹀彿'
/

comment on column AV_ORG_INFO_HB.C_NSR_TYPE is '绾崇◣浜虹被鍨'
/

