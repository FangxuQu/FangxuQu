create view AV_TAX_ASSET_DETAIL_HB as
select t.CAL_DATE D_CAL_DATE,  -- 鏃ユ湡
    t.prd_code C_CODE,  -- 浜у搧浠ｇ爜
    t.asset_code C_ASSET_CODE,  -- 璧勪骇浠ｇ爜
    t.asset_short_name C_ASSET_NAME ,  --  璧勪骇鍚嶇О
    t.CURR_TYPE C_CURRENCY ,  --   甯佺
    case when t.tax_source_type in ('7', '2', '3') then
      '2'
     else
      (case interest_tax_flag
     when '3' then
      '1'
     when '2' then
      '3'
     else
      '4'
    end) end C_TAX_FLAG ,  --  娑夌◣灞炴€�1-搴旂◣鍒╂伅鏀跺叆;2-搴旂◣涔板崠鎹熺泭;3-鍏嶇◣;4-涓嶅緛绋�    case
     when t.tax_source_type in ('7', '2', '3') then
      3.00
     else
      (case interest_tax_flag
     when '3' then
      3.00
     else
      0.00
    end) end F_RATE ,  --  绋庣巼
    case when (t.income_type = '3' and
          t.tax_source_type in ('1', '4', '5', '6')) then
      '2725021000'
     when (t.income_type = '3' and
          t.tax_source_type in ('7', '2', '3')) then
      '2725021000'
     when (t.income_type != '3' and
          t.tax_source_type in ('1', '4', '5', '6')) then
      '2725011000'
     when (t.income_type != '3' and
          t.tax_source_type in ('7', '2', '3')) then
      '2725011000'
     else
      ' '
    end TAX_SUBJECT ,  --   澧炲€肩◣绉戠洰
    case when (t.INTEREST_TAX + t.NET_GAIN_LOSS_TAX + t.AMOR_TAX +
          t.INTEREST_GAIN_TAX) >= 0 then
      'C'
     else
      'D'
    end JD_FLAG ,  --   鍊熻捶:D-鍊�C-璐�F-骞�         t.SHARES ASSET_SHARES ,  --   璧勪骇浠介
         t.BUY_PRICE F_BUY_PRICE ,  --    涔板叆鍗曚环
         t.SELL_PRICE F_SELL_PRICE ,  --    鍗栧嚭鍗曚环
         t.BUY_AMT F_BUY_AMT ,  --    涔板叆浠�         t.SELL_AMT F_SELL_AMT ,  --    鍗栧嚭浠�    case when t.tax_source_type in ('6', '7') then
                  null
                 else
                  (t.INTEREST_TAX_BASE + t.AMOR_TAX_BASE + t.NET_GAIN_LOSS +
                  t.INTEREST_GAIN)
               end F_BASE_AMT ,  --   浠风◣鍒嗙鍓嶉噾棰�         (t.INTEREST_TAX + t.AMOR_TAX + t.NET_GAIN_LOSS_TAX +
               t.INTEREST_GAIN_TAX) F_AMT,  --   绋庨
         1.00000 hl,    -- 鎶樹汉姘戝竵姹囩巼
         (t.INTEREST_TAX + t.AMOR_TAX + t.NET_GAIN_LOSS_TAX +
               t.INTEREST_GAIN_TAX) * 1.00 F_AMT_TORMB,-- 鎶樼畻鍚庣◣棰�    case when t.tax_source_type in ('6', '7') then
                  null
                 else
                  (t.INTEREST_TAX_BASE + t.AMOR_TAX_BASE + t.NET_GAIN_LOSS +
                  t.INTEREST_GAIN) -
                  (t.INTEREST_TAX + t.AMOR_TAX + t.NET_GAIN_LOSS_TAX +
                  t.INTEREST_GAIN_TAX)
               end F_BASE_AMT_SUB,  -- 浠风◣鍒嗙鍚庨噾棰�    case when t.income_type = '3' then
                  '18350203'
              else
                  '18350103'
              end TZ_SUBJECT,  --   璋冩暣绉戠洰
         t.SERIAL_NO C_SERIALNO,  --   娴佹按鍙�         t.SERIAL_NO || '_' || t.TAX_SOURCE_TYPE || '_' || t.CAL_DATE ONLYRN, --   搴忓垪鍙�        '001' C_LEGAL_BANK_CODE --   閾惰缂栧彿
        from av_tax_detail_v2 t
         where t.zh_prd_tax_flag != '2'
           and t.channel_tax_flag != '2'
 order by t.cal_date, t.inter_prd_code
/

comment on table AV_TAX_ASSET_DETAIL_HB is '澧炲€肩◣绾崇◣鏄庣粏琛'
/

comment on column AV_TAX_ASSET_DETAIL_HB.D_CAL_DATE is '鏃ユ湡'
/

comment on column AV_TAX_ASSET_DETAIL_HB.C_CODE is '浜у搧浠ｇ爜'
/

comment on column AV_TAX_ASSET_DETAIL_HB.C_ASSET_CODE is '璧勪骇浠ｇ爜'
/

comment on column AV_TAX_ASSET_DETAIL_HB.C_ASSET_NAME is '璧勪骇鍚嶇О'
/

comment on column AV_TAX_ASSET_DETAIL_HB.C_CURRENCY is '甯佺'
/

comment on column AV_TAX_ASSET_DETAIL_HB.C_TAX_FLAG is '娑夌◣灞炴€�1-搴旂◣鍒╂伅鏀跺叆;2-搴旂◣涔板崠鎹熺泭;3-鍏嶇◣;4-涓嶅緛绋'
/

comment on column AV_TAX_ASSET_DETAIL_HB.F_RATE is '绋庣巼'
/

comment on column AV_TAX_ASSET_DETAIL_HB.TAX_SUBJECT is '澧炲€肩◣绉戠洰'
/

comment on column AV_TAX_ASSET_DETAIL_HB.JD_FLAG is '鍊熻捶:D-鍊�C-璐�F-骞'
/

comment on column AV_TAX_ASSET_DETAIL_HB.ASSET_SHARES is '璧勪骇浠介'
/

comment on column AV_TAX_ASSET_DETAIL_HB.F_BUY_PRICE is '涔板叆鍗曚环'
/

comment on column AV_TAX_ASSET_DETAIL_HB.F_SELL_PRICE is '鍗栧嚭鍗曚环'
/

comment on column AV_TAX_ASSET_DETAIL_HB.F_BUY_AMT is '涔板叆浠'
/

comment on column AV_TAX_ASSET_DETAIL_HB.F_SELL_AMT is '鍗栧嚭浠'
/

comment on column AV_TAX_ASSET_DETAIL_HB.F_BASE_AMT is '浠风◣鍒嗙鍓嶉噾棰'
/

comment on column AV_TAX_ASSET_DETAIL_HB.F_AMT is '绋庨'
/

comment on column AV_TAX_ASSET_DETAIL_HB.HL is '鎶樹汉姘戝竵姹囩巼'
/

comment on column AV_TAX_ASSET_DETAIL_HB.F_AMT_TORMB is '鎶樼畻鍚庣◣棰'
/

comment on column AV_TAX_ASSET_DETAIL_HB.F_BASE_AMT_SUB is '浠风◣鍒嗙鍚庨噾棰'
/

comment on column AV_TAX_ASSET_DETAIL_HB.TZ_SUBJECT is '璋冩暣绉戠洰'
/

comment on column AV_TAX_ASSET_DETAIL_HB.C_SERIALNO is '娴佹按鍙'
/

comment on column AV_TAX_ASSET_DETAIL_HB.ONLYRN is '搴忓垪鍙'
/

comment on column AV_TAX_ASSET_DETAIL_HB.C_LEGAL_BANK_CODE is '閾惰缂栧彿'
/

