create view AV_TAX_DETAIL_V1 as
select case when tax_source_type = '1_1' then '1' when tax_source_type = '2_2' then '1' else tax_rule.interest_tax_flag end interest_tax_flag,
  -- 缁勫悎浜у搧璁＄◣鏍囧織  0琛ㄧず鏅€氫骇鍝佹姇璧�璁＄◣ 1璁＄◣缁勫悎鎶曡祫-璁＄◣ 2琛ㄧず涓嶈绋庣粍鍚堟姇璧�涓嶈绋�涓嶇撼鍏ュ鍊肩◣缁熻
  case when p1.model_flag!='2' then '0' when (p1.model_flag='2' and p1.reserve2='1') then '1' else '2' end zh_prd_tax_flag,
  -- 閫氶亾鎶曡祫璁＄◣鏍囧織 0闈為€氶亾鎶曡祫-璁＄◣ 1璁＄◣閫氶亾鎶曡祫-璁＄◣ 2涓嶈绋庨€氶亾鎶曡祫-涓嶈绋�涓嶇撼鍏ュ鍊肩◣缁熻
  case when (c.inter_prd_code2 = ' ' or p2.reserve2 is null) then '0' when p2.reserve2='1' then '1' else  '2' end channel_tax_flag,
  info.asset_code,info.asset_short_name,
  tax."TAX_SOURCE_TYPE",tax."INTER_PRD_CODE",tax."CAL_DATE",tax."COMBI_NO",tax."ASSET_TYPE",tax."INTER_CODE",tax."LINK_INTER_CODE",tax."INVEST_TYPE",tax."SERIAL_NO",tax."BUSIN_EVENT",tax."INTEREST_TAX_BASE",tax."NET_GAIN_LOSS",tax."INTEREST_TAX",tax."NET_GAIN_LOSS_TAX",tax."INTEREST_TAX_PAYAMT",tax."PRICE_TAX_PAYAMT",tax."SUR_TAX_PAYAMT" from(
   -- 鍒╂伅鍩烘暟
   select '1' tax_source_type,a.book_code inter_prd_code,a.voucher_date cal_date,case when t.cal_unit = ' ' then a.book_code else t.cal_unit end combi_no,a.asset_type,a.inter_code,case when a.asset_type in ('11','H1','F1','O1') then a.inter_code else a.asset_type end link_inter_code,a.invest_type,a.voucher_serial serial_no,a.busin_event,case when t.direction = 'D' then -1*t.amt else t.amt end interest_tax_base,0 net_gain_loss,0 interest_tax,0 net_gain_loss_tax,0 interest_tax_payamt,0 price_tax_payamt,0 sur_tax_payamt from tblocalentry t left join tblocalvoucher a on a.voucher_serial = t.voucher_serial  where a.voucher_date>=20180101 and (substr(t.subject,0,4) in ('6011','6012') or (substr(t.subject,0,4) in ('6111') and a.busin_event in ('A09','A10'))) and a.busin_event not in ('A96','C01') and a.reserve2 <> 'SKIP'
   union all
   -- 鍒╂伅绋庢敮浠樺弽鍐插熀鏁�   select '1_1' tax_source_type,a.book_code inter_prd_code,a.voucher_date cal_date,case when t.cal_unit = ' ' then a.book_code else t.cal_unit end combi_no,a.asset_type,a.inter_code,case when a.asset_type in ('11','H1','F1','O1') then a.inter_code else a.asset_type end link_inter_code,a.invest_type,a.voucher_serial serial_no,a.busin_event,case when t.direction = 'D' then -1*t.amt else t.amt end interest_tax_base,0 net_gain_loss,0 interest_tax,0 net_gain_loss_tax,0 interest_tax_payamt,0 price_tax_payamt,0 sur_tax_payamt from tblocalentry t left join tblocalvoucher a on a.voucher_serial = t.voucher_serial   where (a.voucher_date>= 20180101
      and ((substr(t.subject, 0, 4) in ('6011', '6012') or substr(t.subject, 0, 6) in ('660101'))
      and (a.busin_event = 'A96' or a.reserve2 = 'SKIP')))
       or( T.voucher_serial IN
          ('2019103120084016665978', '2019103120084016665982') AND T.ENTRY_ID='9')
   union all
   -- 浠峰樊绋庡熀鏁�   select '2' tax_source_type,a.book_code inter_prd_code,a.voucher_date cal_date,case when t.cal_unit = ' ' then a.book_code else t.cal_unit end combi_no,a.asset_type,a.inter_code,case when a.asset_type in ('11','H1','F1','O1') then a.inter_code else a.asset_type end link_inter_code,a.invest_type,a.voucher_serial serial_no,a.busin_event,0 interest_tax_base,case when t.direction = 'D' then -1*t.amt else t.amt end net_gain_loss,0 interest_tax,0 net_gain_loss_tax,0 interest_tax_payamt,0 price_tax_payamt,0 sur_tax_payamt from tblocalentry t left join tblocalvoucher a on a.voucher_serial = t.voucher_serial  where a.voucher_date>=20180101 and substr(t.subject,0,4) = '6111' and a.busin_event not in ('A09','A10','A96','C01') and t.voucher_serial not in  ( '2019103120084016665978','2019103120084016665982') and not exists(select 'x' from tbcaltransflow trans where a.ori_serial_no=trans.serial_no and trans.this_price_tax_flag='0')
   union all
   -- 浠峰樊绋庢敮浠樺弽鍐插熀鏁�   select '2_1' tax_source_type,a.book_code inter_prd_code,a.voucher_date cal_date,case when t.cal_unit = ' ' then a.book_code else t.cal_unit end combi_no,a.asset_type,a.inter_code,case when a.asset_type in ('11','H1','F1','O1') then a.inter_code else a.asset_type end link_inter_code,a.invest_type,a.voucher_serial serial_no,a.busin_event,0 interest_tax_base,case when t.direction = 'D' then -1*t.amt else t.amt end net_gain_loss,0 interest_tax,0 net_gain_loss_tax,0 interest_tax_payamt,0 price_tax_payamt,0 sur_tax_payamt from tblocalentry t left join tblocalvoucher a on a.voucher_serial = t.voucher_serial  where a.voucher_date>=20180101 and (substr(t.subject,0,4) = '6111' or substr(t.subject, 0, 6) in ('660102')) and a.busin_event='A96'
   union all
   -- 浠峰樊绋庝笉寰佺◣鍩烘暟锛堝悎骞跺埌鍒╂伅鏀跺叆涓嶅緛绋庡熀鏁颁腑灞曠ず锛�   select '2_2' tax_source_type,a.book_code inter_prd_code,a.voucher_date cal_date,case when t.cal_unit = ' ' then a.book_code else t.cal_unit end combi_no,a.asset_type,a.inter_code,case when a.asset_type in ('11','H1','F1','O1') then a.inter_code else a.asset_type end link_inter_code,a.invest_type,a.voucher_serial serial_no,a.busin_event,case when t.direction = 'D' then -1*t.amt else t.amt end interest_tax_base,0 net_gain_loss,0 interest_tax,0 net_gain_loss_tax,0 interest_tax_payamt,0 price_tax_payamt,0 sur_tax_payamt from tblocalentry t left join tblocalvoucher a on a.voucher_serial = t.voucher_serial  where a.voucher_date>=20180101 and substr(t.subject,0,4) = '6111' and a.busin_event not in ('A09','A10','A96','C01') and t.voucher_serial not in  ( '2019103120084016665978','2019103120084016665982') and exists(select 'x' from tbcaltransflow trans where a.ori_serial_no=trans.serial_no and trans.this_price_tax_flag='0')
   union all
   -- 搴旂即鍒╂伅绋�   select '3' tax_source_type,a.book_code inter_prd_code,a.voucher_date cal_date,case when t.cal_unit = ' ' then a.book_code else t.cal_unit end combi_no,a.asset_type,a.inter_code,case when a.asset_type in ('11','H1','F1','O1') then a.inter_code else a.asset_type end link_inter_code,a.invest_type,a.voucher_serial serial_no,a.busin_event,0 interest_tax_base,0 net_gain_loss,case when t.direction = 'D' then -1*t.amt else t.amt end interest_tax,0 net_gain_loss_tax,0 interest_tax_payamt,0 price_tax_payamt,0 sur_tax_payamt from tblocalentry t left join tblocalvoucher a on a.voucher_serial = t.voucher_serial  where a.voucher_date>=20180101 and t.subject = '23010101' and a.busin_event<>'A96'
   union all
   -- 搴旂即浠峰樊绋�   select '4' tax_source_type,a.book_code inter_prd_code,a.voucher_date cal_date,case when t.cal_unit = ' ' then a.book_code else t.cal_unit end combi_no,a.asset_type,a.inter_code,case when a.asset_type in ('11','H1','F1','O1') then a.inter_code else a.asset_type end link_inter_code,a.invest_type,a.voucher_serial serial_no,a.busin_event,0 interest_tax_base,0 net_gain_loss,0 interest_tax,case when t.direction = 'D' then -1*t.amt else t.amt end net_gain_loss_tax,0 interest_tax_payamt,0 price_tax_payamt,0 sur_tax_payamt from tblocalentry t left join tblocalvoucher a on a.voucher_serial = t.voucher_serial  where a.voucher_date>=20180101 and t.subject = '23010201' and a.busin_event<>'A96'
  ) tax
   left join
  (
  select '11' asset_type,t.inter_code,t.interest_tax_flag from tbbondproperty t
  union all
  select 'H1' asset_type,t.inter_code,t.interest_tax_flag from tbassetplan t
  union all
  select 'F1' asset_type,t.inter_code,t.interest_tax_flag from tbfund t
  union all
  select 'O1' asset_type,t.inter_code,t.interest_tax_flag from tbnonstandard t
  union all
  select dim_code asset_type,dim_code inter_code,interest_tax_flag from tbtaxrate where dim_code not in ('F1','O1','H1') and dim_code not like '11%'
  ) tax_rule on tax.asset_type = tax_rule.asset_type and tax.link_inter_code = tax_rule.inter_code
  left join tbproduct p1 on p1.inter_prd_code = tax.inter_prd_code
  left join tbcombi c on tax.combi_no = c.combi_no
  left join tbproduct p2 on c.inter_prd_code2 = p2.inter_prd_code
  left join vassetinfo info on info.inter_code = tax.inter_code
/

