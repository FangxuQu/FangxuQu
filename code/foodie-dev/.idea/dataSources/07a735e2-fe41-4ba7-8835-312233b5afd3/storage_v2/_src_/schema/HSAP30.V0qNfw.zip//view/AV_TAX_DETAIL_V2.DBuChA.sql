create view AV_TAX_DETAIL_V2 as
select tax_rule.interest_tax_flag,
  p1.prd_code,
  -- 1淇濇湰淇濊瘉鏀剁泭绫�2淇濇湰娴姩鏀剁泭绫�3闈炰繚鏈诞鍔ㄦ敹鐩婄被
  p1.income_type,
  -- 缁勫悎浜у搧璁＄◣鏍囧織  0琛ㄧず鏅€氫骇鍝佹姇璧�璁＄◣ 1璁＄◣缁勫悎鎶曡祫-璁＄◣ 2琛ㄧず涓嶈绋庣粍鍚堟姇璧�涓嶈绋�涓嶇撼鍏ュ鍊肩◣缁熻
  case when p1.model_flag!='2' then '0' when (p1.model_flag='2' and p1.reserve2='1') then '1' else '2' end zh_prd_tax_flag,
  -- 閫氶亾鎶曡祫璁＄◣鏍囧織 0闈為€氶亾鎶曡祫-璁＄◣ 1璁＄◣閫氶亾鎶曡祫-璁＄◣ 2涓嶈绋庨€氶亾鎶曡祫-涓嶈绋�涓嶇撼鍏ュ鍊肩◣缁熻
  case when (c.inter_prd_code2 = ' ' or p2.reserve2 is null) then '0' when p2.reserve2='1' then '1' else  '2' end channel_tax_flag,
  va.asset_code,va.asset_short_name,
  tax."TAX_SOURCE_TYPE",tax."SHARES",tax."BUY_PRICE",tax."BUY_AMT",tax."SELL_PRICE",tax."SELL_AMT",tax."CURR_TYPE",tax."INTER_PRD_CODE",tax."CAL_DATE",tax."COMBI_NO",tax."ASSET_TYPE",tax."INTER_CODE",tax."LINK_INTER_CODE",tax."INVEST_TYPE",tax."SERIAL_NO",tax."INTEREST_TAX_BASE",tax."INTEREST_TAX",tax."INTEREST_GAIN",tax."INTEREST_GAIN_TAX",tax."AMOR_TAX_BASE",tax."AMOR_TAX",tax."NET_GAIN_LOSS",tax."NET_GAIN_LOSS_TAX" from (
  -- 鍒╂伅绋� tax_source_type='1'     璐ㄦ娂寮忔鍥炶喘  涔版柇寮忔鍥炶喘 涓哄埄鎭敮鍑猴紝涓嶈鍏ュ湪鍐�  select '1' tax_source_type,p.shares,0 buy_price,0 buy_amt,0 sell_price,0 sell_amt,p.curr_type,p.inter_prd_code,t.cal_date,p.cal_unit combi_no,p.asset_type,p.inter_code,case when p.asset_type in ('11','H1','F1','O1') then p.inter_code else asset_type end link_inter_code,p.invest_type,p.serial_no,t.today_accrued_amt interest_tax_base,t.today_accrued_tax interest_tax,0 interest_gain,0 interest_gain_tax,0 amor_tax_base,0 amor_tax,0 net_gain_loss,0 net_gain_loss_tax  from tbhisassetinterest t left join tbhisassetposition p on t.serial_no = p.serial_no and p.cal_date = t.cal_date where t.today_accrued_amt<>0  and (p.asset_type not in ('31','33') or (p.asset_type in ('31','33') and p.asset_flag = '1' ))
  union all
  select '1' tax_source_type,p.shares,0 buy_price,0 buy_amt,0 sell_price,0 sell_amt,p.curr_type,p.inter_prd_code,t.cal_date,p.cal_unit combi_no,p.asset_type,p.inter_code,case when p.asset_type in ('11','H1','F1','O1') then p.inter_code else asset_type end link_inter_code,p.invest_type,p.serial_no,t.today_accrued_amt interest_tax_base,t.today_accrued_tax interest_tax,0 interest_gain,0 interest_gain_tax,0 amor_tax_base,0 amor_tax,0 net_gain_loss,0 net_gain_loss_tax  from(select a.* from tbassetinterest a,tbsysarg b where a.cal_date=b.init_date) t left join tbassetposition p on t.serial_no = p.serial_no and p.cal_date = t.cal_date where t.today_accrued_amt<>0  and (p.asset_type not in ('31','33') or (p.asset_type in ('31','33') and p.asset_flag = '1' ))
  -- 鎽婇攢绋�tax_source_type='2'
  union all
  select '2' tax_source_type,p.shares,0 buy_price,0 buy_amt,0 sell_price,0 sell_amt,p.curr_type,p.inter_prd_code,t.cal_date,p.cal_unit combi_no,p.asset_type,p.inter_code,case when p.asset_type in ('11','H1','F1','O1') then p.inter_code else asset_type end link_inter_code,p.invest_type,p.serial_no,0 interest_tax_base,0 interest_tax,0 interest_gain,0 interest_gain_tax,-t.today_amor_amt amor_tax_base,t.today_amor_tax amor_tax,0 net_gain_loss,0 net_gain_loss_tax from tbhisassetamor t left join tbhisassetposition p on t.serial_no = p.serial_no and p.cal_date = t.cal_date where t.today_amor_amt<>0
  union all
  select '2' tax_source_type,p.shares,0 buy_price,0 buy_amt,0 sell_price,0 sell_amt,p.curr_type,p.inter_prd_code,t.cal_date,p.cal_unit combi_no,p.asset_type,p.inter_code,case when p.asset_type in ('11','H1','F1','O1') then p.inter_code else asset_type end link_inter_code,p.invest_type,p.serial_no,0 interest_tax_base,0 interest_tax,0 interest_gain,0 interest_gain_tax,-t.today_amor_amt amor_tax_base,t.today_amor_tax amor_tax,0 net_gain_loss,0 net_gain_loss_tax from (select a.* from tbassetamor a,tbsysarg b where a.cal_date=b.init_date) t left join tbassetposition p on t.serial_no = p.serial_no and p.cal_date = t.cal_date where t.today_amor_amt<>0
  union all
  -- 浠峰樊绋�tbcaltransflow tax_source_type='3'
  select '3' tax_source_type,t.shares,round((t.amt-t.interest-t.net_gain_loss)/(t.count/(case when t.busin_type = '11' then 100.00000000 else 1.00000000 end)),8) buy_price,t.amt-t.interest-t.net_gain_loss buy_amt,t.price sell_price,t.amt-t.interest sell_amt,t.curr_type,t.inter_prd_code,t.settle_date cal_date,t.combi_no,t.asset_type,t.inter_code,case when t.asset_type in ('11','H1','F1','O1') then t.inter_code else t.asset_type end link_inter_code,t.invest_type,t.serial_no,0 interest_tax_base,0 interest_tax,0 interest_gain,0 interest_gain_tax,0 amor_tax_base,0 amor_tax,t.net_gain_loss,t.net_gain_loss_tax from tbcaltransflow t where t.net_gain_loss<>0 and t.cal_flag='2' and t.cancel_flag='0' and t.approve_status='3' and t.busin_event in  ('A02','A10','A12', 'A13','A26','A32')
  union all
  -- 鍒╂伅璋冩暣绋�tbcaltransflow tax_source_type='4'  璐ㄦ娂寮忔鍥炶喘  涔版柇寮忔鍥炶喘 涓哄埄鎭敮鍑猴紝涓嶈鍏ュ湪鍐�  select '4' tax_source_type,t.shares,0 buy_price,0 buy_amt,0 sell_price,0 sell_amt,t.curr_type,t.inter_prd_code,t.settle_date cal_date,t.combi_no,t.asset_type,t.inter_code,case when t.asset_type in ('11','H1','F1','O1') then t.inter_code else t.asset_type end link_inter_code,t.invest_type,t.serial_no,0 interest_tax_base,0 interest_tax,t.interest_gain,t.interest_gain_tax,0 amor_tax_base,0 amor_tax,0 net_gain_loss,0 net_gain_loss_tax  from tbcaltransflow t where t.interest_gain<>0  and t.busin_event in ('A02','A10', 'A12', 'A13','A26','A32') and (t.asset_type not in ('31','33') or (t.asset_type in ('31','33') and t.cal_direction = '1' ))
  union all
  -- 鍒╂伅璋冩暣绋�tbcalcashflow tax_source_type='5'  璐ㄦ娂寮忔鍥炶喘  涔版柇寮忔鍥炶喘 涓哄埄鎭敮鍑猴紝涓嶈鍏ュ湪鍐�  select '5' tax_source_type,t.shares,0 buy_price,0 buy_amt,0 sell_price,0 sell_amt,t.curr_type,t.inter_prd_code,t.pay_date cal_date,t.combi_no,t.asset_type,t.inter_code,case when t.asset_type in ('11','H1','F1','O1') then t.inter_code else t.asset_type end link_inter_code,t.invest_type,t.serial_no,0 interest_tax_base,0 interest_tax,t.interest_gain,t.interest_gain_tax,0 amor_tax_base,0 amor_tax,0 net_gain_loss,0 net_gain_loss_tax from tbcalcashflow t where t.interest_gain<>0 and t.busin_event in ('A05', 'A06', 'A07', 'A08', 'A09', 'A30', 'A31') and (t.asset_type not in ('31','33') or (t.asset_type in ('31','33') and t.cal_direction = '1' ))
   union all
  -- 澧炲€肩◣璋冩暣 tbcaltransflow tax_source_type='6'  鍒╂伅璋冩暣  tax_source_type='7'  浠峰樊璋冩暣
  select case t.sub_code when 'l' then '6' else '7' end tax_source_type,null shares,null buy_price,null buy_amt,null sell_price,null sell_amt,t.curr_type,t.inter_prd_code,t.settle_date cal_date,t.combi_no,t.asset_type,t.inter_code,case when t.asset_type in ('11','H1','F1','O1') then t.inter_code else t.asset_type end link_inter_code,t.invest_type,t.serial_no,0 interest_tax_base,0 interest_tax,0 interest_gain, interest_gain_tax,0 amor_tax_base,0 amor_tax,0 net_gain_loss,t.net_gain_loss_tax from tbcaltransflow t where  t.cal_flag='2' and t.cancel_flag='0' and t.approve_status='3' and t.busin_event in  ('A9X','A9Y')
  ) tax left join
  (
  select '11' asset_type,t.inter_code,t.interest_tax_flag from tbbondproperty t
  union all
  select 'H1' asset_type,t.inter_code,t.interest_tax_flag from tbassetplan t
  union all
  select 'F1' asset_type,t.inter_code,t.interest_tax_flag from tbfund t
  union all
  select 'O1' asset_type,t.inter_code,t.interest_tax_flag from tbnonstandard t
  union all
  select dim_code asset_type,dim_code inter_code,interest_tax_flag from tbtaxrate where dim_code not in ('F1','O1','H1') and dim_code not like '11%'
  ) tax_rule on tax.asset_type = tax_rule.asset_type and tax.link_inter_code = tax_rule.inter_code
  left join tbproduct p1 on p1.inter_prd_code = tax.inter_prd_code
  left join tbcombi c on tax.combi_no = c.combi_no
  left join tbproduct p2 on c.inter_prd_code2 = p2.inter_prd_code
  left join vassetinfo va on va.inter_code = tax.inter_code
/

