create view AV_TICKET_OPENING_HB as
select t.pay_date transdate, -- 鏃ユ湡
       '0098' ordid, -- 鏈烘瀯
       s.cust_no publisher,-- 瀹㈡埛鍙�       a.object_code asset_code, -- 鎶曡祫鏍囩殑浠ｇ爜
       t.serial_no transno,-- 娴佹按鍙�       t.amt, -- 閲戦
       round(t.amt/(1+ COALESCE(tax.interest_rate,3.00)/100)*(COALESCE(tax.interest_rate,3.00)/100),2) taxamt, -- 绋庨
       tax.interest_rate rate -- 绋庣巼
  from tbcalcashflow t
  left join tbassetplan a on a.inter_code = t.inter_code
  left join tbsyscustinfo s on a.publisher_code = s.inter_cust_no
  left join tbcombi  p on p.combi_no = t.cal_unit
  left join tbproduct p1 on p1.inter_prd_code = p.inter_prd_code
  left join tbproduct p2 on p2.inter_prd_code = p.inter_prd_code2
  left join tbtaxrate tax on tax.dim_code = t.busin_type
 where t.busin_type = 'H1' -- 璧勭璁″垝璧勪骇
   and t.busin_event in ('A05', 'A08','A09','A10', 'A30') -- A05鍗栧嚭鏀舵伅/A08鏀舵伅/A09鐜伴噾鍒嗙孩/A10绾㈠埄鍐嶆姇/A30琛ュ綍鏀舵伅
   and ((p.inter_prd_code2 = ' 'and (p1.model_flag!='2' or (p1.model_flag='2' and p1.reserve2='1')) )  or  ((p.inter_prd_code2 <> ' 'and p2.reserve2='1') and (p1.model_flag!='2' or (p1.model_flag='2' and p1.reserve2='1')) )) -- 闈為€氶亾 浜у搧鎴栬€呰绋庣粍鍚�鐨勪氦鏄�鎴栬€�璁＄◣閫氶亾 浜у搧鎴栬€呰绋庣粍鍚�鐨勪氦鏄�   and a.is_guaranteed = '1' --  淇濇湰璧勪骇寰佺◣
   and t.cal_flag='2' and t.cancel_flag='0' and t.approve_status='3'
union all
-- 闈炴爣
select t.pay_date transdate, -- 鏃ユ湡
       '0098' ordid, -- 鏈烘瀯
       s.cust_no publisher,-- 瀹㈡埛鍙�       a.object_code asset_code, -- 鎶曡祫鏍囩殑浠ｇ爜
       t.serial_no transno,-- 娴佹按鍙�       t.amt, -- 閲戦
       round(t.amt/(1+ COALESCE(tax.interest_rate,3.00)/100)*(COALESCE(tax.interest_rate,3.00)/100),2) taxamt, -- 绋庨
       COALESCE(tax.interest_rate,3.00) rate -- 绋庣巼
  from tbcalcashflow t
  left join tbnonstandard a on a.inter_code = t.inter_code
  left join tbsyscustinfo s on a.issuer_no = s.inter_cust_no
  left join tbcombi  p on p.combi_no = t.cal_unit
  left join tbproduct p1 on p1.inter_prd_code = p.inter_prd_code
  left join tbproduct p2 on p2.inter_prd_code = p.inter_prd_code2
  left join tbtaxrate tax on tax.dim_code = t.busin_type
 where t.busin_type = 'O1' -- 闈炴爣璧勪骇
   and t.busin_event in ('A05', 'A08','A09','A10', 'A30') -- A05鍗栧嚭鏀舵伅/A08鏀舵伅/A09鐜伴噾鍒嗙孩/A10绾㈠埄鍐嶆姇/A30琛ュ綍鏀舵伅
   and ((p.inter_prd_code2 = ' 'and (p1.model_flag!='2' or (p1.model_flag='2' and p1.reserve2='1')) )  or  ((p.inter_prd_code2 <> ' 'and p2.reserve2='1') and (p1.model_flag!='2' or (p1.model_flag='2' and p1.reserve2='1')) )) -- 闈為€氶亾 浜у搧鎴栬€呰绋庣粍鍚�鐨勪氦鏄�鎴栬€�璁＄◣閫氶亾 浜у搧鎴栬€呰绋庣粍鍚�鐨勪氦鏄�   and a.is_guaranteed = '1' --  淇濇湰璧勪骇寰佺◣
   and t.cal_flag='2' and t.cancel_flag='0' and t.approve_status='3'
union all
-- 鍊哄埜
select t.pay_date transdate, -- 鏃ユ湡
       '0098' ordid, -- 鏈烘瀯
       s.cust_no publisher,-- 瀹㈡埛鍙�       a.bond_code asset_code, -- 鎶曡祫鏍囩殑浠ｇ爜
       t.serial_no transno,-- 娴佹按鍙�       t.amt, -- 閲戦
       round(t.amt/(1+ COALESCE(tax.interest_rate,3.00)/100)*(COALESCE(tax.interest_rate,3.00)/100),2) taxamt, -- 绋庨
       COALESCE(tax.interest_rate,3.00) rate -- 绋庣巼
  from tbcalcashflow t
  left join tbbondproperty a on a.inter_code = t.inter_code
  left join tbbondissure b on a.inter_code = b.inter_code
  left join tbsyscustinfo s on b.issuer_no = s.inter_cust_no
  left join tbcombi  p on p.combi_no = t.cal_unit
  left join tbproduct p1 on p1.inter_prd_code = p.inter_prd_code
  left join tbproduct p2 on p2.inter_prd_code = p.inter_prd_code2
  left join tbtaxrate tax on tax.dim_code = (t.busin_type||'|'||a.stock_type)
 where t.busin_type = '11' -- 鍊哄埜璧勪骇
   and t.busin_event in ('A05', 'A08','A09','A10', 'A30') -- A05鍗栧嚭鏀舵伅/A08鏀舵伅/A09鐜伴噾鍒嗙孩/A10绾㈠埄鍐嶆姇/A30琛ュ綍鏀舵伅
   and ((p.inter_prd_code2 = ' 'and (p1.model_flag!='2' or (p1.model_flag='2' and p1.reserve2='1')) )  or  ((p.inter_prd_code2 <> ' 'and p2.reserve2='1') and (p1.model_flag!='2' or (p1.model_flag='2' and p1.reserve2='1')) )) -- 闈為€氶亾 浜у搧鎴栬€呰绋庣粍鍚�鐨勪氦鏄�鎴栬€�璁＄◣閫氶亾 浜у搧鎴栬€呰绋庣粍鍚�鐨勪氦鏄�   and a.interest_tax_flag = '3' --  寰佺◣鍊哄埜
   and t.cal_flag='2' and t.cancel_flag='0' and t.approve_status='3'
/

