create view COLLECTTOTAL_VIEW as
select
--??????
a.inter_prd_code as inter_prd_code,
--????
a.prd_code as prd_code,
--  ??????
b.bfirs_code as bfirs_code,
--  ???????
n.grnum as grnum,
--  ???????
n.jgnum as jgnum,
-- ????????
0 as fftTotalNum,
--  ???????????
d.financselldetail as financselldetail,
--  ??
curr.reserve3 || ',' || to_char(nvl(c.ipo_share, '0.00'),'FM9999999990.00') || ',' || to_char(nvl((case when a.curr_type = 'CNY' then c.ipo_amount
else c.ipo_amount*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=a.ipo_end_date) and curr_source=a.curr_type and curr_target='CNY')
end), '0.00'),'FM9999999990.00') as curr_type,
--  ??????
case when a.curr_type = 'CNY' then c.ipo_amount
else c.ipo_amount*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=a.ipo_end_date) and curr_source=a.curr_type and curr_target='CNY')
end as mujiamount,
-- ???????
case when a.curr_type = 'CNY' then c.ipo_amount
else c.ipo_amount*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=a.ipo_end_date) and curr_source=a.curr_type and curr_target='CNY')
end as curr_total_amount,
-- ???????
substr(d.financselldetail, (instr(d.financselldetail, ',' ,1 , 2) + 1)) as area_total_amount,
--  ???????????
c.ipo_share as total_ipo_shares,
--  ???????????
case when a.prd_form = '3' then '01 ?' else '02 ?' end as proxy,
--  ?????????
case when a.prd_form = '3' and a.curr_type = 'CNY' then c.ipo_amount
when a.prd_form = '3' and a.curr_type <> 'CNY' then c.ipo_amount*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=a.ipo_end_date) and curr_source=a.curr_type and curr_target='CNY')
else 0.00
end as proxy_amount,
--  ?????
a.ipo_start_date as ipo_start_date,
--  ??
case when param.param_value = '1' then a.prd_code else b.summary end as summary
from tbproduct a
left join tbreportproduct b on (a.inter_prd_code = b.inter_prd_code)
left join (
select d.inter_prd_code,sum(d.p_shares + d.o_shares) ipo_amount,sum(d.p_shares + d.o_shares) ipo_share
from tbprdsharedetail d, tbproduct d2
where d.inter_prd_code = d2.inter_prd_code
and d.trans_type in ('1')
and d.trans_date <= d2.estab_date
group by d.inter_prd_code
) c on (a.inter_prd_code = c.inter_prd_code)
left join (select c.inter_prd_code,replace(replace(TO_CHAR(wm_concat(c.areaamt)),',',';'),'#',',') financselldetail
from (select a.inter_prd_code,
a.area_code || '#' || a.area_name || '#' || round(a.amount,2) areaamt
from (select v2.area_code,v2.area_name,v2.inter_prd_code,sum(v2.amount) amount from (
select v1.area_code, v1.area_name, v1.inter_prd_code,
case when v1.curr_type = 'CNY' then v1.amount
else v1.amount*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=(select p1.ipo_end_date from tbproduct p1 where p1.inter_prd_code = v1.inter_prd_code)) and curr_source=v1.curr_type and curr_target='CNY')
end amount
from (
select  area_code, area_name, inter_prd_code,curr_type, sum(per_sub_amt + inst_sub_amt + ty_sub_amt) amount
from (select case when f.mother_prd_flag = '2' then f.mother_prd_code else f.inter_prd_code end inter_prd_code,r.area_code,r.area_name,r.per_sub_amt,r.inst_sub_amt,r.ty_sub_amt, r.curr_type
from tblcptreportinfo r
join tbproduct f on r.inter_prd_code = f.inter_prd_code  and r.trans_date<=f.income_date
where f.model_flag='0' and f.mother_prd_flag in ('0','2')) l
group by inter_prd_code, area_code, area_name, curr_type) v1 ) v2
group by v2.area_code,v2.area_name,v2.inter_prd_code) a inner join tbproduct b on a.inter_prd_code = b.inter_prd_code
where b.dealing_status = '0' order by b.inter_prd_code) c
group by c.inter_prd_code) d on (a.inter_prd_code = d.inter_prd_code)
left join (select a.inter_prd_code, sum(a.per_count) grnum, sum(a.inst_count+a.ty_count) jgnum
from (select case when f.mother_prd_flag = '2' then f.mother_prd_code else f.inter_prd_code end inter_prd_code,r.per_count,r.inst_count,r.ty_count,r.trans_date
from tblcptreportinfo r
inner join tbproduct f on r.inter_prd_code = f.inter_prd_code  and r.trans_date<=f.income_date
where f.dealing_status ='0' and f.model_flag='0' and f.mother_prd_flag in ('0','2')) a
group by a.inter_prd_code) n on (a.inter_prd_code = n.inter_prd_code)
join tbcurrency curr on a.curr_type = curr.curr_type
left join tbparam param on param.param_id = 'AP_REPORT_REMARK_SHOWTYPE' and param.ta_code ='000000'
where a.dealing_status = '0' and a.model_flag = '0' and a.mother_prd_flag in ('0','1')
and a.report_flag='1' and a.bank_no = '001'
order by a.prd_code
/

