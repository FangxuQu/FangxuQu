create view JBPM4_EXT_HTASK_ as
select
		t.dbid_ as id_,
		t.activity_name_ as activity_name_,
		p.proc_exe_name_ as proc_name_,
		t.create_ as create_,
		t.end_ as end_,
		t.duration_ as duration_,
		t.state_ as state_,
		t.assignee_ as assignee_,
		ext.assignee_name_ as assignee_name_, /*???????*/
		p.deployment_id_ as deployment_id_,
		p.id_ as hsbpm_instance_,
		t.execution_ as execution_id_,
		t.supertask_ as supertask_,
		ext.name_ as name_,
		ext.biz_flow_uuid_ as biz_flow_uuid_,
		p.procdefid_ as procdefid_,
		t.outcome_ as outcome_,
		p.proc_inst_desc_ as proc_inst_desc_,
		ext.extfield1 as taskoutcomeaction,
		ext.extfield2 as nextnodeoperator,
		ext.taskstatus as taskstatus,
		ext.class_ as class_,
		ext.archive_status as archivestatus, /*??????*/
		ext.agent_id_ as agent_id_, /*???id*/
		ext.agent_name_ as agent_name_, /*???name*/
		s.starter_ as starter_,
		s.starter_name_ as starter_name_,
		s.org_id_ as org_id_,
		s.org_name_ as org_name_,
		ext.parent_task_ as parent_task_,
		ext.visible_ as visible_,
		t.priority_ as priority_,
		ext.extfield1 as  action_name_,
		p.state_ as instance_state_ /*????*/
		from jbpm4_hist_procinst p,
		jbpm4_hist_task t,
		jbpm4_ext_hist_task ext,
		jbpm4_ext_start s
		where t.procinst_ = p.dbid_
		and s.dbid_ = p.dbid_
		and ext.dbid_ = t.dbid_
with read only
/

