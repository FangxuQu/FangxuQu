create view JBPM4_EXT_SIGN_TASK_ as
select
    t.dbid_             as id_,
    t.name_             as name_,
    t.descr_            as descr_,
    inst.proc_exe_name_ as proc_name_,
    t.create_           as create_,
    t.state_            as state_,
    t.assignee_         as assignee_,
    inst.deployment_id_ as deployment_id_,
    e.id_               as execution_id_,
    p.userid_           as userid_,
    p.groupid_          as groupid_,
    t.supertask_        as supertask_,
    t.activity_name_    as activity_name_,
    e.procdefid_        as procdefid_,
    t.biz_ref_id_       as biz_flow_uuid_,
    ''                as candidates,
    t.pre_operators_    as lastoperators
from
    jbpm4_task t,
    jbpm4_participation p,
    jbpm4_execution e,
    jbpm4_hist_procinst inst
where
t.procinst_ = e.dbid_
and t.dbid_ = p.task_
and t.assignee_ is null
and e.instance_=inst.dbid_
with read only
/

