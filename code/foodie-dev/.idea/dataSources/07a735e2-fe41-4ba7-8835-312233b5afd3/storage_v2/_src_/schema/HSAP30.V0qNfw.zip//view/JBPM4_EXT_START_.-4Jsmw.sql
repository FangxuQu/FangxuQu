create view JBPM4_EXT_START_ as
select
    starttmp.dbid_,
    starttmp.starter_,
    starttmp.starter_name_,
    starttmp.process_instance_,
    starttmp.state_,
    starttmp.create_,
    starttmp.end_,
    starttmp.org_id_,
    starttmp.org_name_,
    starttmp.proc_name_,
    hisproc.procdefid_,
    hisproc.proc_inst_desc_ as proc_inst_desc,
    starttmp.last_operator_,
    starttmp.last_activity_,
    starttmp.last_outcome_action_,
    starttmp.last_comment_,
    starttmp.last_operate_time_
from
    jbpm4_ext_start starttmp,
    jbpm4_hist_procinst hisproc
where
    starttmp.dbid_ = hisproc.dbid_
with read only
/

