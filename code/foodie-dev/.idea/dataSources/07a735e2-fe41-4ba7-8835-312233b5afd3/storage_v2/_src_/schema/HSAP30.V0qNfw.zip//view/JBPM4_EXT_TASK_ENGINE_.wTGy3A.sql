create view JBPM4_EXT_TASK_ENGINE_ as
select
    t.dbid_  as id_,
    t.class_ as class_,
    /*????*/
    t.name_                     as name_,
    t.descr_                    as descr_,
    hisprocinst.proc_exe_name_  as proc_name_,
    t.create_                   as create_,
    t.state_                    as state_,
    t.assignee_                 as assignee_,
    t.priority_                 as priority_,
    hisprocinst.deployment_id_  as deployment_id_,
    hisprocinst.id_             as execution_id_,
    t.supertask_                as supertask_,
    t.activity_name_            as activity_name_,
    hisprocinst.procdefid_      as procdefid_,
    t.biz_ref_id_               as biz_flow_uuid_,
    ''                          as candidates,
    t.pre_operators_            as lastoperators,
    t.sub_state_                as taskstatus,
    hisprocinst.proc_inst_desc_ as proc_inst_desc_,
    s.starter_                  as starter_,
    s.starter_name_             as starter_name_,
    s.org_id_                   as org_id_,
    s.org_name_                 as org_name_,
    d.process_key_              as processid,
    d.version_                  as version_,
    t.visible_                  as visible_
from
    jbpm4_task t,
    jbpm4_hist_procinst hisprocinst,
    jbpm4_ext_start s, jbpm4_deployment d
where
    t.procinst_ = hisprocinst.dbid_
and s.dbid_=hisprocinst.dbid_
and hisprocinst.deployment_id_=d.dbid_
and hisprocinst.state_ = 'active'
and t.state_ <> 'completed'
with read only
/

