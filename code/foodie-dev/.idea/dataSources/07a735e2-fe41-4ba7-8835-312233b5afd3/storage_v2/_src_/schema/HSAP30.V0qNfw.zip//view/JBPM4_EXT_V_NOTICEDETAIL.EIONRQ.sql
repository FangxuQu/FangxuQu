create view JBPM4_EXT_V_NOTICEDETAIL as
select
    noticereciver.dbid_ as noticedbid,
    notice.msg_sender,
    notice.msg_title,
    notice.msg_content,
    notice.createtime,
    notice.taskid,
    histask.name_ as activity_name,
    notice.process_instance_id,
    notice.process_def_id,
    notice.process_def_name,
    notice.isalive as noticeisalive,
    noticereciver.recivername,
    noticereciver.recivercode,
    noticereciver.reciver_type,
    noticereciver.reciver_type_name,
    noticereciver.group_done_type,
    noticereciver.isalive as recvisalive
from
    jbpm4_ext_notice notice,
    jbpm4_ext_notice_reciver noticereciver,
    jbpm4_ext_hist_task histask
where
    notice.dbid_ = noticereciver.noticedbid
and histask.dbid_= notice.taskid
with read only
/

