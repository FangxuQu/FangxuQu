create view JBPM4_EXT_V_NOTICESTATUS as
select
    noticestatus.dbid_ as noticedbid,
    notice.msg_sender,
    notice.msg_sender_name,
    notice.msg_title,
    notice.msg_content,
    notice.taskid,
    histask.name_ as activity_name,
    notice.process_instance_id,
    notice.process_def_id,
    notice.process_def_name,
    notice.isalive as noticeisalive,
    noticestatus.reciver,
    noticestatus.reciver_name,
    noticestatus.has_read,
    noticestatus.create_time,
    noticestatus.read_time,
    noticestatus.noticemsg,
    noticestatus.isalive as notstaisalive
from
    jbpm4_ext_notice notice,
    jbpm4_ext_notice_status noticestatus,
    jbpm4_ext_hist_task histask
where
    notice.dbid_ = noticestatus.noticedbid
and notice.taskid = histask.dbid_
with read only
/

