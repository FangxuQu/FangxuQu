create view PERSONANDORGEND_VIEW as
select
	-- ??????
	a.inter_prd_code as inter_prd_code,
  --  ??????
  b.bfirs_code as bfirs_code,
  --????
  a.prd_code as prd_code,
  --  ??????????
  a.end_date as balance_date,
  --  ????????????
	coalesce(sf.all_fee,0) amount,
  --  ?????????
  coalesce(z2.amount_customtotal,0)-coalesce(s.redeem_shares_cny,0) as client_income,
  --  ??????????
	case when coalesce(z2.amount_customtotal,0) < 0 then 0 else coalesce(z2.amount_customtotal,0) end as amount_customtotal,
  --  ?????
  case when coalesce(s.redeem_shares,0) <=0 then 0 else s.redeem_shares end as redeem_shares,
  --  ?????????
  case when coalesce(sf.tgfee_bh,0) <=0 then 0 else sf.tgfee_bh end as amountsf7,
  --  ?????????
  case when coalesce(sf.glfee_bh,0) <=0 then 0 else sf.glfee_bh end as amount1,
  --  ???????????
  case when coalesce(sf.sxfee_bh,0) <=0 then 0 else sf.sxfee_bh end as amount4,
  --  ?????????
  coalesce(sf.qtfee_bh,0) amount9,
  --  ??????????
  case when coalesce(sf.tgfee_qt,0) <=0 then 0 else sf.tgfee_qt end as amountof7,
  --  ??????????
  case when coalesce(sf.glfee_qt,0) <=0 then 0 else sf.glfee_qt end as amountof1,
  --  ?????????
  case when coalesce(sf.sxfee_qt,0) <=0 then 0 else sf.sxfee_qt end as amountof4,
  --  ???
  case when coalesce(sf.gwfee,0) <=0 then 0 else sf.gwfee end as amount3,
  --  ??????????
  coalesce(sf.qtfee_qt,0) amountof9,
  --  ?????????
	case when coalesce(c.client_current_income_rate,0) < 0 then 0 else coalesce(c.client_current_income_rate,0) end as client_current_income_rate,
  --  ?????????
	case when coalesce(c.current_income_rate,0) < 0 then 0 else coalesce(c.current_income_rate,0) end as fld_income_rate,
  -- ????1??????2??????
  '1' as data_type
  from tbproduct a
  left join tbreportproduct b on a.inter_prd_code = b.inter_prd_code
  left join tbhisprdincome c on a.inter_prd_code = c.inter_prd_code and c.cal_date = a.end_date and c.trial_flag = '0'
  left join (select n.inter_prd_code,coalesce(n.sum_shshares,0) redeem_shares,case when n.curr_type = 'CNY' then coalesce(n.sum_shshares,0) else coalesce(n.sum_shshares,0)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=(select a.balance_date from tbproduct a where a.inter_prd_code =n.inter_prd_code )) and curr_source=n.curr_type and curr_target='CNY') end as redeem_shares_cny
     from (select sum(shshares) sum_shshares,inter_prd_code,curr_type
       from (select case when trans_type in ('3','4','7') then p_shares + o_shares else 0 end as shshares,inter_prd_code,trans_date,curr_type
          from tbprdsharedetail
         where trans_type in ('3','4','7')) w
         group by inter_prd_code,curr_type) n) s on a.inter_prd_code = s.inter_prd_code
  left join (select w.inter_prd_code,sum(all_fee) all_fee,sum(tgfee_bh) tgfee_bh,sum(glfee_bh) glfee_bh,sum(sxfee_bh) sxfee_bh,sum(qtfee_bh) qtfee_bh,sum(tgfee_qt)tgfee_qt,sum(glfee_qt) glfee_qt,sum(sxfee_qt)sxfee_qt,sum(gwfee) gwfee,sum(qtfee_qt)qtfee_qt from (
     select alias.inter_prd_code,alias.curr_type,alias.balance_date,
      case when alias.curr_type = 'CNY' then sum(alias.all_fee) else sum(alias.all_fee)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as all_fee,
      case when alias.curr_type = 'CNY' then sum(alias.tgfee_bh) else sum(alias.tgfee_bh)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as tgfee_bh,
      case when alias.curr_type = 'CNY' then sum(alias.glfee_bh) else sum(alias.glfee_bh)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as glfee_bh,
      case when alias.curr_type = 'CNY' then sum(alias.sxfee_bh) else sum(alias.sxfee_bh)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as sxfee_bh,
      case when alias.curr_type = 'CNY' then sum(alias.qtfee_bh) else sum(alias.qtfee_bh)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as qtfee_bh,
      case when alias.curr_type = 'CNY' then sum(alias.tgfee_qt) else sum(alias.tgfee_qt)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as tgfee_qt,
      case when alias.curr_type = 'CNY' then sum(alias.glfee_qt) else sum(alias.glfee_qt)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as glfee_qt,
      case when alias.curr_type = 'CNY' then sum(alias.sxfee_qt) else sum(alias.sxfee_qt)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as sxfee_qt,
      case when alias.curr_type = 'CNY' then sum(alias.gwfee) else sum(alias.gwfee)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as gwfee,
      case when alias.curr_type = 'CNY' then sum(alias.qtfee_qt) else sum(alias.qtfee_qt)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as qtfee_qt
      from (
      select c.inter_prd_code,c.cfl_type,c.fee_type,c.pay_ccy curr_type,p.balance_date,
      --  ??????=??????+??????+???????+???????+??????????
      case when c.fee_type in ('b','e','g','h') and (s.cust_type1 = '00' or s.cust_type1 is null) then -c.pay_amt
           when c.fee_type in ('f') and e.trustee_flag <> '4' then -c.pay_amt else 0 end as all_fee,
      --  ??????
      case when c.fee_type in ('f') and e.trustee_flag <> '4' then -c.pay_amt else 0 end as tgfee_bh,
      --  ??????
      case when c.fee_type in ('b') and (s.cust_type1 = '00' or s.cust_type1 is null) then -c.pay_amt
           when c.fee_type in ('h') then -c.pay_amt else  0 end as glfee_bh,
      --  ????????
      case when c.fee_type in ('e') and (s.cust_type1 = '00' or s.cust_type1 is null) then -c.pay_amt else 0 end as sxfee_bh,
      --  ???????
      case when c.fee_type in ('g') and (s.cust_type1 = '00' or s.cust_type1 is null) then -c.pay_amt else 0 end as qtfee_bh,
      --  ???????
      case when c.fee_type in ('f') and e.trustee_flag = '4' then -c.pay_amt else 0  end as tgfee_qt,
      --  ???????
      case when c.fee_type in ('b') and s.cust_type1 <> '00' and s.cust_type1 is not null then -c.pay_amt else 0 end as glfee_qt,
      --  ?????????
      case when c.fee_type in ('e') and s.cust_type1 <> '00' and s.cust_type1 is not null then -c.pay_amt else 0 end as sxfee_qt,
      --  ??????
      case when c.fee_type in ('d') then -c.pay_amt else 0 end as gwfee,
      --  ??????????
      case when c.fee_type in ('g') and s.cust_type1 <> '00' and s.cust_type1 is not null then -c.pay_amt else 0 end as qtfee_qt
      from tbprdcfl c join tbproduct p on c.inter_prd_code = p.inter_prd_code
      left join tbprdtrustee e on p.inter_prd_code = e.inter_prd_code
      left join tbcustaccountinfo a on c.rival_serial_no = a.serial_no
      left join tbsyscustinfo s on a.inter_cust_no = s.inter_cust_no
      where c.busin_event = 'A89' and c.status in ('3') and c.version_no = 0 and c.pay_date <= p.balance_date)alias
     group by alias.inter_prd_code,alias.curr_type,alias.balance_date)w
    group by w.inter_prd_code) sf on a.inter_prd_code = sf.inter_prd_code
  left join (select z3.inter_prd_code,coalesce(sum(z3.amount),0) amount_customtotal from (
              select z1.inter_prd_code, z1.curr_type,
              case when z1.curr_type = 'CNY' then coalesce(sum(z1.amount),0)
                else (coalesce(sum(z1.amount),0)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=(select a.balance_date from tbproduct a where a.inter_prd_code =z1.inter_prd_code )) and curr_source=z1.curr_type and curr_target='CNY')) end amount
              from (select c1.inter_prd_code,c1.pay_ccy curr_type, coalesce(sum(c1.pay_amt),0) amount
              from tbprdcfl c1
             where c1.busin_event = 'A85' and c1.status = '3'
            group by inter_prd_code,pay_ccy
            union all
           select inter_prd_code,curr_type, coalesce(sum(p_amount),0) + coalesce(sum(o_amount),0) amount
          from tbprdsharedetail
         where trans_type in ('3','4','7')
         group by inter_prd_code,curr_type) z1
 group by z1.inter_prd_code,z1.curr_type) z3 group by z3.inter_prd_code) z2 on a.inter_prd_code = z2.inter_prd_code
 where a.status = 'a'
   and a.model_flag = '0'
   and a.reserve1 in ('1','2')
   and a.report_flag='1'
   and a.bank_no = '001'
union all
select
	-- ??????
	a.inter_prd_code as inter_prd_code,
  --  ??????
  b.bfirs_code as bfirs_code,
  --????
  a.prd_code as prd_code,
  --  ???
  a.end_date as balance_date,
  --  ?????????
  coalesce(sf.all_fee,0) amount,
  --  ??????
  coalesce(z2.amount_customtotal,0)-coalesce(s.redeem_shares_cny,0) as client_income,
  --  ??????????
	case when coalesce(z2.amount_customtotal,0) < 0 then 0 else coalesce(z2.amount_customtotal,0) end as amount_customtotal,
  --  ?????
  case when coalesce(s.redeem_shares,0) <=0 then 0 else s.redeem_shares end as redeem_shares,
  --  ?????????
  case when coalesce(sf.tgfee_bh,0) <=0 then 0 else sf.tgfee_bh end as amountsf7,
  --  ?????????
  case when coalesce(sf.glfee_bh,0) <=0 then 0 else sf.glfee_bh end as amount1,
  --  ???????????
  case when coalesce(sf.sxfee_bh,0) <=0 then 0 else sf.sxfee_bh end as amount4,
  --  ?????????
  coalesce(sf.qtfee_bh,0) amount9,
  --  ??????????
  case when coalesce(sf.tgfee_qt,0) <=0 then 0 else sf.tgfee_qt end as amountof7,
  --  ??????????
  case when coalesce(sf.glfee_qt,0) <=0 then 0 else sf.glfee_qt end as amountof1,
  --  ?????????
  case when coalesce(sf.sxfee_qt,0) <=0 then 0 else sf.sxfee_qt end as amountof4,
  --  ???
  case when coalesce(sf.gwfee,0) <=0 then 0 else sf.gwfee end as amount3,
  --  ??????????
  coalesce(sf.qtfee_qt,0) amountof9,
  --  ?????????
	case when coalesce(c.client_current_income_rate,0) < 0 then 0 else coalesce(c.client_current_income_rate,0) end as client_current_income_rate,
  --  ?????????
	case when coalesce(c.current_income_rate,0) < 0 then 0 else coalesce(c.current_income_rate,0) end as fld_income_rate,
  -- ????1??????2??????
  '2' as data_type
  from tbproduct a
  left join tbreportproduct b on a.inter_prd_code = b.inter_prd_code
  left join tbhisprdincome c on a.inter_prd_code = c.inter_prd_code and a.end_date = c.cal_date and c.trial_flag = '0'
  left join (select n.inter_prd_code,coalesce(n.sum_shshares,0) redeem_shares,case when n.curr_type = 'CNY' then coalesce(n.sum_shshares,0) else coalesce(n.sum_shshares,0)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=(select a.balance_date from tbproduct a where a.inter_prd_code =n.inter_prd_code )) and curr_source=n.curr_type and curr_target='CNY') end as redeem_shares_cny
     from (select sum(shshares) sum_shshares,inter_prd_code,curr_type
       from (select case when trans_type in ('3','4','7') then p_shares + o_shares else 0 end as shshares,inter_prd_code,trans_date,curr_type
          from tbprdsharedetail
         where trans_type in ('3','4','7')) w
         group by inter_prd_code,curr_type) n) s on a.inter_prd_code = s.inter_prd_code
  left join (select w.inter_prd_code,sum(all_fee) all_fee,sum(tgfee_bh) tgfee_bh,sum(glfee_bh) glfee_bh,sum(sxfee_bh) sxfee_bh,sum(qtfee_bh) qtfee_bh,sum(tgfee_qt)tgfee_qt,sum(glfee_qt) glfee_qt,sum(sxfee_qt)sxfee_qt,sum(gwfee) gwfee,sum(qtfee_qt)qtfee_qt from (
     select alias.inter_prd_code,alias.curr_type,alias.balance_date,
      case when alias.curr_type = 'CNY' then sum(alias.all_fee) else sum(alias.all_fee)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as all_fee,
      case when alias.curr_type = 'CNY' then sum(alias.tgfee_bh) else sum(alias.tgfee_bh)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as tgfee_bh,
      case when alias.curr_type = 'CNY' then sum(alias.glfee_bh) else sum(alias.glfee_bh)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as glfee_bh,
      case when alias.curr_type = 'CNY' then sum(alias.sxfee_bh) else sum(alias.sxfee_bh)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as sxfee_bh,
      case when alias.curr_type = 'CNY' then sum(alias.qtfee_bh) else sum(alias.qtfee_bh)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as qtfee_bh,
      case when alias.curr_type = 'CNY' then sum(alias.tgfee_qt) else sum(alias.tgfee_qt)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as tgfee_qt,
      case when alias.curr_type = 'CNY' then sum(alias.glfee_qt) else sum(alias.glfee_qt)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as glfee_qt,
      case when alias.curr_type = 'CNY' then sum(alias.sxfee_qt) else sum(alias.sxfee_qt)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as sxfee_qt,
      case when alias.curr_type = 'CNY' then sum(alias.gwfee) else sum(alias.gwfee)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as gwfee,
      case when alias.curr_type = 'CNY' then sum(alias.qtfee_qt) else sum(alias.qtfee_qt)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=alias.balance_date) and curr_source=alias.curr_type and curr_target='CNY') end as qtfee_qt
      from (
      select c.inter_prd_code,c.cfl_type,c.fee_type,c.pay_ccy curr_type,p.balance_date,
      --  ??????=??????+??????+???????+???????+??????????
      case when c.fee_type in ('b','e','g','h') and (s.cust_type1 = '00' or s.cust_type1 is null) then -c.pay_amt
           when c.fee_type in ('f') and e.trustee_flag <> '4' then -c.pay_amt else 0 end as all_fee,
      --  ??????
      case when c.fee_type in ('f') and e.trustee_flag <> '4' then -c.pay_amt else 0 end as tgfee_bh,
      --  ??????
      case when c.fee_type in ('b') and (s.cust_type1 = '00' or s.cust_type1 is null) then -c.pay_amt
           when c.fee_type in ('h') then -c.pay_amt else  0 end as glfee_bh,
      --  ????????
      case when c.fee_type in ('e') and (s.cust_type1 = '00' or s.cust_type1 is null) then -c.pay_amt else 0 end as sxfee_bh,
      --  ???????
      case when c.fee_type in ('g') and (s.cust_type1 = '00' or s.cust_type1 is null) then -c.pay_amt else 0 end as qtfee_bh,
      --  ???????
      case when c.fee_type in ('f') and e.trustee_flag = '4' then -c.pay_amt else 0  end as tgfee_qt,
      --  ???????
      case when c.fee_type in ('b') and s.cust_type1 <> '00' and s.cust_type1 is not null then -c.pay_amt else 0 end as glfee_qt,
      --  ?????????
      case when c.fee_type in ('e') and s.cust_type1 <> '00' and s.cust_type1 is not null then -c.pay_amt else 0 end as sxfee_qt,
      --  ??????
      case when c.fee_type in ('d') then -c.pay_amt else 0 end as gwfee,
      --  ??????????
      case when c.fee_type in ('g') and s.cust_type1 <> '00' and s.cust_type1 is not null then -c.pay_amt else 0 end as qtfee_qt
      from tbprdcfl c join tbproduct p on c.inter_prd_code = p.inter_prd_code
      left join tbprdtrustee e on p.inter_prd_code = e.inter_prd_code
      left join tbcustaccountinfo a on c.rival_serial_no = a.serial_no
      left join tbsyscustinfo s on a.inter_cust_no = s.inter_cust_no
      where c.busin_event = 'A89' and c.status in ('3') and c.version_no = 0 and c.pay_date <= p.balance_date )alias
     group by alias.inter_prd_code,alias.curr_type,alias.balance_date)w
    group by w.inter_prd_code) sf on a.inter_prd_code = sf.inter_prd_code
  left join  (select z3.inter_prd_code,coalesce(sum(z3.amount),0) amount_customtotal from (
              select z1.inter_prd_code, z1.curr_type,
              case when z1.curr_type = 'CNY' then coalesce(sum(z1.amount),0)
                else (coalesce(sum(z1.amount),0)*(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=(select a.balance_date from tbproduct a where a.inter_prd_code =z1.inter_prd_code )) and curr_source=z1.curr_type and curr_target='CNY')) end amount
              from (select c1.inter_prd_code,c1.pay_ccy curr_type, coalesce(sum(c1.pay_amt),0) amount
              from tbprdcfl c1
             where c1.busin_event = 'A85' and c1.status = '3'
            group by inter_prd_code,pay_ccy
            union all
           select inter_prd_code,curr_type, coalesce(sum(p_amount),0) + coalesce(sum(o_amount),0) amount
          from tbprdsharedetail
         where trans_type in ('3', '4','7')
         group by inter_prd_code,curr_type) z1
  group by z1.inter_prd_code,z1.curr_type) z3 group by z3.inter_prd_code) z2 on a.inter_prd_code = z2.inter_prd_code
  where a.status = 'a'
   and a.model_flag = '0'
   and a.reserve1 in ('3','6','7')
   and a.report_flag='1'
   and a.bank_no = '001'
/

