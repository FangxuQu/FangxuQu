create view PERSONPRDPUB_VIEW as
select
      --????
      a.prd_name as prd_name,
      --??????(??????)
      b.bfirs_code as bfirs_code,
      --?????
      a.prd_code as prd_code,
      --??????
      b.issuer_organ_code as issuer_organ_code,
      --???????
      b.approver_name as approver_name,
      --???????
      b.approver_id as approver_id,
      --???????
      b.designer_name as designer_name,
      --???????
       b.designer_id as designer_id,
      --??????
      b.manager_name as manager_name,
      --??????
      b.manager_id as manager_id,
      --???????
      b.liaisons_name as liaisons_name,
      --???????
      b.liaisons_tel as liaisons_tel,
      --???????
      b.liaisons_mobile as liaisons_mobile,
      --???????
      b.liaisons_mail as liaisons_mail,
      --??????
      a.income_type as income_type,
      --????
      b.confer_term_type as confer_term_type,
      --?????
      case when b.invester_type = ' ' then (case when a.reserve1 = '1' then '03' when a.reserve1 = '2' then '05' when a.reserve1 = '3' then '01' when a.reserve1='6' then '02' when a.reserve1='7' then '04' else '' end) else b.invester_type end as invester_type,
      --??????
      b.fund_invest_area as fund_invest_area,
      --?????????????
      b.over_seas as over_seas,
      --????????
      b.busin_service as busin_service,
      --??????
      b.prd_operate_mode as prd_operate_mode,
      --??????
      b.accounting_type as accounting_type,
      --????????
      b.asset_config as asset_config,
      --??????
      b.manage_type as manage_type,
      --???????
      b.fact_manager as fact_manager,
      --??????
      b.makeprice_type asmakeprice_type,
      --??????
      b.invest_type as invest_type,
      --?????????
      b.struct_inasset as struct_inasset,
      --????????
      b.guest_rate_exist_flag as guest_rate_exist_flag,
      --??????????
      b.guess_rate_flag as guess_rate_flag,
      --??????????%
    	case when b.guest_rate_exist_flag='0' then null else round(b.client_max_rate,8) end as  client_max_rate,
      --??????????%
    	case when b.guest_rate_exist_flag='0' then null else round(b.client_min_rate,8) end as  client_min_rate,
      --??????
      b.sell_area as sell_area,
      --??????
      case when s.pfirst_amt is null then 0.0 else s.pfirst_amt end as pfirst_amt,
      --????
      c1.reserve3 as curr_type,
      --??????
      c2.reserve3 as cost_curr_type,
      --??????
      c3.reserve3 as income_curr_type,
      --??????%
      b.poundage_rate as sxfee,
      --????%
      b.trustee_rate as tgfee,
      --  ????????)
      a.ipo_start_date as ipo_start_date,
      --  ????????)
      a.ipo_end_date as ipo_end_date,
      --  ?????????
      case when a.curr_type = 'CNY' then a.collect_scale
      else  a.collect_scale *(select mid_price from tbcurrencyrateview where trans_date=(select max(trans_date) from tbcurrencyrateview where trans_date<=a.ipo_start_date) and curr_source=a.curr_type and curr_target='CNY')
      end as collect_scale,
      --  ????????
      b.jntg_org_name as jntg_org_name,
      --  ????????
      b.jntg_org_id as jntg_org_id,
      --  ????????
      b.jwtg_org_id as jwtg_org_id,
      --  ????????
      b.jwtg_org_name as jwtg_org_name,
      --  ???????
      b.invest_risk as invest_risk,
      --  ??????
      b.risk_grade as risk_grade,
      --  ???????????
      b.ahead_flag as ahead_flag,
      --  ???????
      b.stop_flag as stop_flag,
      --  ????
      b.brand as brand,
      --  ????
      b.prd_no as prd_no,
      --  ????
      b.zzbb_cooperation as zzbb_cooperation,
       --  ??????
      b.cooperation_org as cooperation_org,
       --  ???????
      b.red_speed as red_speed,
      --  ???????
      b.div_speed as div_speed,
      --  ??????
      b.credit_flag as credit_flag,
      --  ????????
      b.credit_org_type as credit_org_type,
      --  ??????
      b.credit_type as credit_type,
      --  ?????????
      b.asset_kind_ratio as asset_kind_ratio,
      --?????
      '' as report_date,
      --??
      b.summary as summary,
      -------------------------??????----------------------------------
      --??????
      a.income_date as income_date,
      --??????
      a.end_date as end_date,
      --????????????
      b.struct_flag as struct_flag,
      --????
      b.struct_type as struct_type,
      --??????????%
      case when  b.guest_rate_exist_flag='0' then null else b.client_averate end client_averate,
      --?????????
      case when (b.interest_brand=' ' or b.interest_brand is null ) then '?' else b.interest_brand end as interest_brand ,
      --  ????
      b.open_mode as open_mode,
      --  ??????
      b.open_period as open_period,
      --  ???????????
      case when (b.open_period != '99' or a.trans_way = '2') then 0 else b.otheropen_day end as otheropen_day,
      -- b.otheropen_day as otheropen_day,
      --  ???????
      b.open_irregular as open_irregular,
      --  ?????????
      case when b.firstopen_bdate = '0' then 0 else b.firstopen_bdate end as firstopen_bdate,
      -- b.firstopen_bdate as firstopen_bdate,
      --  ???????
      b.open_holi_flag as open_holi_flag,
      --  ??????????
      case when a.trans_way = '2' then 0 else b.open_numbers end as open_numbers,
       -- b.open_numbers as open_numbers,
      --  ?????
      b.open_business as open_business,
      --  ???????
      b.open_business_des as open_business_des,
      -- ?????
      a.estab_date as estab_date,
      -- ????1??????2??????
      '1' as data_type
  from tbproduct a
  left join tbreportproduct b on (a.inter_prd_code = b.inter_prd_code)
  left join tbprdsale s on (a.inter_prd_code = s.inter_prd_code)
  join tbcurrency c1 on a.curr_type = c1.curr_type
  join tbcurrency c2 on a.cost_curr_type = c2.curr_type
  join tbcurrency c3 on a.income_curr_type = c3.curr_type
  where a.status <> '3'
    and a.reserve1 in ('1','2')
    and a.model_flag in ('0','s')
    and a.dealing_status = '0'
    and a.report_flag='1'
    and a.bank_no = '001'
union all
    select
      --????
      a.prd_name as prd_name,
      --??????(??????)
      b.bfirs_code as bfirs_code,
      --?????
      a.prd_code as prd_code,
      --??????
      b.issuer_organ_code as issuer_organ_code,
      --  ???????
      b.approver_name as approver_name,
      --  ?????????
      b.approver_id as approver_id,
      --  ???????
      b.designer_name as designer_name,
      --  ?????????
      b.designer_id as designer_id,
      --  ??????
      b.manager_name as manager_name,
      --  ????????
      b.manager_id as manager_id,
      --  ???????
      b.liaisons_name as liaisons_name,
      --  ???????
      b.liaisons_tel as liaisons_tel,
      --  ???????
      b.liaisons_mobile as liaisons_mobile,
      --  ???????
      b.liaisons_mail as liaisons_mail,
      --  ??????
      a.income_type as income_type,
      --  ????
      b.confer_term_type as confer_term_type,
      --  ?????
      case when b.invester_type = ' ' then (case when a.reserve1 = '1' then '03' when a.reserve1 = '2' then '05' when a.reserve1 = '3' then '01' when a.reserve1='6' then '02' when a.reserve1='7' then '04' else '' end) else b.invester_type end as invester_type,
      --  ??????
      b.fund_invest_area as fund_invest_area,
      --  ?????????
      b.over_seas as over_seas,
      --  ????????
      b.busin_service as busin_service,
      --  ??????
      b.prd_operate_mode as prd_operate_mode,
      --  ??????
      b.accounting_type as accounting_type,
      --  ????????
      b.asset_config as asset_config,
      --  ??????
      b.manage_type as manage_type,
      --  ???????
      b.fact_manager as fact_manager,
      --  ??????
      b.makeprice_type as makeprice_type,
      --  ??????
      b.invest_type as invest_type,
      --  ?????????
      b.struct_inasset as struct_inasset,
      --  ????????
      b.guest_rate_exist_flag as guest_rate_exist_flag,
      --  ??????????
      b.guess_rate_flag as guess_rate_flag,
      --  ??????????%
    	case when b.guest_rate_exist_flag='0' then null else b.pub_min_rate end as client_min_rate,
      --  ??????????%
    	case when b.guest_rate_exist_flag='0' then null else b.pub_max_rate end as client_max_rate,
      --  ??????
      b.sell_area as sell_area,
      --  ?????????
      case when a.reserve1 in ('3') then s.pfirst_amt else s.ofirst_amt end as ofirst_amt,
      --  ????
      c1.reserve3 as curr_type,
      --  ??????
      c2.reserve3 as cost_curr_type,
      --  ??????
      c3.reserve3 as income_curr_type,
      --  ??????
      b.poundage_rate sxFee,
      --  ????
      b.trustee_rate as tgFee,
      --  ??????
      a.ipo_start_date as ipo_start_date,
      --  ??????
      a.ipo_end_date as ipo_end_date,
      --  ?????????
      0 as collect_scale,
      --  ????????
      b.jntg_org_name as jntg_org_name,
      --  ????????
      b.jntg_org_id as jntg_org_id,
      --  ????????
      b.jwtg_org_id as jwtg_org_id,
      --  ????????
      b.jwtg_org_name as jwtg_org_name,
      --  ???????
      b.invest_risk as invest_risk,
      --  ??????
      b.risk_grade as risk_grade,
      --  ???????????
      b.ahead_flag as ahead_flag,
      --  ???????
      b.stop_flag as stop_flag,
      --  ????
      b.brand as brand,
      --  ????
      b.prd_no as prd_no,
      --  ????
      b.zzbb_cooperation as zzbb_cooperation,
      --  ??????
      b.cooperation_org as cooperation_org,
      --  ???????
      b.red_speed as red_speed,
      --  ???????
      b.div_speed as div_speed,
      --  ??????
      b.credit_flag as credit_flag,
      --  ????????
      b.credit_org_type as credit_org_type,
      --  ??????
      b.credit_type as credit_type,
      --  ?????????
      b.asset_kind_ratio as asset_kind_ratio,
      --?????
      '' as report_date,
      --??
      b.summary as summary,
      --  ??????
      a.income_date as income_date,
      --  ????????
      a.end_date as end_date,
      --  ????????????
      b.struct_flag as struct_flag,
      --  ????
      b.struct_type as struct_type,
      --  ??????????%
      case when  b.guest_rate_exist_flag='0' then null else b.client_averate end client_averate,
      --  ?????????
      case when (b.interest_brand=' ' or b.interest_brand is null ) then '?' else b.interest_brand end as interest_brand,
      --  ????
      b.open_mode as open_mode,
      --  ??????
      b.open_period as open_period,
      --  ???????????
      case when (b.open_period != '99' or a.trans_way = '2') then 0 else b.otheropen_day end as otheropen_day,
      -- b.otheropen_day as otheropen_day,
      --  ???????
      b.open_irregular as open_irregular,
      --  ?????????
      case when b.firstopen_bdate = '0' then 0 else b.firstopen_bdate end as firstopen_bdate,
      -- b.firstopen_bdate as firstopen_bdate,
      --  ???????
      b.open_holi_flag as open_holi_flag,
      --  ??????????
      case when a.trans_way = '2' then 0 else b.open_numbers end as open_numbers,
      -- b.open_numbers as open_numbers,
      --  ?????
      b.open_business as open_business,
      --  ???????
      b.open_business_des as open_business_des,
       -- ?????
      a.estab_date as estab_date,
       -- ????1??????2??????
      '2' as data_type
       from tbproduct a
      left join tbreportproduct b on (a.inter_prd_code = b.inter_prd_code)
      left join tbprdsale s on (a.inter_prd_code = s.inter_prd_code)
      left join (select c.inter_prd_code, round(c.fee_rate,8) sxFee
                   from tbprdfeerate c where c.fee_type = 'e') m
                   on a.inter_prd_code = m.inter_prd_code
      left join (select d.inter_prd_code, round(d.fee_rate,8) tgFee
                   from tbprdfeerate d where d.fee_type = 'f') n
                   on a.inter_prd_code = n.inter_prd_code
      join tbcurrency c1 on a.curr_type = c1.curr_type
      join tbcurrency c2 on a.cost_curr_type = c2.curr_type
      join tbcurrency c3 on a.income_curr_type = c3.curr_type
      where a.reserve1 in ('3','6','7') and a.dealing_status='0'
         and a.model_flag = '0'
         and a.report_flag='1'
         and a.bank_no = '001'
/

