create view TBBRANCH as
select  branch_path  internal_branch,
   branch_code  branch_no,
   branch_name ,
   short_name ,
   parent_code  up_branch,
   branch_level,
   branch_type branch_kind,
   ' '         branch_trans,
   remark     reserve1,
	 bank_no bank_no
from
   tsys_branch
/

