create view TBCALUNIT as
select a.combi_no as cal_unit,a.inter_prd_code as book_code,a.combi_name as cal_unit_name,
b.branch_no as book_branch,' ' as reserve1,' ' as reserve2,a.last_date as last_date,a.last_time as last_time
from tbcombi a left join tbproduct b on a.inter_prd_code = b.inter_prd_code
with read only
/

