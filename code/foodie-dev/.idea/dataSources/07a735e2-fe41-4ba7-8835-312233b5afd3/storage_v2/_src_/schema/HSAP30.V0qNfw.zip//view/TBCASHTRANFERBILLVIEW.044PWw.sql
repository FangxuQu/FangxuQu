create view TBCASHTRANFERBILLVIEW as
select r."YEAR0",r."MONTH0",r."DAY0",r."YWSM",r."RATE",r."YEAR1",r."MONTH1",r."DAY1",r."START_DATE",r."END_DATE",r."YEAR2",r."MONTH2",r."DAY2",r.skdwqc, r.skkhyh, r.skzh, r.fkdwqc, r.fkkhyh, r.fkzh, r.jyds, r."QUANZ",r."ZQME_W",r."ZQME",r."ZSBL",r."JINE",r."YUANY",r."PAY_AMT",r."INTER_PRD_CODE",r."CFL_NO",r."DEAL_SERIAL_NO",r."LEG_NO",r."INTER_CODE",r."COMBI_NO",r."INVEST_TYPE",r."PRD_CODE",r."PAY_DATE",r."FLAG" from (
--type1
select t1.year0, t1.month0, t1.day0, t1.ywsm, t1.rate, t1.year1, t1.month1, t1.day1, t1.start_date, t1.end_date, t1.year2, t1.month2, t1.day2,
t1.skdwqc, t1.skkhyh, t1.skzh, t1.fkdwqc, t1.fkkhyh, t1.fkzh, t1.jyds, t1.quanz, t1.zqme_w, '' as zqme, t1.zsbl, t1.jine, t1.yuany, t1.pay_amt,
t1.inter_prd_code , t1.cfl_no,  t1.deal_serial_no, t1.leg_no, t1.inter_code, t1.combi_no, ' ' as invest_type, t1.prd_code, t1.pay_date, t1.flag
from (
--鐞嗚储鍒版湡璧勯噾鍒掑洖
select
     to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鐞嗚储鍒版湡璧勯噾鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       ' ' as quanz, ' ' as zqme_w, ' ' as zsbl, v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夊埌鏈燂紝璧勯噾鍒掑洖銆傝祹鍥炴湰閲�||v.bj_amt||'鍏冿紝鍒╂伅閲戦'||sy_amt||'鍏� as yuany,
       v.pay_amt, v.inter_prd_code ,v.cfl_no, '0' as leg_no, v.deal_serial_no, '' as inter_code, '' as combi_no, '0' as is_hf, v.prd_code, v.pay_date, '3' as flag
     from (
       select v.pay_date, v.crebit_account, t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name, v.pay_amt, prd.prd_name, prd.prd_code, prd.inter_prd_code ,v.cfl_no,
          to_date(to_char(prd.end_date), 'yyyyMMdd') - to_date(to_char(prd.estab_date), 'yyyyMMdd') as qx_days,
          trim(to_char(trunc(coalesce(abs(t4.red_principal), 0), 2), '999999999990.99')) as bj_amt,
          trim(to_char(trunc(coalesce((t4.o_amount + t4.p_amount) - t4.red_principal, 0), 2), '999999999990.99')) as sy_amt,
          cast((prd.prd_max_bala/10000) as decimal(18,2)) as max_bala,  '0' as leg_no, v.ori_serial as deal_serial_no, '' as inter_code, '' as combi_no
        from (select '3' as cfl_flag,
           t3.inter_prd_code,
           v.bank_no,v.crebit_account,t3.busin_event,t3.ori_serial,t3.cfl_no,1 as leg_no,t3.end_date,t3.pay_date,t3.ori_pay_date,
           t3.cfl_type,0 pay_rate,t3.pay_ccy,
           trim(to_char(trunc(coalesce(abs(t3.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
           t3.ori_pay_amt,t3.position,t3.self_no,t3.inter_cust_no,t3.self_serial_no,t3.rival_serial_no,t3.netting_no,t3.fee_type,
           t3.status as cfl_status,t3.deal_status,t3.cash_settle_status
        from tbprdcfl t3, tbproduct v
       where t3.inter_prd_code = v.inter_prd_code
         and t3.cfl_type = '2'
         and v.model_flag = '0'
         and t3.busin_event in('A25', 'A82') ) v
        left join tbcustaccountinfo t1
        on v.self_serial_no = t1.serial_no
        left join tbcustaccountinfo t2
        on v.rival_serial_no = t2.serial_no
        left join tbbranch branch
        on v.self_no = branch.branch_no
        left join tbproduct prd
        on v.inter_prd_code = prd.inter_prd_code
        left join tbsyscustinfo t3
        on v.inter_cust_no = t3.inter_cust_no
        join tbprdsharedetail t4 on v.ori_serial = t4.deal_serial_no and t4.trans_type = '4'
       where 1 = 1
      )v
union all
-- 鍕熼泦璧勯噾鍒掍粯
  select
     to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鍕熼泦璧勯噾鍒掍粯' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       v.df_account_name as skdwqc,
       v.df_bank as skkhyh,
       v.df_account as skzh,
       v.bf_account_name as fkdwqc,
       v.bf_bank as fkkhyh,
       v.bf_account as fkzh,
       '姹夊彛閾惰鑲′唤鏈夐檺鍏徃' as jyds,
       ' ' as quanz, ' ' as zqme_w, ' ' as zsbl, v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夛紝鍕熼泦璧勯噾鍒掍粯' as yuany,
       v.pay_amt, v.inter_prd_code ,v.cfl_no, '0' as leg_no, v.deal_serial_no, '' as inter_code, '' as combi_no, '1' as is_hf, v.prd_code, v.pay_date, '4' as flag
  from (
    select
         v.pay_date, v.crebit_account, t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name, v.pay_amt, prd.prd_name, prd.prd_code,
         prd.inter_prd_code ,v.cfl_no, '0' as leg_no, v.ori_serial as deal_serial_no, '' as inter_code, '' as combi_no
        from (select '3' as cfl_flag,
           t3.inter_prd_code,
           v.bank_no,
           v.crebit_account,
           t3.busin_event,
           t3.ori_serial,
           t3.cfl_no,
           1 as leg_no,
           t3.end_date,
           t3.pay_date,
           t3.ori_pay_date,
           t3.cfl_type,
           0 pay_rate,
           t3.pay_ccy,
           trim(to_char(trunc(coalesce(abs(t3.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
           t3.ori_pay_amt,
           t3.position,
           t3.self_no,
           t3.inter_cust_no,
           t3.self_serial_no,
           t3.rival_serial_no,
           t3.netting_no,
           t3.fee_type,
           t3.status as cfl_status,
           t3.deal_status,
           t3.cash_settle_status
          from tbprdcfl t3, tbproduct v
         where t3.inter_prd_code = v.inter_prd_code
           and t3.cfl_type = '2'
           and t3.cash_settle_status <> '5'
           and v.model_flag = '0'
           and t3.busin_event in ('A80', 'A81')) v
      left join tbcustaccountinfo t1
        on v.self_serial_no = t1.serial_no
      left join tbcustaccountinfo t2
        on v.rival_serial_no = t2.serial_no
      left join tbbranch branch
        on v.self_no = branch.branch_no
      left join tbproduct prd
        on v.inter_prd_code = prd.inter_prd_code
      left join tbsyscustinfo t3
        on v.inter_cust_no = t3.inter_cust_no
    ) v
union all
-- 鎵樼璐规敮浠�select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day,
       '鐞嗚储鎵樼璐瑰垝浠� as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.bf_account_name as jyds,
       ' ' as quanz,
       ' ' as zqme_w,
       ' ' as zsbl,
       v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code ||'锛夊埌鏈燂紝鍒掍粯鎵樼璐广€傦紙鎵樼璐�||coalesce(v.tg_amt, 0)||'='||v.lcbj_amt||'*'||v.tg_rate||'%*'||v.qx_day||'/'||v.pay_basic||'锛夈€� as yuany,
       v.pay_amt, v.inter_prd_code ,v.cfl_no, '0' as leg_no, v.deal_serial_no, '' as inter_code, '' as combi_no, '1' as is_hf, v.prd_code, v.pay_date, '5' as flag
  from (select v.inter_prd_code,
               v.cfl_no,
               v.pay_date,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               trim(to_char(trunc(coalesce(abs(v.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               prd.prd_name,
               prd.prd_code,
               round(s.shareall * k.tg_rate / 365 * (to_date(prd.end_date, 'yyyyMMdd') - to_date(prd.estab_date, 'yyyyMMdd')), 2) as tg_amt, --鎵樼璐�               s.shareall as lcbj_amt, --鐞嗚储鏈噾
               coalesce(tg_rate, 0)*100 as tg_rate, --鎵樼璐圭巼
               to_date(prd.end_date, 'yyyyMMdd') -
               to_date(prd.estab_date, 'yyyyMMdd') as qx_day, --鎶曡祫鏈熼檺
               case when v.pay_basis = '1' then '360' else '365' end pay_basic,
         '0' as leg_no, v.ori_serial as deal_serial_no, '' as inter_code, '' as combi_no
          from (select '3' as cfl_flag,
                       v.estab_date,
                       t3.inter_prd_code,
                       v.bank_no,
                       t3.cfl_no,
                       t3.end_date,
                       t3.pay_date,
                       t3.cfl_type,
                       t3.pay_ccy,
                       t3.ori_serial,
                       abs(t3.pay_amt) as pay_amt,
                       t3.ori_pay_amt,
                       t3.pay_method,
                       t3.position,
                       t3.self_no,
                       t3.inter_cust_no,
                       t3.self_serial_no,
                       t3.rival_serial_no,
                       t3.netting_no,
                       t3.fee_type,
                       ' ' as first_maturity,
                       t3.status as cfl_status,
                       t3.deal_status,
                       t3.cash_settle_status,
                       t3.postscript,
                       t3.remark,
                       t3.busin_event,
                       v.pay_basis
                  from tbprdcfl t3, tbproduct v
                 where t3.inter_prd_code = v.inter_prd_code
                   and t3.cfl_type = '1'
                   and v.model_flag = '0'
                   and t3.fee_type = 'f'
                   and t3.busin_event = 'A89') v
          left join tbcustaccountinfo t1
            on v.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on v.rival_serial_no = t2.serial_no
          left join tbbranch branch
            on v.self_no = branch.branch_no
          left join tbproduct prd
            on v.inter_prd_code = prd.inter_prd_code
          left join (select sum(d.p_shares + d.o_shares) shareall,
                           sum(d.p_amount + d.o_amount) amountall,
                           d.inter_prd_code
                      from tbprdsharedetail d
                     where d.trans_type in ('1', '2', '5', '6')
                     group by d.inter_prd_code) s
            on s.inter_prd_code = v.inter_prd_code
          left join (select f.inter_prd_code,
                           sum(case
                                   when f.fee_type = 'f' then
                                    f.fee_rate
                                   else
                                    0
                               end) as tg_rate
                      from tbprdfeerate f
                     group by f.inter_prd_code) k
            on v.inter_prd_code = k.inter_prd_code) v
  union all
-- 鐞嗚储鏈熼棿鍒╂伅鍒掑洖
select
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鐞嗚储鏈熼棿鍒╂伅鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       v.df_account_name as skdwqc,
       v.df_bank as skkhyh,
       v.df_account as skzh,
       v.bf_account_name as fkdwqc,
       v.bf_bank as fkkhyh,
       v.bf_account as fkzh,
       v.bf_account_name as jyds,
       ' ' as quanz, ' ' as zqme_w, ' ' as zsbl, v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夌悊璐㈡湡闂村埄鎭垝鍥炪€� as yuany,
       v.pay_amt, v.inter_prd_code ,v.cfl_no, '0' as leg_no, v.deal_serial_no, '' as inter_code, '' as combi_no, '0' as is_hf, v.prd_code, v.pay_date, '1' as flag
       from (
           select v.pay_date, v.debit_account, t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
 v.pay_amt, prd.prd_name, prd.prd_code, prd.inter_prd_code ,v.cfl_no,
                  to_date(to_char(prd.end_date), 'yyyyMMdd') - to_date(to_char(prd.estab_date), 'yyyyMMdd') as qx_days,
                  trim(to_char(trunc(coalesce(abs(t4.red_principal), 0), 2), '999999999990.99')) as bj_amt,
                  trim(to_char(trunc(coalesce((t4.o_amount + t4.p_amount) - t4.red_principal, 0), 2), '999999999990.99')) as sy_amt,
                  cast((prd.prd_max_bala/10000) as decimal(18,2)) as max_bala,  '0' as leg_no, v.ori_serial as deal_serial_no, '' as inter_code, '' as combi_no
              from (select '3' as cfl_flag,
                   t3.inter_prd_code,
                   v.bank_no,
                   v.debit_account,
                   t3.busin_event,
                   t3.ori_serial,
                   t3.cfl_no,
                   1 as leg_no,
                   t3.end_date,
                   t3.pay_date,
                   t3.ori_pay_date,
                   t3.cfl_type,
                   0 pay_rate,
                   t3.pay_ccy,
                   trim(to_char(trunc(coalesce(abs(t3.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                   t3.ori_pay_amt,
                   t3.position,
                   t3.self_no,
                   t3.inter_cust_no,
                   t3.self_serial_no,
                   t3.rival_serial_no,
                   t3.netting_no,
                   t3.fee_type,
                   t3.status as cfl_status,
                   t3.deal_status,
                   t3.cash_settle_status
              from tbprdcfl t3, tbproduct v
             where t3.inter_prd_code = v.inter_prd_code
               and t3.cfl_type in ('3', '4')
               and v.model_flag = '0'
               and t3.busin_event = 'A85') v
              left join tbcustaccountinfo t1
                on v.self_serial_no = t1.serial_no
              left join tbcustaccountinfo t2
                on v.rival_serial_no = t2.serial_no
              left join tbbranch branch
                on v.self_no = branch.branch_no
              left join tbproduct prd
                on v.inter_prd_code = prd.inter_prd_code
              left join tbsyscustinfo t3
                on v.inter_cust_no = t3.inter_cust_no
              left join tbprdsharedetail t4 on v.ori_serial = t4.deal_serial_no
)v
union all
-- 鐞嗚储浜у搧杩樻湰璧勯噾鍒掑洖
select
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鐞嗚储浜у搧杩樻湰璧勯噾鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       ' ' as quanz, ' ' as zqme_w, ' ' as zsbl, v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夌悊璐㈡湡闂撮儴鍒嗚繕鏈紝鏈噾'||v.bj_w||'涓囧厓' as yuany,
       v.pay_amt, v.inter_prd_code ,v.cfl_no, '0' as leg_no, v.deal_serial_no, '' as inter_code, '' as combi_no, '0' as is_hf, v.prd_code, v.pay_date, '2' as flag
       from (
           select v.pay_date, v.debit_account, t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name, v.pay_amt, prd.prd_name, prd.prd_code, prd.inter_prd_code ,v.cfl_no,
                  to_date(to_char(prd.end_date), 'yyyyMMdd') - to_date(to_char(prd.estab_date), 'yyyyMMdd') as qx_days,
                  trim(to_char(trunc(coalesce(abs(t4.red_principal), 0), 2), '999999999990.99')) as bj_amt,
                  trim(to_char(trunc(coalesce((t4.o_amount + t4.p_amount) - t4.red_principal, 0), 2), '999999999990.99')) as sy_amt,
                  cast((prd.prd_max_bala/10000) as decimal(18,2)) as max_bala,  '0' as leg_no, v.ori_serial as deal_serial_no, '' as inter_code, '' as combi_no,
                  case when round(v.pay_amt/10000, 4) < 1 and round(v.pay_amt/10000, 4) != 0 then '0'||round(v.pay_amt/10000, 4)
                  else to_char(round(v.pay_amt/10000, 4)) end as bj_w
              from (select '3' as cfl_flag,
                   t3.inter_prd_code,
                   v.bank_no,
                   v.debit_account,
                   t3.busin_event,
                   t3.ori_serial,
                   t3.cfl_no,
                   1 as leg_no,
                   t3.end_date,
                   t3.pay_date,
                   t3.ori_pay_date,
                   t3.cfl_type,
                   0 pay_rate,
                   t3.pay_ccy,
                   trim(to_char(trunc(coalesce(abs(t3.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                   t3.ori_pay_amt,
                   t3.position,
                   t3.self_no,
                   t3.inter_cust_no,
                   t3.self_serial_no,
                   t3.rival_serial_no,
                   t3.netting_no,
                   t3.fee_type,
                   t3.status as cfl_status,
                   t3.deal_status,
                   t3.cash_settle_status
              from tbprdcfl t3, tbproduct v
             where t3.inter_prd_code = v.inter_prd_code
               and t3.cfl_type = '2'
               and v.model_flag = '0') v
              left join tbcustaccountinfo t1
                on v.self_serial_no = t1.serial_no
              left join tbcustaccountinfo t2
                on v.rival_serial_no = t2.serial_no
              left join tbbranch branch
                on v.self_no = branch.branch_no
              left join tbproduct prd
                on v.inter_prd_code = prd.inter_prd_code
              left join tbsyscustinfo t3
                on v.inter_cust_no = t3.inter_cust_no
              join tbprdsharedetail t4 on v.ori_serial = t4.deal_serial_no and t4.trans_type = '3'
             where 1 = 1 and v.busin_event in('A25', 'A82')
            )v
union all
-- 澧炲€肩◣闄勫姞绋庡垝鍥�select
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       v.prd_name || '浜у搧澧炲€肩◣鍙婇檮鍔犲垝鍥� as ywsm,
       ' ' as rate,
       to_char(to_date(v.start_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.start_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.start_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.start_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       to_char(to_date(v.end_date, 'YYYYMMDD'), 'YYYY-MM-DD') as end_date,
       to_char(to_date(v.end_date, 'YYYYMMDD'), 'YYYY') as year2,
       to_char(to_date(v.end_date, 'YYYYMMDD'), 'MM') as month2,
       to_char(to_date(v.end_date, 'YYYYMMDD'), 'DD') as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       ' ' as quanz, ' ' as zqme_w, ' ' as zsbl, v.pay_amt as jine,
       v.prd_name || '浜у搧锛堜唬鐮侊細' || v.prd_code || '锛�'
      || to_char(to_date(v.start_date, 'YYYYMMDD'), 'YYYY') || '骞�
      || to_char(to_date(v.start_date, 'YYYYMMDD'), 'MM') || '鏈�
      || to_char(to_date(v.start_date, 'YYYYMMDD'), 'DD') || '鏃ヨ嚦'
      || to_char(to_date(v.end_date, 'YYYYMMDD'), 'YYYY') || '骞�
      || to_char(to_date(v.end_date, 'YYYYMMDD'), 'MM') || '鏈�
      || to_char(to_date(v.end_date, 'YYYYMMDD'), 'DD') || '鏃ユ湡闂村鍊肩◣鍙婇檮鍔犲垝鍥炪€�浠樻鏂规埛鍚嶏細'
      || v.df_account_name ||' 璐﹀彿锛� || v.df_account || ' 寮€鎴疯锛� || v.df_bank ||')' as yuany,
       v.pay_amt, v.inter_prd_code ,v.cfl_no, '0' as leg_no,' ' as deal_serial_no, '' as inter_code, '' as combi_no, '0' as is_hf, v.prd_code, v.pay_date, '37' as flag
       from (
           select v.pay_date,v.start_date,v.end_date,v.debit_account, t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name, v.pay_amt, prd.prd_name, prd.prd_code, prd.inter_prd_code ,v.cfl_no
              from (select
                   t3.inter_prd_code,
                   v.bank_no,
                   v.debit_account,
                   t3.busin_event,
                   t3.ori_serial,
                   t3.cfl_no,
                   1 as leg_no,
                   t3.start_date,
                   t3.end_date,
                   t3.pay_date,
                   t3.ori_pay_date,
                   t3.cfl_type,
                   0 pay_rate,
                   t3.pay_ccy,
                   trim(to_char(trunc(coalesce(abs(t3.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                   t3.ori_pay_amt,
                   t3.position,
                   t3.self_no,
                   t3.inter_cust_no,
                   t3.self_serial_no,
                   t3.rival_serial_no,
                   t3.netting_no,
                   t3.status as cfl_status,
                   t3.deal_status,
                   t3.cash_settle_status
              from tbprdcfl t3, tbproduct v
             where t3.inter_prd_code = v.inter_prd_code
               and t3.cfl_type ='8'
               and v.model_flag = '0') v
              left join tbcustaccountinfo t1
                on v.self_serial_no = t1.serial_no
              left join tbcustaccountinfo t2
                on v.rival_serial_no = t2.serial_no
              left join tbbranch branch
                on v.self_no = branch.branch_no
              left join tbproduct prd
                on v.inter_prd_code = prd.inter_prd_code
              left join tbsyscustinfo t3
                on v.inter_cust_no = t3.inter_cust_no
                )v
) t1
-- type2
union all
select t2.year0, t2.month0, t2.day0, t2.ywsm, t2.rate, t2.year1, t2.month1, t2.day1, t2.start_date, t2.end_date, t2.year2, t2.month2, t2.day2,
t2.skdwqc, t2.skkhyh, t2.skzh, t2.fkdwqc, t2.fkkhyh, t2.fkzh, t2.jyds,  t2.quanz, t2.zqme_w, t2.zqme, t2.zsbl, t2.jine, t2.yuany, t2.pay_amt, t2.inter_prd_code , t2.cfl_no,  t2.deal_serial_no, t2.leg_no,
t2.inter_code, t2.combi_no, t2.invest_type, t2.prd_code, t2.pay_date, t2.flag
from (
 select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '閫嗗洖璐� as ywsm, v.rate as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'YYYY') as year2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'MM') as month2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'DD') as day2,
       v.df_account_name as skdwqc,
       v.df_bank as skkhyh,
       v.df_account as skzh,
       v.bf_account_name as fkdwqc,
       v.bf_bank as fkkhyh,
       v.bf_account as fkzh,
       v.df_account_name as jyds,
       ' ' as quanz, v.zqme_w, to_char(v.zqme) as zqme, ' ' as zsbl, v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夊悜'||v.df_bank||'铻嶅嚭璧勯噾锛屽埄鐜�||v.rate||'锛屽埌鏈熷洖娆鹃噾棰�||coalesce(v.second_clear_balance, 0)||'鍏冦€� as yuany,
       v.pay_amt, v.inter_prd_code, v.cfl_no, v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '6' as flag
  from (select v.pay_date,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               prd.prd_name,
               prd.prd_code,
               v.second_settle_type,
               v.second_clear_balance,
               v.maturity_date_adj,
               t3.cust_fullname,
               case when v.rate < 1 and v.rate != 0 then '0'||v.rate else to_char(v.rate) end || '%' as rate,
               case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
               v.zqme,
               prd.inter_prd_code,
               v.cfl_no,
               v.deal_serial_no,
               v.leg_no,
               v.inter_code,
               v.combi_no,
               v.pay_amt,
               v.invest_type
          from (select t1.*,
                    round(coalesce(abs(case busin_class when '32' then deal2.rate else deal.rate end), 0), 4) as rate,
                    round((case busin_class when '32' then deal2.settle_amt else deal.first_net_balance end) / 10000, 4) as zqme_w,
                    case busin_class when '32' then deal2.settle_amt else deal.first_net_balance end as zqme,
                    deal2.second_settle_type,
                    deal2.second_clear_balance
                  from (select t2.deal_serial_no,t1.inter_code,t1.combi_no,c.inter_prd_code,t1.invest_type,t1.busin_class,t1.busin_type,t1.bank_no,t1.open_branch,
                           t1.status as status,t1.dealing_status,t2.cfl_no,t2.leg_no,t2.end_date,t2.pay_date,t2.cfl_type,t2.pay_rate,t2.pay_ccy,
                               trim(to_char(trunc(coalesce(abs(t2.pay_amt),0),2),'999999999990.99')) as pay_amt,t2.ori_pay_amt,t2.pay_method,t2.position,
                               t2.self_no,t2.inter_cust_no,t2.self_serial_no,t2.rival_serial_no,t2.netting_no,t2.fee_type,t2.status as cfl_status,t2.deal_status,
                               t2.cash_settle_status,t1.source_trade_flag,t2.nominal_amt,t1.entrust_direction,t1.maturity_date_adj,t2.version_no
                          from tbinstcfl t2, tbcombi c, tbinstext t1
                         where t2.deal_serial_no = t1.deal_serial_no
                           and t1.combi_no = c.combi_no
                           and t2.version_no = 0
                           and t1.version_no = t2.version_no
                           and t1.status not in ('a', '0', '3')
                           and t1.dealing_status not in ('1', '5')
                           and t1.source_trade_flag = '0'
                           and t1.busin_class in ('32', '34')
                           and t2.cfl_type = '2'
                           and t2.first_maturity = '5') t1
                  left join tbrealdeal deal
                    on t1.deal_serial_no = deal.deal_serial_no
                   and deal.version_no = t1.version_no
                  left join tbmmrealdeal deal2
                    on t1.deal_serial_no = deal2.deal_serial_no
                   and deal2.version_no = t1.version_no
                  left join tbrealdeal real
                    on real.deal_serial_no = t1.deal_serial_no, tbproduct p
                  left join tbcombiprdext ext
                    on p.inter_prd_code = ext.inter_prd_code
                 where t1.inter_prd_code = p.inter_prd_code
                   and p.model_flag in ('0', '2', '1')) v
          left join tbcustaccountinfo t1
            on v.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on v.rival_serial_no = t1.serial_no
          left join tbstockinfo info
            on v.inter_code = info.inter_code
          left join tbproduct prd
            on v.inter_prd_code = prd.inter_prd_code
          left join tbsyscustinfo t3
            on v.inter_cust_no = t3.inter_cust_no
          left join tbmmrealdeal deal
            on deal.deal_serial_no = v.deal_serial_no) v
  union all
--- 閫嗗洖璐埌鏈熻繕娆�select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '杩樻' as ywsm,
       case when v.rate < 1 and v.rate != 0 then '0'||v.rate else to_char(v.rate) end || '%' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'YYYY') as year2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'MM') as month2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'DD') as day2,
       t1.account_name as skdwqc,
       t1.bank as skkhyh,
       t1.account as skzh,
       t2.account_name as fkdwqc,
       t2.bank as fkkhyh,
       t2.account as fkzh,
       t2.account_name as jyds,
       ' ' as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl, v.pay_amt as jine, '閫嗗洖璐埌鏈熻繕娆俱€� as yuany,
       v.pay_amt, v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '7' as flag
  from (select t1.pay_date,
               t1.maturity_date_adj,
               p.prd_name,
               p.prd_code,
               round(coalesce(abs(case busin_class when '32' then deal2.rate else deal.rate end), 0), 4) as rate,
               round((case busin_class when '32' then deal2.settle_amt else deal.first_net_balance end) / 10000, 4) as zqme_w,
               case busin_class when '32' then deal2.settle_amt else deal.first_net_balance end as zqme,
               t1.pay_amt,
               t1.rival_serial_no, t1.self_serial_no, t1.inter_cust_no,
               t1.inter_prd_code , t1.cfl_no,  t1.deal_serial_no, t1.leg_no, t1.inter_code, t1.combi_no, t1.invest_type
          from (select t2.deal_serial_no,
                       t1.inter_code,
                       t1.combi_no,
                       c.inter_prd_code,
                       t1.invest_type,
                       t1.busin_class,
                       t1.busin_type,
                       t1.bank_no,
                       t1.open_branch,
                       t1.status             as status,
                       t1.dealing_status,
                       t2.cfl_no,
                       t2.leg_no,
                       t2.end_date,
                       t2.pay_date,
                       t2.cfl_type,
                       t2.pay_rate,
                       t2.pay_ccy,
                       trim(to_char(trunc(coalesce(abs(t2.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                       t2.ori_pay_amt,
                       t2.pay_method,
                       t2.position,
                       t2.self_no,
                       t2.inter_cust_no,
                       t2.self_serial_no,
                       t2.rival_serial_no,
                       t2.netting_no,
                       t2.fee_type,
                       t2.first_maturity,
                       t2.status             as cfl_status,
                       t2.deal_status,
                       t2.cash_settle_status,
                       t1.source_trade_flag,
                       t2.nominal_amt,
                       t1.entrust_direction,
                       t1.maturity_date_adj,
                       t2.version_no
                  from tbinstcfl t2, tbcombi c, tbinstext t1
                 where t2.deal_serial_no = t1.deal_serial_no
                   and t1.combi_no = c.combi_no
                   and t2.version_no = 0
                   and t1.version_no = t2.version_no
                   and t1.status not in ('a', '0', '3')
                   and t1.dealing_status not in ('1', '5')
                   and t1.source_trade_flag = '0'
                   and t1.busin_class in ('32', '34')
                   and t2.cfl_type = '2'
                   and t2.first_maturity = '6') t1
          left join tbrealdeal deal
            on t1.deal_serial_no = deal.deal_serial_no and deal.version_no = t1.version_no
          left join tbmmrealdeal deal2
            on t1.deal_serial_no = deal2.deal_serial_no and deal2.version_no = t1.version_no
          left join tbproduct p
            on t1.inter_prd_code = p.inter_prd_code
           and p.model_flag in ('0', '2', '1')) v
  left join tbcustaccountinfo t1
    on v.self_serial_no = t1.serial_no
  left join tbcustaccountinfo t2
    on v.rival_serial_no = t2.serial_no
  left join tbsyscustinfo t3
    on v.inter_cust_no = t3.inter_cust_no
  left join tbproduct prd
    on v.inter_prd_code = prd.inter_prd_code
union all
-- 姝ｅ洖璐�select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '姝ｅ洖璐� as ywsm, v.rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'YYYY') as year2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'MM') as month2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'DD') as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       ' ' as quanz, v.zqme_w, to_char(v.zqme) as zqme, ' ' as zsbl, v.pay_amt as jine,
       v.prd_name || '锛堜唬鐮� ' || v.prd_code || '锛夎瀺鍏� || v.cust_fullname || '锛屽埄鐜� || v.rate || '銆� as yuany,
       v.pay_amt, v.inter_prd_code, v.cfl_no, v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '8' as flag
  from (select v.pay_date,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               prd.prd_name,
               prd.prd_code,
               v.second_settle_type,
               v.second_clear_balance,
               v.maturity_date_adj,
               t3.cust_fullname,
               case when v.rate < 1 and v.rate != 0 then '0'||v.rate else to_char(v.rate) end || '%' as rate,
               case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
               v.zqme,
               prd.inter_prd_code,
               v.cfl_no,
               v.deal_serial_no,
               v.leg_no,
               v.inter_code,
               v.combi_no,
               v.pay_amt,
               v.invest_type
          from (select t1.*,
                    round(coalesce(abs(case busin_class when '31' then deal2.rate else deal.rate end), 0), 4) as rate,
                    round((case busin_class when '31' then deal2.settle_amt else deal.first_net_balance end) / 10000, 4) as zqme_w,
                    case busin_class when '31' then deal2.settle_amt else deal.first_net_balance end as zqme,
                       deal2.second_settle_type,
                       deal2.second_clear_balance
                  from (select t2.deal_serial_no,t1.inter_code,t1.combi_no,c.inter_prd_code,t1.invest_type,t1.busin_class,t1.busin_type,t1.bank_no,t1.open_branch,
                           t1.status as status,t1.dealing_status,t2.cfl_no,t2.leg_no,t2.end_date,t2.pay_date,t2.cfl_type,t2.pay_rate,t2.pay_ccy,
                               trim(to_char(trunc(coalesce(abs(t2.pay_amt),0),2),'999999999990.99')) as pay_amt,t2.ori_pay_amt,t2.pay_method,t2.position,
                               t2.self_no,t2.inter_cust_no,t2.self_serial_no,t2.rival_serial_no,t2.netting_no,t2.fee_type,t2.status as cfl_status,t2.deal_status,
                               t2.cash_settle_status,t1.source_trade_flag,t2.nominal_amt,t1.entrust_direction,t1.maturity_date_adj,t2.version_no
                          from tbinstcfl t2, tbcombi c, tbinstext t1
                         where t2.deal_serial_no = t1.deal_serial_no
                           and t1.combi_no = c.combi_no
                           and t2.version_no = 0
                           and t1.version_no = t2.version_no
                           and t1.status not in ('a', '0', '3')
                           and t1.dealing_status not in ('1', '5')
                           and t1.source_trade_flag = '0'
                           and t1.busin_class in ('31', '33')
                           and t2.cfl_type = '2'
                           and t2.first_maturity = '5') t1
                  left join tbrealdeal deal
                    on t1.deal_serial_no = deal.deal_serial_no
                   and deal.version_no = t1.version_no
                  left join tbmmrealdeal deal2
                    on t1.deal_serial_no = deal2.deal_serial_no
                   and deal2.version_no = t1.version_no
                  left join tbrealdeal real
                    on real.deal_serial_no = t1.deal_serial_no, tbproduct p
                  left join tbcombiprdext ext
                    on p.inter_prd_code = ext.inter_prd_code
                 where t1.inter_prd_code = p.inter_prd_code
                   and p.model_flag in ('0', '2', '1')) v
          left join tbcustaccountinfo t1
            on v.self_serial_no = t1.serial_no
           left join tbcustaccountinfo t2
            on v.rival_serial_no = t2.serial_no
          left join tbstockinfo info
            on v.inter_code = info.inter_code
          left join tbproduct prd
            on v.inter_prd_code = prd.inter_prd_code
          left join tbsyscustinfo t3
            on v.inter_cust_no = t3.inter_cust_no
          left join tbmmrealdeal deal
            on deal.deal_serial_no = v.deal_serial_no) v
union all
--- 姝ｅ洖璐埌鏈熻繕娆�select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '杩樻' as ywsm,
       case when v.rate < 1 and v.rate != 0 then '0'||v.rate else to_char(v.rate) end || '%' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'YYYY') as year2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'MM') as month2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'DD') as day2,
       t2.account_name as skdwqc,
       t2.bank as skkhyh,
       t2.account as skzh,
       t1.account_name as fkdwqc,
       t1.bank as fkkhyh,
       t1.account as fkzh,
       t2.account_name as jyds,
       ' ' as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
      '姝ｅ洖璐埌鏈熻繕娆俱€� as yuany,
       v.pay_amt, v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '9' as flag
  from (select t1.pay_date,
               t1.maturity_date_adj,
               p.prd_name,
               p.prd_code,
               round(coalesce(abs(case busin_class when '31' then deal2.rate else deal.rate end), 0), 4) as rate,
               round((case busin_class when '31' then deal2.settle_amt else deal.first_net_balance end) / 10000, 4) as zqme_w,
               case busin_class when '31' then deal2.settle_amt else deal.first_net_balance end as zqme,
               t1.pay_amt,
               t1.rival_serial_no, t1.self_serial_no, t1.inter_cust_no,
               t1.inter_prd_code , t1.cfl_no,  t1.deal_serial_no, t1.leg_no, t1.inter_code, t1.combi_no, t1.invest_type
          from (select t2.deal_serial_no,
                       t1.inter_code,
                       t1.combi_no,
                       c.inter_prd_code,
                       t1.invest_type,
                       t1.busin_class,
                       t1.busin_type,
                       t1.bank_no,
                       t1.open_branch,
                       t1.status             as status,
                       t1.dealing_status,
                       t2.cfl_no,
                       t2.leg_no,
                       t2.end_date,
                       t2.pay_date,
                       t2.cfl_type,
                       t2.pay_rate,
                       t2.pay_ccy,
                       trim(to_char(trunc(coalesce(abs(t2.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                       t2.ori_pay_amt,
                       t2.pay_method,
                       t2.position,
                       t2.self_no,
                       t2.inter_cust_no,
                       t2.self_serial_no,
                       t2.rival_serial_no,
                       t2.netting_no,
                       t2.fee_type,
                       t2.first_maturity,
                       t2.status             as cfl_status,
                       t2.deal_status,
                       t2.cash_settle_status,
                       t1.source_trade_flag,
                       t2.nominal_amt,
                       t1.entrust_direction,
                       t1.maturity_date_adj,
                       t2.version_no
                  from tbinstcfl t2, tbcombi c, tbinstext t1
                 where t2.deal_serial_no = t1.deal_serial_no
                   and t1.combi_no = c.combi_no
                   and t2.version_no = 0
                   and t1.version_no = t2.version_no
                   and t1.status not in ('a', '0', '3')
                   and t1.dealing_status not in ('1', '5')
                   and t1.source_trade_flag = '0'
                   and t1.busin_class in ('31', '33')
                   and t2.cfl_type = '2'
                   and t2.first_maturity = '6') t1
          left join tbrealdeal deal
            on t1.deal_serial_no = deal.deal_serial_no and deal.version_no = t1.version_no
          left join tbmmrealdeal deal2
            on t1.deal_serial_no = deal2.deal_serial_no and deal2.version_no = t1.version_no
          left join tbproduct p
            on t1.inter_prd_code = p.inter_prd_code
           and p.model_flag in ('0', '2', '1')) v
  left join tbcustaccountinfo t1
    on v.self_serial_no = t1.serial_no
  left join tbcustaccountinfo t2
    on v.rival_serial_no = t2.serial_no
  left join tbsyscustinfo t3
    on v.inter_cust_no = t3.inter_cust_no
  left join tbproduct prd
    on v.inter_prd_code = prd.inter_prd_code
union all
-- 鐞嗚储璧勪骇鍑鸿
        select
               to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
               to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
               to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
               '鐞嗚储璧勪骇鍑鸿' as ywsm,
               ' ' as rate,
               to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
               to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
               to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
               to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
               '' as end_date,
               ' ' as year2, ' ' as month2, ' ' as day2,
               t1.account_name as skdwqc,
               t1.bank as skkhyh,
               t1.account as skzh,
               t2.account_name as fkdwqc,
               t2.bank as fkkhyh,
               t2.account as fkzh,
               t3.cust_fullname as jyds,
               v.inter_code||' '||v.zqme_w||'涓� as quanz,
               v.zqme_w||'涓� as zqme_w,
               to_char(v.zqme) as zqme,
               ' ' as zsbl,
               v.pay_amt as jine,
              prd.prd_name||'锛�||prd.prd_code||'锛夊悜'||t3.cust_fullname||'鍑鸿璧勪骇銆� as yuany,
               v.pay_amt, v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, prd.prd_code, v.pay_date, '10' as flag
          from (select t1.*
                  from (select t2.deal_serial_no,
                               t1.inter_code,
                               t1.combi_no,
                               c.inter_prd_code,
                               t1.invest_type,
                               t1.busin_class,
                               t1.busin_type,
                               t1.bank_no,
                               t1.open_branch,
                               t1.status             as status,
                               t1.dealing_status,
                               t2.cfl_no,
                               t2.leg_no,
                               t2.end_date,
                               t2.pay_date,
                               t2.cfl_type,
                               t2.pay_rate,
                               t2.pay_ccy,
                               trim(to_char(trunc(coalesce(abs(t2.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                               t2.pay_method,
                               t2.position,
                               t2.self_no,
                               t2.inter_cust_no,
                               t2.self_serial_no,
                               t2.rival_serial_no,
                               t2.netting_no,
                               t2.fee_type,
                               t2.first_maturity,
                               t2.status             as cfl_status,
                               t2.deal_status,
                               t2.cash_settle_status,
                               t1.source_trade_flag,
                               t2.nominal_amt,
                               case when round(t2.nominal_amt/10000, 4) < 1 and round(t2.nominal_amt/10000, 4) != 0 then '0'||round(t2.nominal_amt/10000, 4) else to_char(round(t2.nominal_amt/10000, 4)) end as zqme_w ,
                               t2.nominal_amt as zqme,
                               t1.entrust_direction,
                               t1.maturity_date_adj
                          from tbinstcfl t2, tbcombi c, tbinstext t1
                         where t2.deal_serial_no = t1.deal_serial_no
                           and t1.combi_no = c.combi_no
                           and t1.version_no = t2.version_no
                           and t1.version_no = 0
                           and t1.status not in ('a', '0', '3')
                           and t1.dealing_status not in ('1', '5')
                           and t1.source_trade_flag = '0'
                           and t1.inner_trade_flag = '1'
                           and t2.position = '1'
                           and t2.cfl_type = '2'
                           and t1.busin_type in ('11', 'O1')
                           and t1.inner_trade_flag = '1'
                           ) t1,
                       tbproduct p
                  left join tbcombiprdext ext
                    on p.inter_prd_code = ext.inter_prd_code
                 where t1.inter_prd_code = p.inter_prd_code
                   and p.model_flag in ('0', '2', '1')) v
          left join tbcustaccountinfo t1
            on v.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on v.rival_serial_no = t2.serial_no
          left join tbbranch branch
            on v.self_no = branch.branch_no
          left join tbstockinfo info
            on v.inter_code = info.inter_code
          left join tbassetplan tp
            on v.inter_code = tp.inter_code
          left join tbproduct prd
            on v.inter_prd_code = prd.inter_prd_code
          left join tbsyscustinfo t3
            on v.inter_cust_no = t3.inter_cust_no
union all
-- 鐞嗚储璧勪骇鍙楄
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鐞嗚储璧勪骇鍙楄' as ywsm, ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       t2.account_name as skdwqc,
       t2.bank as skkhyh,
       t2.account as skzh,
       t1.account_name as fkdwqc,
       t1.bank as fkkhyh,
       t1.account as fkzh,
       t3.cust_fullname as jyds,
       v.inter_code || ' ' || v.zqme_w || '涓� as quanz,
       v.zqme_w || '涓� as zqme_w, to_char(v.zqme) as zqme, ' ' as zsbl, v.pay_amt as jine,
       prd.prd_name || '锛� || prd.prd_code || '锛夊彈璁� || t3.cust_fullname ||'鐞嗚储璧勪骇銆� as yuany, v.pay_amt,
       v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, prd.prd_code, v.pay_date, '11' as flag
  from (select t1.*
          from (select t2.deal_serial_no,
                       t1.inter_code,
                       t1.combi_no,
                       c.inter_prd_code,
                       t1.invest_type,
                       t1.busin_class,
                       t1.busin_type,
                       t1.bank_no,
                       t1.open_branch,
                       t1.status as status,
                       t1.dealing_status,
                       t2.cfl_no,
                       t2.leg_no,
                       t2.end_date,
                       t2.pay_date,
                       t2.cfl_type,
                       t2.pay_rate,
                       t2.pay_ccy,
                       trim(to_char(trunc(coalesce(abs(t2.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                       t2.pay_method,
                       t2.position,
                       t2.self_no,
                       t2.inter_cust_no,
                       t2.self_serial_no,
                       t2.rival_serial_no,
                       t2.netting_no,
                       t2.fee_type,
                       t2.first_maturity,
                       t2.status as cfl_status,
                       t2.deal_status,
                       t2.cash_settle_status,
                       t1.source_trade_flag,
                       t2.nominal_amt,
                       case when round(t2.nominal_amt/10000, 4) < 1 and round(t2.nominal_amt/10000, 4) != 0 then '0'||round(t2.nominal_amt/10000, 4)
                       else to_char(round(t2.nominal_amt/10000, 4)) end as zqme_w ,
                       t2.nominal_amt as zqme,
                       t1.entrust_direction,
                       t1.maturity_date_adj
                  from tbinstcfl t2, tbcombi c, tbinstext t1
                 where t2.deal_serial_no = t1.deal_serial_no
                   and t1.combi_no = c.combi_no
                   and t1.version_no = t2.version_no
                   and t1.version_no = 0
                   and t1.status not in ('a', '0', '3')
                   and t1.dealing_status not in ('1', '5')
                   and t1.source_trade_flag = '0'
                   and t1.inner_trade_flag = '1'
                   and t2.position = '2'
                   and t2.cfl_type = '2'
                   and t1.inner_trade_flag = '1'
                   and t1.busin_type in ('11', 'O1')) t1,
               tbproduct p
          left join tbcombiprdext ext
            on p.inter_prd_code = ext.inter_prd_code
         where t1.inter_prd_code = p.inter_prd_code
           and p.model_flag in ('0', '2', '1')) v
  left join tbcustaccountinfo t1
    on v.self_serial_no = t1.serial_no
  left join tbcustaccountinfo t2
    on v.rival_serial_no = t2.serial_no
  left join tbstockinfo info
    on v.inter_code = info.inter_code
  left join tbproduct prd
    on v.inter_prd_code = prd.inter_prd_code
  left join tbsyscustinfo t3
    on v.inter_cust_no = t3.inter_cust_no
union all
-- 鍗栧嚭鍊哄埜
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鍗栧嚭鍊哄埜' as ywsm, case when v.rate < 1 and v.rate != 0 then '0'||v.rate else to_char(v.rate) end || '%' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       t1.account_name as skdwqc,
       t1.bank as skkhyh,
       t1.account as skzh,
       t2.account_name as fkdwqc,
       t2.bank as fkkhyh,
       t2.account as fkzh,
       t2.account_name as jyds,
       property.bond_code as quanz,
       v.zqme_w || '涓� as zqme_w, to_char(v.zqme) as zqme, ' ' as zsbl, v.pay_amt as jine,
       prd.prd_name || '锛� || prd.prd_code || '锛夊悜' || t3.cust_fullname ||'鍗栧嚭鍊哄埜璧勪骇銆� as yuany, v.pay_amt,
       v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, prd.prd_code, v.pay_date, '12' as flag
  from (select t.*
          from (select ext.deal_serial_no,
                       ext.inter_code,
                       ext.combi_no,
                       bi.inter_prd_code,
                       ext.busin_class,
                       ext.busin_type,
                       ext.bank_no,
                       ext.balance,
                       case when round(ext.balance/10000, 4) < 1 and round(ext.balance/10000, 4) != 0 then '0'||round(ext.balance/10000, 4)
                       else to_char(round(ext.balance/10000, 4)) end as zqme_w ,
                       ext.balance as zqme,
                       cfl.cfl_no,
                       cfl.leg_no,
                       cfl.pay_date,
                       cfl.pay_rate,
                       trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                       cfl.position,
                       cfl.self_no,
                       cfl.inter_cust_no,
                       cfl.self_serial_no,
                       cfl.rival_serial_no,
                       cfl.fee_type,
                       cfl.nominal_amt,
                       cfl.cfl_type,
                       round(coalesce(abs(deal.first_mature_yield), 0), 4) as rate,
                       ext.invest_type
                  from tbinstext ext
                  left join tbinstcfl cfl
                    on cfl.deal_serial_no = ext.deal_serial_no
                   and cfl.version_no = ext.version_no
                  left join tbcombi bi
                    on ext.combi_no = bi.combi_no
                  left join tbrealdeal deal
            on cfl.deal_serial_no = deal.deal_serial_no
                 where ext.version_no = 0
                   and ext.status not in ('a', '0', '3')
                   and ext.dealing_status not in ('1', '5')
                   and ext.source_trade_flag = '0'
                   and ext.busin_class = '12'
                   and cfl.cfl_type = '2'
                   and cfl.position = '1'
                   and ext.inner_trade_flag = '0'
                   ) t
          left join tbproduct prd
            on prd.inter_prd_code = t.inter_prd_code
         where prd.model_flag in ('0', '2', '1')) v
  left join tbcustaccountinfo t1
    on v.self_serial_no = t1.serial_no
  left join tbcustaccountinfo t2
    on v.rival_serial_no = t2.serial_no
  left join tbproduct prd
    on v.inter_prd_code = prd.inter_prd_code
  left join tbsyscustinfo t3
    on v.inter_cust_no = t3.inter_cust_no
  left join tbbondproperty property
    on property.inter_code = v.inter_code
union all
-- 涔板叆鍊哄埜
select
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '涔板叆鍊哄埜' as ywsm, case when v.rate < 1 and v.rate != 0 then '0'||v.rate else to_char(v.rate) end || '%' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       t2.account_name as skdwqc,
       t2.bank as skkhyh,
       t2.account as skzh,
       t1.account_name as fkdwqc,
       t1.bank as fkkhyh,
       t1.account as fkzh,
       t2.account_name as jyds,
       property.bond_code as quanz,
       v.zqme_w || '涓� as zqme_w, to_char(v.zqme) as zqme, ' ' as zsbl, v.pay_amt as jine,
       prd.prd_name || '锛� || prd.prd_code || '锛変拱鍏� || t3.cust_fullname ||'鍊哄埜璧勪骇銆� as yuany, v.pay_amt,
       v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, prd.prd_code, v.pay_date, '13' as flag
  from (select t.*
          from (select ext.deal_serial_no,
                       ext.inter_code,
                       ext.combi_no,
                       bi.inter_prd_code,
                       ext.busin_class,
                       ext.busin_type,
                       ext.bank_no,
                       ext.balance,
                       case when round(ext.balance/10000, 4) < 1 and round(ext.balance/10000, 4) != 0 then '0'||round(ext.balance/10000, 4)
                       else to_char(round(ext.balance/10000, 4)) end as zqme_w ,
                       ext.balance as zqme,
                       cfl.cfl_no,
                       cfl.leg_no,
                       cfl.pay_date,
                       cfl.pay_rate,
                       trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                       cfl.position,
                       cfl.self_no,
                       cfl.inter_cust_no,
                       cfl.self_serial_no,
                       cfl.rival_serial_no,
                       cfl.fee_type,
                       cfl.nominal_amt,
                       cfl.cfl_type,
                       round(coalesce(abs(deal.first_mature_yield), 0), 4) as rate,
                       ext.invest_type
                  from tbinstext ext
                  left join tbinstcfl cfl
                    on cfl.deal_serial_no = ext.deal_serial_no
                   and cfl.version_no = ext.version_no
                  left join tbcombi bi
                    on ext.combi_no = bi.combi_no
                  left join tbrealdeal deal
            on cfl.deal_serial_no = deal.deal_serial_no
                 where ext.version_no = 0
                   and ext.status not in ('a', '0', '3')
                   and ext.dealing_status not in ('1', '5')
                   and ext.source_trade_flag = '0'
                   and ext.busin_class = '11'
                   and cfl.cfl_type = '2'
                   and cfl.position = '2'
                   and ext.inner_trade_flag = '0'
                   ) t
          left join tbproduct prd
            on prd.inter_prd_code = t.inter_prd_code
         where prd.model_flag in ('0', '2', '1')) v
  left join tbcustaccountinfo t1
    on v.self_serial_no = t1.serial_no
  left join tbcustaccountinfo t2
    on v.rival_serial_no = t2.serial_no
  left join tbassetplan tp
    on v.inter_code = tp.inter_code
  left join tbproduct prd
    on v.inter_prd_code = prd.inter_prd_code
  left join tbsyscustinfo t3
    on v.inter_cust_no = t3.inter_cust_no
  left join tbbondproperty property
    on property.inter_code = v.inter_code
union all
-- 鍗栧嚭鐞嗚储璧勪骇
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鍗栧嚭鐞嗚储璧勪骇' as ywsm, ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       t1.account_name as skdwqc,
       t1.bank as skkhyh,
       t1.account as skzh,
       t2.account_name as fkdwqc,
       t2.bank as fkkhyh,
       t2.account as fkzh,
       t2.account_name as jyds,
       v.inter_code || ' ' || v.balance_w || '涓� as quanz,
       v.zqme_w, to_char(v.zqme) as zqme, ' ' as zsbl, v.pay_amt as jine,
       prd.prd_name || '锛� || prd.prd_code || '锛夊崠鍑虹悊璐㈣祫浜с€� as yuany, v.pay_amt,
       v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, prd.prd_code, v.pay_date, '14' as flag
          from (select t1.*, case when t1.balance_w < 1 and t1.balance_w != 0 then '0'||t1.balance_w else to_char(t1.balance_w) end || '涓� as zqme_w
                  from (select t1.deal_serial_no,
                       t1.inter_code,
                       t1.combi_no,
                       c.inter_prd_code,
                       t1.busin_class,
                       t1.busin_type,
                       t1.bank_no,
                       t1.balance,
                       round(t1.balance/10000, 4) as balance_w,
                       t1.balance as zqme,
                       t2.cfl_no,
                       t2.leg_no,
                       t2.pay_date,
                       t2.pay_rate,
                       trim(to_char(trunc(coalesce(abs(t2.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                       t2.position,
                       t2.self_no,
                       t2.inter_cust_no,
                       t2.self_serial_no,
                       t2.rival_serial_no,
                       t2.fee_type,
                       t2.nominal_amt,
                       t2.cfl_type,
                       t1.invest_type
                          from tbinstcfl t2, tbcombi c, tbinstext t1
                         where t2.deal_serial_no = t1.deal_serial_no
                           and t1.combi_no = c.combi_no
                           and t1.version_no = t2.version_no
                           and t1.version_no = 0
                           and t1.status not in ('a', '0', '3')
                           and t1.dealing_status not in ('1', '5')
                           and t1.source_trade_flag = '0'
                           and t2.position = '1'
                           and t2.cfl_type = '2'
                           and t1.busin_type in ('H1', 'O1')
                           and t1.entrust_direction = '4'
                           ) t1,
                       tbproduct p
                  left join tbcombiprdext ext
                    on p.inter_prd_code = ext.inter_prd_code
                 where t1.inter_prd_code = p.inter_prd_code
                   and p.model_flag in ('0', '2', '1')) v
          left join tbcustaccountinfo t1
            on v.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on v.rival_serial_no = t2.serial_no
          left join tbstockinfo info
            on v.inter_code = info.inter_code
          left join tbproduct prd
            on v.inter_prd_code = prd.inter_prd_code
          left join tbsyscustinfo t3
            on v.inter_cust_no = t3.inter_cust_no
          left join tbbondproperty property
            on property.inter_code = v.inter_code
          left join tbrate r
            on r.deal_serial_no = v.inter_code and r.start_date_adj < v.pay_date and r.end_date_adj > v.pay_date
          left join tbrealdeal deal
            on v.deal_serial_no = deal.deal_serial_no
          left join vassetinfo views
            on v.inter_code = views.inter_code
union all
-- 涔板叆鐞嗚储璧勪骇
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '涔板叆鐞嗚储璧勪骇' as ywsm,
       case when v.rate_v < 1 and v.rate_v != 0 then '0'||v.rate_v else to_char(v.rate_v) end || '%' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       t2.account_name as skdwqc,
       t2.bank as skkhyh,
       t2.account as skzh,
       t1.account_name as fkdwqc,
       t1.bank as fkkhyh,
       t1.account as fkzh,
       t2.account_name as jyds,
       info.object_code || ' ' || v.zqme_w as quanz,
       v.zqme_w, to_char(v.zqme) as zqme, ' ' as zsbl, v.pay_amt as jine,
       prd.prd_name || '锛� || prd.prd_code || '锛変拱鍏ョ悊璐㈣祫浜э紝鍒╃巼' || case when v.rate_v < 1 and v.rate_v != 0 then '0'||v.rate_v else to_char(v.rate_v) end || '%锛屾湡闄� ||
       to_char(to_date(to_char(views.end_date), 'yyyyMMdd') - to_date(to_char(views.value_date), 'yyyyMMdd')) || '鏃ャ€� as yuany,
       v.pay_amt, v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no,  v.invest_type, '0' as is_hf, prd.prd_code, v.pay_date, '15' as flag
  from (select t1.*, round(coalesce(abs(r.pay_rate), 0), 4) as rate_v,
      case when t1.zqme_w_v < 1 and t1.zqme_w_v != 0 then '0'||t1.zqme_w_v else to_char(t1.zqme_w_v) end || '涓� as zqme_w
          from (select t1.deal_serial_no,
                       t1.inter_code,
                       t1.combi_no,
                       c.inter_prd_code,
                       t1.busin_class,
                       t1.busin_type,
                       t1.bank_no,
                       t1.balance,
                       round(t1.balance / 10000, 4) as zqme_w_v,
                       t1.balance as zqme,
                       t2.cfl_no,
                       t2.leg_no,
                       t2.pay_date,
                       t2.pay_rate,
                       trim(to_char(trunc(coalesce(abs(t2.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                       t2.position, t2.self_no,
                       t2.inter_cust_no,
                       t2.self_serial_no,
                       t2.rival_serial_no,
                       t2.fee_type,
                       t2.nominal_amt,
                       t2.cfl_type,
                       t1.invest_type
                  from tbinstcfl t2, tbcombi c, tbinstext t1
                 where t2.deal_serial_no = t1.deal_serial_no
                   and t1.combi_no = c.combi_no
                   and t1.version_no = t2.version_no
                   and t1.version_no = 0
                   and t1.status not in ('a', '0', '3')
                   and t1.dealing_status not in ('1', '5')
                   and t1.source_trade_flag = '0'
                   and t2.position = '2'
                   and t2.cfl_type = '2'
                   and t1.busin_type in ('H1', 'O1')
                   and t1.entrust_direction = '3'
                   ) t1
          left join tbrate r
         on r.deal_serial_no = t1.inter_code and r.start_date_adj < t1.pay_date and r.end_date_adj > t1.pay_date
         ,tbproduct p
          left join tbcombiprdext ext
            on p.inter_prd_code = ext.inter_prd_code
         where t1.inter_prd_code = p.inter_prd_code
           and p.model_flag in ('0', '2', '1')) v
  left join tbcustaccountinfo t1
    on v.self_serial_no = t1.serial_no
  left join tbcustaccountinfo t2
    on v.rival_serial_no = t2.serial_no
  left join tbstockinfo info
    on v.inter_code = info.inter_code
  left join tbproduct prd
    on v.inter_prd_code = prd.inter_prd_code
  left join tbsyscustinfo t3
    on v.inter_cust_no = t3.inter_cust_no
  left join tbbondproperty property
    on property.inter_code = v.inter_code
  left join tbrealdeal deal
    on v.deal_serial_no = deal.deal_serial_no
  left join vassetinfo views
    on v.inter_code = views.inter_code
union all
-- 瀛樻斁鍚屼笟瀛樻
select to_char(to_date(v.value_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.value_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.value_date, 'YYYYMMDD'), 'DD') as day0,
       '瀛樻斁鍚屼笟瀛樻' as ywsm,
       case when v.rate_v < 1 and v.rate_v != 0 then '0'||v.rate_v else to_char(v.rate_v) end || '%' as rate,
       to_char(to_date(v.value_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.value_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.value_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.value_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'YYYY-MM-DD') as end_date,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'YYYY') as year2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'MM') as month2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'DD') as day2,
       t2.account_name as skdwqc,
       t2.bank as skkhyh,
       t2.account as skzh,
       t1.account_name as fkdwqc,
       t1.bank as fkkhyh,
       t1.account as fkzh,
       t2.account_name as jyds,
       ' ' as quanz,
       v.zqme_w, to_char(v.zqme) as zqme, ' ' as zsbl, v.pay_amt as jine,
       prd.prd_name || '锛� || prd.prd_code || '锛夊悜' ||t3.cust_fullname||'瀛樻斁鍚屼笟瀛樻锛屽埄鐜�||case when v.rate_v < 1 and v.rate_v != 0 then '0'||v.rate_v else to_char(v.rate_v) end || '%锛屾湡闄�||
       to_char(to_date(to_char(v.maturity_date_adj), 'yyyyMMdd') - to_date(to_char(v.value_date), 'yyyyMMdd')) || '鏃ワ紝鍒版湡姹囨閲戦涓�||m.settle_amt||'鍏冦€� as yuany,
       v.pay_amt, v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, prd.prd_code, v.pay_date, '16' as flag
          from (select t1.*, round(coalesce(abs(var.fix_rate), 0), 4) as rate_v,
                case when t1.zqme_w_v < 1 and t1.zqme_w_v != 0 then '0'||t1.zqme_w_v else to_char(t1.zqme_w_v) end || '涓� as zqme_w
                  from (select
                           t1.maturity_date_adj,
                           t1.value_date,
                           t1.contract_no,
                               t1.deal_serial_no,
                               t1.inter_code,
                               t1.combi_no,
                               c.inter_prd_code,
                               t1.busin_class,
                               t1.busin_type,
                               t1.bank_no,
                               t1.balance,
                               round(t1.balance / 10000, 4) as zqme_w_v,
                               t1.balance as zqme,
                               t2.cfl_no,
                               t2.leg_no,
                               t2.pay_date,
                               t2.pay_rate,
                               trim(to_char(trunc(coalesce(abs(t2.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                               t2.position, t2.self_no,
                               t2.inter_cust_no,
                               t2.self_serial_no,
                               t2.rival_serial_no,
                               t2.fee_type,
                               t2.nominal_amt,
                               t2.cfl_type,
                               round(t2.nominal_amt/10000, 0) as nominal_amt_w,
                               t1.invest_type
                          from tbinstcfl t2, tbcombi c, tbinstext t1, tbproduct p
                         where t2.deal_serial_no = t1.deal_serial_no
                           and t1.combi_no = c.combi_no
                           and t1.version_no = t2.version_no
                           and t1.version_no = 0
                           and t1.status not in ('a', '0', '3')
                           and t1.dealing_status not in ('1', '5')
                           and t1.source_trade_flag = '0'
                           and t2.cfl_type = '2'
                           and t1.busin_class = '93'
                           and t2.first_maturity = '5'
                           and c.inter_prd_code = p.inter_prd_code
                          and p.model_flag in ('0', '2', '1')
                           ) t1
                      left join tbinstratevar var
                    on var.busin_no = t1.contract_no
                       ) v
          left join tbcustaccountinfo t1
            on v.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on v.rival_serial_no = t2.serial_no
          left join tbbranch branch
            on v.self_no = branch.branch_no
          left join tbstockinfo info
            on v.inter_code = info.inter_code
          left join vassetinfo info1
            on v.contract_no = info1.inter_code
          left join tbassetplan tp
            on v.inter_code = tp.inter_code
          left join tbproduct prd
            on v.inter_prd_code = prd.inter_prd_code
          left join tbsyscustinfo t3
            on v.inter_cust_no = t3.inter_cust_no
          left join tbbondproperty property
            on property.inter_code = v.inter_code
          left join tbrealdeal deal
            on v.deal_serial_no = deal.deal_serial_no
          left join tbrate views
            on views.is_bond = '0' and v.contract_no = views.deal_serial_no and views.start_date_adj < v.pay_date and views.end_date_adj > v.pay_date
        left join tbmmrealdeal m
            on m.deal_serial_no = v.deal_serial_no
union all
-- 瀛樻斁鍚屼笟鍒版湡
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '瀛樻斁鍚屼笟鍒版湡'||v.type||'鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.value_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.value_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.value_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.value_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'YYYY-MM-DD') as end_date,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'YYYY') as year2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'MM') as month2,
       to_char(to_date(v.maturity_date_adj, 'YYYYMMDD'), 'DD') as day2,
       t1.account_name as skdwqc,
       t1.bank as skkhyh,
       t1.account as skzh,
       t2.account_name as fkdwqc,
       t2.bank as fkkhyh,
       t2.account as fkzh,
       t3.cust_fullname as jyds,
       ' ' as quanz,
       ' ' as zqme_w, '' as zqme, ' ' as zsbl, v.pay_amt as jine,
       prd.prd_name || '锛� || prd.prd_code || '锛夐厤缃� ||t3.cust_fullname||'瀛樻斁鍚屼笟鍒版湡锛�||v.type||'鍒掑洖銆�  as yuany,
       v.pay_amt, v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, prd.prd_code, v.pay_date, '17' as flag
          from (select t1.*
                  from (select
                  t1.value_date,
                           t1.maturity_date_adj,
                           t1.contract_no,
                               t1.deal_serial_no,
                               t1.inter_code,
                               t1.combi_no,
                               c.inter_prd_code,
                               t1.busin_class,
                               t1.busin_type,
                               t1.bank_no,
                               t1.balance,
                               round(t1.balance / 10000, 0) as balance_w,
                               t2.cfl_no,
                               t2.leg_no,
                               t2.pay_date,
                               t2.pay_rate,
                               trim(to_char(trunc(coalesce(abs(t2.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                               t2.position, t2.self_no,
                               t2.inter_cust_no,
                               t2.self_serial_no,
                               t2.rival_serial_no,
                               t2.fee_type,
                               t2.nominal_amt,
                               t2.cfl_type,
                               round(t2.nominal_amt/10000, 0) as nominal_amt_w,
                               t1.invest_type,
                               case when t2.cfl_type = '2' then '鏈噾' else '鍒╂伅' end type
                          from tbinstcfl t2, tbcombi c, tbinstext t1
                         where t2.deal_serial_no = t1.deal_serial_no
                           and t1.combi_no = c.combi_no
                           and t1.version_no = t2.version_no
                           and t1.version_no = 0
                           and t1.status not in ('a', '0', '3')
                           and t1.dealing_status not in ('1', '5')
                           and t1.source_trade_flag = '0'
                           and t2.cfl_type in ('2', '3')
                           and t1.busin_class = '93'
                           and t2.first_maturity = '6'
                           ) t1,
                       tbproduct p
                 where t1.inter_prd_code = p.inter_prd_code
                   and p.model_flag in ('0', '2', '1')) v
          left join tbcustaccountinfo t1
            on v.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on v.rival_serial_no = t2.serial_no
          left join tbstockinfo info
            on v.inter_code = info.inter_code
          left join tbproduct prd
            on v.inter_prd_code = prd.inter_prd_code
          left join tbsyscustinfo t3
            on v.inter_cust_no = t3.inter_cust_no
          left join tbbondproperty property
            on property.inter_code = v.inter_code
          left join tbinstratevar var
            on var.busin_no = v.contract_no
          left join tbrealdeal deal
            on v.deal_serial_no = deal.deal_serial_no
          left join tbrate views
            on views.is_bond = '0' and v.contract_no = views.deal_serial_no and views.start_date_adj < v.pay_date and views.end_date_adj > v.pay_date
        left join tbmmrealdeal m
            on m.deal_serial_no = v.deal_serial_no
union all
--璁よ喘璧勪骇绠＄悊璁″垝
select
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '璁よ喘鎶曡祫绠＄悊璁″垝' as ywsm, v.rate as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       t2.account_name as skdwqc,
       t2.bank as skkhyh,
       t2.account as skzh,
       t1.account_name as fkdwqc,
       t1.bank as fkkhyh,
       t1.account as fkzh,
       t2.account_name as jyds,
       info.object_code as quanz,
       v.zqme_w, to_char(v.zqme) as zqme, ' ' as zsbl, v.pay_amt as jine,
       prd.prd_name || '鐞嗚储璁よ喘' || t3.cust_fullname ||info.object_code||'锛屽埄鐜�||v.rate||'锛屾湡闄�||
       to_char(to_date(to_char(tp.end_date), 'yyyyMMdd') - to_date(to_char(tp.value_date), 'yyyyMMdd'))||'澶┿€� as yuany, v.pay_amt,
       v.inter_prd_code , v.cfl_no,  v.deal_serial_no, to_char(v.leg_no) as leg_no, v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, prd.prd_code, v.pay_date, '18' as flag
  from (select t.*, case when t.rate_v < 1 and t.rate_v != 0 then '0'||t.rate_v else to_char(t.rate_v) end || '%' as rate,
        case when t.zqme_w_v < 1 and t.zqme_w_v != 0 then '0'||t.zqme_w_v else to_char(t.zqme_w_v) end || '涓� as zqme_w
          from (select ext.deal_serial_no,
                       ext.inter_code,
                       ext.combi_no,
                       bi.inter_prd_code,
                       ext.busin_class,
                       ext.busin_type,
                       ext.bank_no,
                       ext.balance,
                       round(ext.balance/10000, 4) as zqme_w_v,
                       ext.balance as zqme,
                       cfl.cfl_no,
                       cfl.leg_no,
                       cfl.pay_date,
                       cfl.pay_rate,
                       trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
                       cfl.position,
                       cfl.self_no,
                       cfl.inter_cust_no,
                       cfl.self_serial_no,
                       cfl.rival_serial_no,
                       cfl.fee_type,
                       cfl.nominal_amt,
                       cfl.cfl_type,
                       ext.invest_type,
                       round(coalesce(abs(views.pay_rate), 0), 4) rate_v
                  from tbinstext ext
                  left join tbinstcfl cfl
                    on cfl.deal_serial_no = ext.deal_serial_no
                   and cfl.version_no = ext.version_no
                  left join tbcombi bi
                    on ext.combi_no = bi.combi_no
                  left join tbrate views
            on ext.inter_code = views.deal_serial_no and views.is_bond = '0'  and views.start_date_adj < cfl.pay_date and views.end_date_adj > cfl.pay_date
                 where ext.version_no = 0
                   and ext.status not in ('a', '0', '3')
                   and ext.dealing_status not in ('1', '5')
                   and ext.source_trade_flag = '0'
                   and cfl.cfl_type = '2'
                   and cfl.position = '2'
                   and ext.busin_class = 'H1'
                   and ext.entrust_direction = 'r'
                   ) t
          left join tbproduct prd
            on prd.inter_prd_code = t.inter_prd_code
         where prd.model_flag in ('0', '2', '1')) v
  left join tbcustaccountinfo t1
    on v.self_serial_no = t1.serial_no
  left join tbcustaccountinfo t2
    on v.rival_serial_no = t2.serial_no
  left join tbbranch branch
    on v.self_no = branch.branch_no
  left join tbstockinfo info
    on v.inter_code = info.inter_code
  left join tbassetplan tp
    on v.inter_code = tp.inter_code
  left join tbproduct prd
    on v.inter_prd_code = prd.inter_prd_code
  left join tbsyscustinfo t3
    on v.inter_cust_no = t3.inter_cust_no
)t2
-- type3
union all
select t3.year0, t3.month0, t3.day0, t3.ywsm, t3.rate, t3.year1, t3.month1, t3.day1, t3.start_date, t3.end_date, t3.year2, t3.month2, t3.day2,
t3.skdwqc, t3.skkhyh, t3.skzh, t3.fkdwqc, t3.fkkhyh, t3.fkzh, t3.jyds, t3.quanz, t3.zqme_w, t3.zqme, t3.zsbl, t3.jine, t3.yuany, t3.pay_amt, t3.inter_prd_code , t3.cfl_no,  t3.deal_serial_no, t3.leg_no,
t3.inter_code, t3.combi_no, t3.invest_type , t3.prd_code, t3.pay_date, t3.flag
from (
-- 鐞嗚储璧勪骇鍒版湡鏈伅鍒掑洖
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鐞嗚储璧勪骇鍒版湡'||v.type||'鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夌悊璐㈣祫浜у埌鏈�||v.type||'鍒掑洖銆� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '1' as is_hf, v.prd_code, v.pay_date, '19' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               case when cfl.cfl_type = '2' then '鏈噾'
               else '鍒╂伅' end type,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               case when cfl.source_flag = '1' then non.object_code else asset.object_code end as object_code,
               case when cfl.source_flag = '1' then non.object_name else asset.object_name end as object_name,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbassetplan asset
            on asset.inter_code = cfl.inter_code
          left join tbnonstandard non
            on non.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.first_maturity = '6'
           and cfl.source_flag in ('1','2')
           and cfl.cfl_type in ('2', '3', '4')
           and case when cfl.source_flag = '1' then non.end_date
           else asset.end_date end <= ( select init_date from tbsysarg) ) v
  union all
-- 鐞嗚储璧勪骇鍒版湡鏈伅鍒掍粯
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鐞嗚储璧勪骇鍒版湡'||v.type||'鍒掍粯' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.df_account_name as skdwqc,
       v.df_bank as skkhyh,
       v.df_account as skzh,
       v.bf_account_name as fkdwqc,
       v.bf_bank as fkkhyh,
       v.bf_account as fkzh,
       ' ' as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犲悜'||v.prd_name || '锛� || v.prd_code || '锛夊垝浠樼悊璐㈣祫浜у埌鏈�||v.type||'銆� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '1' as is_hf, v.prd_code, v.pay_date, '20' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               case when cfl.cfl_type = '2' then '鏈噾'
               else '鍒╂伅' end type,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               case when cfl.source_flag = '1' then non.object_code else asset.object_code end as object_code,
               case when cfl.source_flag = '1' then non.object_name else asset.object_name end as object_name,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbassetplan asset
            on asset.inter_code = cfl.inter_code
          left join tbnonstandard non
            on non.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.first_maturity = '6'
           and cfl.source_flag in ('1','2')
           and cfl.cfl_type in ('2', '3', '4')
           and case when cfl.source_flag = '1' then non.end_date
           else asset.end_date end <= ( select init_date from tbsysarg) ) v
    union all
-- 璧勪骇姹犵悊璐㈣祫浜у埌鏈熸湰鎭垝浠�select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '璧勪骇姹犵悊璐㈣祫浜у埌鏈�||v.type||'鍒掍粯' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.df_account_name as skdwqc,
       v.df_bank as skkhyh,
       v.df_account as skzh,
       v.bf_account_name as fkdwqc,
       v.bf_bank as fkkhyh,
       v.bf_account as fkzh,
       v.df_account_name as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犵悊璐㈣祫浜у埌鏈�||v.type||'鍒掑洖銆� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '1' as is_hf, v.prd_code, v.pay_date, '21' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               case when cfl.cfl_type = '2' then '鏈噾'
               else '鍒╂伅' end type,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               case when cfl.source_flag = '1' then non.object_code else asset.object_code end as object_code,
               case when cfl.source_flag = '1' then non.object_name else asset.object_name end as object_name,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t3.bank bf_bank, t3.account bf_account, t3.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbcustaccountinfo t3
            on t3.serial_no = t1.mother_trustee_account
          left join tbassetplan asset
            on asset.inter_code = cfl.inter_code
          left join tbnonstandard non
            on non.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.first_maturity = '6'
           and cfl.source_flag in ('1','2')
           and cfl.cfl_type in ('2', '3', '4')
           and case when cfl.source_flag = '1' then non.end_date
           else asset.end_date end <= ( select init_date from tbsysarg) ) v
--鍊哄埜璧勪骇鍒╂伅鍒掑洖
union all
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鍊哄埜璧勪骇鍒╂伅鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夊€哄埜璧勪骇鍒╂伅鍒掑洖銆� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '28' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               info.stock_fullname as object_name,
               info.bond_code as object_code,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbbondproperty info
            on info.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.cfl_type = '3'
           and cfl.source_flag = '0'
           and info.end_date > ( select init_date from tbsysarg) ) v
  union all
--鍊哄埜璧勪骇鍒╂伅鍒掍粯
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鍊哄埜璧勪骇鍒╂伅鍒掍粯' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.df_account_name as skdwqc,
       v.df_bank as skkhyh,
       v.df_account as skzh,
       v.bf_account_name as fkdwqc,
       v.bf_bank as fkkhyh,
       ' ' as fkzh,
       ' ' as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犲悜'||v.prd_name || '锛� || v.prd_code || '锛夊垝浠樺€哄埜璧勪骇鍒╂伅銆� as yuany,
       v.pay_amt, v.inter_prd_code, v.cfl_no, ' ' deal_serial_no, '0' as leg_no, v.inter_code,
       v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '29' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               info.stock_fullname as object_name,
               info.bond_code as object_code,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbbondproperty info
            on info.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.remark ='HKYH707'
           and cfl.position = '2'
           and cfl.cfl_type = '3'
           and cfl.source_flag = '0'
           and info.end_date > ( select init_date from tbsysarg) ) v
union all
--璧勪骇姹犲€哄埜璧勪骇鍒╂伅鍒掑洖
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '璧勪骇姹犲€哄埜璧勪骇鍒╂伅鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犲€哄埜璧勪骇鍒╂伅鍒掑洖銆� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '1' as is_hf, v.prd_code, v.pay_date, '30' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               info.stock_fullname as object_name,
               info.bond_code as object_code,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t3.bank bf_bank, t3.account bf_account, t3.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbcustaccountinfo t3
            on t3.serial_no = t1.mother_trustee_account
          left join tbbondproperty info
            on info.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.remark ='HKYH707'
           and cfl.position = '1'
           and cfl.cfl_type = '3'
           and cfl.source_flag = '0'
           and info.end_date > ( select init_date from tbsysarg) ) v
-- 鍊哄埜璧勪骇杩樻湰璧勯噾鍒掑洖
  union all
  select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鍊哄埜璧勪骇杩樻湰璧勯噾鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夊€哄埜璧勪骇杩樻湰璧勯噾鍒掑洖銆� as yuany,
       v.pay_amt, v.inter_prd_code, v.cfl_no, ' ' deal_serial_no, '0' as leg_no, v.inter_code,
       v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '31' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               info.object_name,
               info.object_code,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.nominal_amt,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbstockinfo info
            on info.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.first_maturity = '7'
           and cfl.cfl_type = '2'
              and cfl.source_flag = '0') v
 union all
 -- 鍊哄埜璧勪骇杩樻湰璧勯噾鍒掍粯
     select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鍊哄埜璧勪骇杩樻湰璧勯噾鍒掍粯' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.df_account_name as skdwqc,
       v.df_bank as skkhyh,
       v.df_account as skzh,
       v.bf_account_name as fkdwqc,
       ' ' as fkkhyh,
       v.bf_account as fkzh,
       ' ' as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犲悜'||v.prd_name || '锛� || v.prd_code || '锛夊垝浠樺€哄埜璧勪骇杩樻湰璧勯噾銆� as yuany,
       v.pay_amt, v.inter_prd_code, v.cfl_no, ' ' deal_serial_no, '0' as leg_no, v.inter_code,
       v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '32' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               info.object_name,
               info.object_code,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbstockinfo info
            on info.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.first_maturity = '7'
           and cfl.cfl_type = '2'
              and cfl.source_flag = '0') v
 union all
 -- 璧勪骇姹犲€哄埜璧勪骇杩樻湰璧勯噾鍒掑洖
   select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '璧勪骇姹犲€哄埜璧勪骇杩樻湰璧勯噾鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犲€哄埜璧勪骇杩樻湰璧勯噾鍒掑洖銆� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '1' as is_hf, v.prd_code, v.pay_date, '33' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               info.object_name,
               info.object_code,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t3.bank bf_bank, t3.account bf_account, t3.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t3.bank as self_bank,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
      left join tbcustaccountinfo t3
            on t3.serial_no = t1.mother_trustee_account
          left join tbstockinfo info
            on info.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.first_maturity = '7'
           and cfl.cfl_type = '2'
           and cfl.source_flag = '0') v
  union all
-- 鐞嗚储璧勪骇鍒╂伅鍒掑洖
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鐞嗚储璧勪骇鍒╂伅鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夌悊璐㈣祫浜у埄鎭垝鍥炪€� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '22' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               case when cfl.cfl_type = '2' then '鏈噾'
               else '鍒╂伅' end type,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               case when cfl.source_flag = '1' then non.object_code else asset.object_code end as object_code,
               case when cfl.source_flag = '1' then non.object_name else asset.object_name end as object_name,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbassetplan asset
            on asset.inter_code = cfl.inter_code
          left join tbnonstandard non
            on non.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.source_flag in ('1','2')
           and cfl.cfl_type in ('3')
           and case when cfl.source_flag = '1' then non.end_date
           else asset.end_date end > ( select init_date from tbsysarg) ) v
union all
-- 鐞嗚储璧勪骇鍒╂伅鍒掍粯
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鐞嗚储璧勪骇鍒╂伅鍒掍粯' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.df_account_name as skdwqc,
       v.df_bank as skkhyh,
       v.df_account as skzh,
       v.bf_account_name as fkdwqc,
       v.bf_bank as fkkhyh,
       v.bf_account as fkzh,
       ' ' as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犲悜'||v.prd_name || '锛� || v.prd_code || '锛夊垝浠樼悊璐㈣祫浜у埄鎭€� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '23' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               case when cfl.cfl_type = '2' then '鏈噾'
               else '鍒╂伅' end type,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               case when cfl.source_flag = '1' then non.object_code else asset.object_code end as object_code,
               case when cfl.source_flag = '1' then non.object_name else asset.object_name end as object_name,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbassetplan asset
            on asset.inter_code = cfl.inter_code
          left join tbnonstandard non
            on non.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.source_flag in ('1','2')
           and cfl.cfl_type in ('3')
           and case when cfl.source_flag = '1' then non.end_date
           else asset.end_date end > ( select init_date from tbsysarg) ) v
union all
-- 璧勪骇姹犵悊璐㈣祫浜у埄鎭垝鍥�select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '璧勪骇姹犵悊璐㈣祫浜у埄鎭垝鍥� as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犵悊璐㈣祫浜у埄鎭垝鍥炪€� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '1' as is_hf, v.prd_code, v.pay_date, '24' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               case when cfl.cfl_type = '2' then '鏈噾'
               else '鍒╂伅' end type,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               case when cfl.source_flag = '1' then non.object_code else asset.object_code end as object_code,
               case when cfl.source_flag = '1' then non.object_name else asset.object_name end as object_name,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t3.bank bf_bank, t3.account bf_account, t3.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1, cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbcustaccountinfo t3
            on t3.serial_no = t1.mother_trustee_account
          left join tbassetplan asset
            on asset.inter_code = cfl.inter_code
          left join tbnonstandard non
            on non.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.source_flag in ('1','2')
           and cfl.cfl_type in ('3')
           and case when cfl.source_flag = '1' then non.end_date
           else asset.end_date end > ( select init_date from tbsysarg) ) v
  union all
--鍊哄埜鍒版湡鏈伅鍒掑洖
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鍊哄埜鍒版湡'||v.type||'鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2,
       ' ' as month2,
       ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夊€哄埜鍒版湡'||v.type||'鍒掑洖銆� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '25' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               case when cfl.cfl_type = '2' then '鏈噾'
         else '鍒╂伅' end type,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               info.stock_fullname as object_name,
               info.bond_code as object_code,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbbondproperty info
            on info.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
       and cfl.first_maturity = '6'
           and cfl.source_flag = '0'
       and cfl.cfl_type in ('2', '3', '4')
           and info.end_date <= ( select init_date from tbsysarg) ) v
  union all
--鍊哄埜鍒版湡鏈伅鍒掍粯
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鍊哄埜鍒版湡'||v.type||'鍒掍粯' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       v.df_account_name as skdwqc,
       v.df_bank as skkhyh,
       v.df_account as skzh,
       v.bf_account_name as fkdwqc,
       v.bf_bank as fkkhyh,
       v.bf_account as fkzh,
       ' ' as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犲悜'||v.prd_name || '锛� || v.prd_code || '锛夊垝浠樺€哄埜鍒版湡'||v.type||'銆� as yuany,
       v.pay_amt, v.inter_prd_code, v.cfl_no, ' ' deal_serial_no, '0' as leg_no,
       v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '26' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               case when cfl.cfl_type = '2' then '鏈噾'
         else '鍒╂伅' end type,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               info.stock_fullname as object_name,
               info.bond_code as object_code,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbbondproperty info
            on info.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
       and cfl.first_maturity = '6'
           and cfl.source_flag = '0'
       and cfl.cfl_type in ('2', '3', '4')
           and info.end_date <= ( select init_date from tbsysarg) ) v
  union all
--璧勪骇姹犲€哄埜鍒版湡鏈伅鍒掑洖
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '璧勪骇姹犲€哄埜鍒版湡'||v.type||'鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犲€哄埜鍒版湡'||v.type||'鍒掑洖銆� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '1' as is_hf, v.prd_code, v.pay_date, '27' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               case when cfl.cfl_type = '2' then '鏈噾'
         else '鍒╂伅' end type,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               info.stock_fullname as object_name,
               info.bond_code as object_code,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t3.bank bf_bank, t3.account bf_account, t3.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
      left join tbcustaccountinfo t3
            on t3.serial_no = t1.mother_trustee_account
          left join tbbondproperty info
            on info.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
       and cfl.first_maturity = '6'
           and cfl.source_flag = '0'
       and cfl.cfl_type in ('2', '3', '4')
           and info.end_date <= ( select init_date from tbsysarg) ) v
  union all
-- 鐞嗚储璧勪骇杩樻湰璧勯噾鍒掑洖
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鐞嗚储璧勪骇杩樻湰璧勯噾鍒掑洖' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       v.prd_name || '锛� || v.prd_code || '锛夌悊璐㈣祫浜ц繕鏈祫閲戝垝鍥炪€� as yuany,
       v.pay_amt,
       v.inter_prd_code,
       v.cfl_no,
       ' ' deal_serial_no,
       '0' as leg_no,
       v.inter_code,
       v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '34' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               case when cfl.source_flag = '1' then non.object_code else asset.object_code end as object_code,
               case when cfl.source_flag = '1' then non.object_name else asset.object_name end as object_name,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbassetplan asset
            on asset.inter_code = cfl.inter_code
          left join tbnonstandard non
            on non.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.first_maturity = '7'
           and cfl.source_flag in ('1','2')
           and case when cfl.source_flag = '1' then non.end_date
           else asset.end_date end > ( select init_date from tbsysarg) ) v
union all
-- 鐞嗚储璧勪骇杩樻湰璧勯噾鍒掍粯
select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '鐞嗚储璧勪骇杩樻湰璧勯噾鍒掍粯' as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,
       ' ' as year2, ' ' as month2, ' ' as day2,
       v.df_account_name as skdwqc,
       v.df_bank as skkhyh,
       v.df_account as skzh,
       v.bf_account_name as fkdwqc,
       v.bf_bank as fkkhyh,
       v.bf_account as fkzh,
       ' ' as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犲悜'||v.prd_name || '锛� || v.prd_code || '锛夊垝浠樼悊璐㈣祫浜ц繕鏈祫閲戙€� as yuany,
       v.pay_amt, v.inter_prd_code, v.cfl_no, ' ' deal_serial_no, '0' as leg_no,
       v.inter_code, v.combi_no, v.invest_type, '0' as is_hf, v.prd_code, v.pay_date, '35' as flag
  from (select prd.prd_name,
               prd.prd_code,
               cfl.pay_date,
               cfl.end_date,
               cfl.combi_no,
               cfl.nominal_amt,
               case when cfl.source_flag = '1' then non.object_code else asset.object_code end as object_code,
               case when cfl.source_flag = '1' then non.object_name else asset.object_name end as object_name,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t1.bank bf_bank, t1.account bf_account, t1.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1,
               cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
          left join tbassetplan asset
            on asset.inter_code = cfl.inter_code
          left join tbnonstandard non
            on non.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.first_maturity = '7'
           and cfl.source_flag in ('1','2')
           and case when cfl.source_flag = '1' then non.end_date
           else asset.end_date end > ( select init_date from tbsysarg) ) v
union all
-- 璧勪骇姹犵悊璐㈣祫浜ц繕鏈祫閲戝垝鍥�select to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month0,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day0,
       '璧勪骇姹犵悊璐㈣祫浜ц繕鏈祫閲戝垝鍥� as ywsm,
       ' ' as rate,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY') as year1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'MM') as month1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'DD') as day1,
       to_char(to_date(v.pay_date, 'YYYYMMDD'), 'YYYY-MM-DD') as start_date,
       '' as end_date,' ' as year2,' ' as month2,' ' as day2,
       v.bf_account_name as skdwqc,
       v.bf_bank as skkhyh,
       v.bf_account as skzh,
       v.df_account_name as fkdwqc,
       v.df_bank as fkkhyh,
       v.df_account as fkzh,
       v.df_account_name as jyds,
       v.object_code as quanz,
       case when v.zqme_w < 1 and v.zqme_w != 0 then '0'||v.zqme_w else to_char(v.zqme_w) end || '涓� as zqme_w ,
       to_char(v.zqme) as zqme,
       ' ' as zsbl,
       v.pay_amt as jine,
       '璧勪骇姹犵悊璐㈣祫浜ц繕鏈祫閲戝垝鍥炪€� as yuany,
       v.pay_amt,v.inter_prd_code,v.cfl_no,' ' deal_serial_no,'0' as leg_no,v.inter_code,
       v.combi_no, v.invest_type, '1' as is_hf, v.prd_code, v.pay_date, '36' as flag
  from (select prd.prd_name, prd.prd_code, cfl.pay_date, cfl.end_date, cfl.combi_no, cfl.nominal_amt,
               case when cfl.source_flag = '1' then non.object_code else asset.object_code end as object_code,
               case when cfl.source_flag = '1' then non.object_name else asset.object_name end as object_name,
               round(cfl.nominal_amt / 10000, 4) as zqme_w,
               cfl.nominal_amt as zqme,
               cfl.inter_code,
               bi.inter_prd_code,
               t3.bank bf_bank, t3.account bf_account, t3.account_name bf_account_name,t2.bank df_bank, t2.account df_account, t2.account_name df_account_name,
               t1.inter_cust_no inter_cust_no1, cfl.cfl_no,
               trim(to_char(trunc(coalesce(abs(cfl.pay_amt), 0), 2), '999999999990.99')) as pay_amt,
               cfl.invest_type
          from tbunitcfl cfl
          left join tbcombi bi
            on bi.combi_no = cfl.combi_no
          left join tbproduct prd
            on prd.inter_prd_code = bi.inter_prd_code
          left join tbcustaccountinfo t1
            on cfl.self_serial_no = t1.serial_no
          left join tbcustaccountinfo t2
            on cfl.rival_serial_no = t2.serial_no
      left join tbcustaccountinfo t3
            on t3.serial_no = t1.mother_trustee_account
          left join tbassetplan asset
            on asset.inter_code = cfl.inter_code
          left join tbnonstandard non
            on non.inter_code = cfl.inter_code
         where prd.model_flag in ('0', '2', '1')
           and cfl.cash_settle_status <> '5'
           and cfl.position = '1'
           and cfl.first_maturity = '7'
           and cfl.source_flag in ('1','2')
           and case when cfl.source_flag = '1' then non.end_date
           else asset.end_date end > ( select init_date from tbsysarg) ) v
  ) t3
) r
with read only
/

