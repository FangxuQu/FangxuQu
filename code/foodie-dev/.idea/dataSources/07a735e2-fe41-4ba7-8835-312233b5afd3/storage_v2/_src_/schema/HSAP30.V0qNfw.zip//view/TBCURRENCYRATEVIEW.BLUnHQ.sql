create view TBCURRENCYRATEVIEW as
select r.trans_date trans_date,
             r.curr_source curr_source,
             r.curr_target curr_target,
             r.mid_price/p.quoted_unit mid_price
      from tbcurrencypair p , tbcurrencyrate r where p.currency_pair = r.curr_source ||'/'||r.curr_target
      union
      select r.trans_date trans_date,
             r.curr_source curr_source,
             r.curr_target curr_target,
             r.mid_price*p.quoted_unit mid_price
      from tbcurrencypair p , tbcurrencyrate r where p.currency_pair = r.curr_target ||'/'||r.curr_source
with read only
/

