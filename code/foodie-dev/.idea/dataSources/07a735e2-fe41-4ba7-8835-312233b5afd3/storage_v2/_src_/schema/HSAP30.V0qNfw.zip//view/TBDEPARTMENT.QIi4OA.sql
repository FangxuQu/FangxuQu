create view TBDEPARTMENT as
select
   dep_code  dep_id,
   dep_name  dep_name,
   short_name short_name,
   parent_code  parent_id,
   branch_code  branch_no,
   dep_path     internal_depid
from
   tsys_dep
/

