create view TBJBPM4_TODO_TASK as
select distinct
        to_char(t.create_,'yyyy-mm-dd HH24:mi:ss:ff') as create_datetime, --  浠诲姟鍒涘缓鏃堕棿
        substr(p.groupid_, 0, instr(p.groupid_, ':') - 1) as grouptype_,--  浠诲姟鍊欓€夌兢缁勭被鍨�        substr(p.groupid_, instr(p.groupid_, ':') + 1) as groupid_,--  浠诲姟鍊欓€夌兢缁刬d
        p.userid_ as assignee_,--  鐢ㄦ埛id
        t.activity_name_ as activity_name_,--  鑺傜偣鍚�        t.dbid_ as id_,--  浠诲姟id
        'S' as tasktype_,--  s:寰呯浠诲姟
        histp.id_ as hsbpm_instance_,--  娴佺▼瀹炰緥鍙�        histp.dbid_ as instancedbid_,--  瀹炰緥鐗╃悊涓婚敭
        histp.state_ as state_--  瀹炰緥鐘舵€�    from
        jbpm4_hist_procinst histp left join
        jbpm4_task t on (histp.dbid_ = t.procinst_ and t.state_ != 'completed' and t.assignee_ is  null)
       left join jbpm4_participation p on t.dbid_ = p.task_
    where  histp.end_ is  null
union all
--  鏈夋寚瀹氫汉鐨勫緟鍔炰换鍔�    select
        to_char(t.create_,'yyyy-mm-dd HH24:mi:ss:ff') as create_datetime, --  浠诲姟鍒涘缓鏃堕棿
        '' as grouptype_,
        '' as groupid_,
        t.assignee_ as assignee_,
        t.activity_name_ as activity_name_,
        t.dbid_ as id_,
        'A' as tasktype_,--  a:鎸囧畾鐨勫緟鍔炰换鍔�        histp.id_ as hsbpm_instance_,
        histp.dbid_ as instancedbid_,
        histp.state_ as state_
    from jbpm4_hist_procinst histp ,jbpm4_task t
    where
        histp.end_ is  null
        and t.assignee_ is not null
    and t.procinst_ = histp.dbid_ and t.state_ != 'completed'
union all
--  浠ｇ悊浜哄緟绛句换鍔�    select
        to_char(t.create_,'yyyy-mm-dd HH24:mi:ss:ff') as create_datetime, --  浠诲姟鍒涘缓鏃堕棿
        '' as grouptype_,
        '' as groupid_,
        p.agent_userid_ as assignee_,
        t.activity_name_ as activity_name_,
        t.dbid_ as id_,
        'S' as tasktype_,--  s:寰呯浠诲姟
        histp.id_ as hsbpm_instance_,
        histp.dbid_ as instancedbid_,
        histp.state_ as state_
    from
        jbpm4_hist_procinst histp
        left join jbpm4_task          t on (histp.dbid_ = t.procinst_ and t.state_ != 'completed' and t.assignee_ is  null)
        left join jbpm4_participation p on t.dbid_ = p.task_
    where  histp.end_ is  null and p.agent_userid_ is not null
union all
--  浠ｇ悊浜虹殑寰呭姙浠诲姟
    select
        to_char(t.create_,'yyyy-mm-dd HH24:mi:ss:ff') as create_datetime, --  浠诲姟鍒涘缓鏃堕棿
        '' as grouptype_,
        '' as groupid_,
        p.agent_userid_ as assignee_,
        t.activity_name_ as activity_name_,
        t.dbid_ as id_,
        'A' as tasktype_,--  a:鎸囧畾鐨勫緟鍔炰换鍔�        histp.id_ as hsbpm_instance_,
        histp.dbid_ as instancedbid_,
        histp.state_ as state_
    from jbpm4_hist_procinst histp ,jbpm4_task t,jbpm4_participation p
    where
        histp.end_ is  null
        and  t.assignee_ is not null
        and p.task_ = t.dbid_
        and p.agent_userid_ is not null
        and t.procinst_ = histp.dbid_ and t.state_ != 'completed'
with read only
/

