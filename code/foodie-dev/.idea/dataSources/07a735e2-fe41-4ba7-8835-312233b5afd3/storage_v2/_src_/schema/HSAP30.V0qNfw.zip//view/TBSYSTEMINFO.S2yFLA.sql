create view TBSYSTEMINFO as
select bank_no as bank_no,prev_date as last_init_date,init_date as init_date,host_check_date as host_check_date from tbsysarg
with read only
/

