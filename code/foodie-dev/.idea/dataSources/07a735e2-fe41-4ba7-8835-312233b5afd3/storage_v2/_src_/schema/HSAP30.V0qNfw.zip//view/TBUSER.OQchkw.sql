create view TBUSER as
select  user_id user_id,
   branch_code branch_no,
   user_name user_name
from
   tsys_user
with read only
/

