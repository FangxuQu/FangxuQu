create view VASSETINFO as
select ' ' as bank_no, '11' as asset_type,a.bond_code as asset_code,a.inter_code as inter_code,a.book_market as market_no,a.stock_name as asset_short_name,a.stock_fullname as asset_full_name,stock_type as asset_sub_type,
       a.curr_type as curr_type,a.pay_interest_type as pay_interest_type,' ' as profit_type,' ' as sub_code,'1' cal_direction,a.value_date as value_date,a.end_date as end_date
from tbbondproperty a
union all
select ' ' as bank_no,case when b.qdii_flag = '1' then 'F2' else 'F1' end as asset_type, b.fund_code as asset_code,b.inter_code as inter_code,b.trans_place as market_no,b.fund_name as asset_short_name,b.fund_name as asset_full_name,b.fund_type as asset_sub_type,
       b.curr_type as curr_type,' ' as pay_interest_type,quoted_type as profit_type,' ' as sub_code,'1' cal_direction,case b.found_date when 0 then 10000101 else b.found_date end as value_date,case b.end_date when 0 then 30000101 else b.end_date end as end_date
from tbfund b
union all
select ' ' bank_no,'N1' as asset_type,t.bill_code as asset_code,t.inter_code as inter_code,' ' as market_no,t.bill_name as asset_short_name,t.bill_name as asset_full_name,' ' as asset_sub_type,
       t.curr_type,  '2' as pay_interest_type,' ' as profit_type,' ' as sub_code,'1' cal_direction,t.value_date,t.end_date
from tbstructurebill t
union all
select c.bank_no bank_no,'O1' as asset_type, c.object_code as asset_code,c.inter_code as inter_code,' ' as market_no,c.object_sname as asset_short_name,c.object_name as asset_full_name,c.sub_code as asset_sub_type,
       c.curr_type as curr_type, case when q.pay_freq is null then ' ' when q.pay_freq ='T' then '1' else '2' end as pay_interest_type ,' ' as profit_type,' ' as sub_code,'1' cal_direction,c.value_date as value_date,c.end_date as end_date
from tbnonstandard c left join tbinstrate q on c.inter_code = q.busin_no and q.leg_no=1 and q.version_no =0
union all
select x.bank_no bank_no,'X1' as asset_type, x.object_code as asset_code,x.inter_code as inter_code,' ' as market_no,x.object_sname as asset_short_name,x.object_name as asset_full_name,x.sub_code as asset_sub_type,
       x.curr_type as curr_type, case when q.pay_freq is null then ' ' when q.pay_freq ='T' then '1' else '2' end as pay_interest_type ,' ' as profit_type,' ' as sub_code,'1' cal_direction,x.value_date as value_date,x.end_date as end_date
from tbcredittransfer x left join tbinstrate q on x.inter_code = q.busin_no and q.leg_no=1 and q.version_no =0
union all
select d.bank_no bank_no,'H1' as asset_type,d.object_code as asset_code,d.inter_code as inter_code,' ' as market_no,d.object_sname as asset_short_name,d.object_name as asset_full_name,d.sub_code as asset_sub_type,
       d.curr_type as curr_type, case when q.pay_freq is null then ' ' when q.pay_freq ='T' then '1' else '2' end as pay_interest_type,profit_type,' ' as sub_code,'1' cal_direction,d.value_date as value_date,d.end_date as end_date
from tbassetplan d left join tbinstrate q on d.inter_code = q.busin_no and q.leg_no=1 and q.version_no =0
union all
select e.bank_no as bank_no,e.busin_type as asset_type,(case e.deal_asso_serial when ' ' then e.contract_no else e.deal_asso_serial end )  as asset_code,e.contract_no as inter_code,' 'as market_no,e.contract_name as asset_short_name,e.contract_name as asset_full_name,e.sub_code2 as asset_sub_type,
       e.curr_type as curr_type, case when q.pay_freq is null then ' ' when q.pay_freq ='T' then '1' else '2' end as pay_interest_type,' ' as profit_type,sub_code,l.account_asset_flag cal_direction,case e.busin_type when '31' then e.value_date else e.ori_value_date end as value_date,e.maturity_date as end_date
from tbinstext e left join tbinstrate q on e.contract_no = q.busin_no and q.leg_no=1 and q.version_no =0
left join tbbusintype l on e.busin_class = l.busin_class
where e.source_trade_flag='1' and e.unit_trade_flag='1' and e.status!='3' and e.busin_type in ('90','94','35','95','31','37')
union all
select v.bank_no,v.asset_type,v.asset_code,v.inter_code,v.market_no,v.asset_short_name,v.asset_full_name,v.asset_sub_type,v.curr_type,v.pay_interest_type,v.profit_type,v.sub_code,v.cal_direction,m.value_date,v.end_date
from (select distinct e.bank_no as bank_no,e.busin_type as asset_type,(case e.deal_asso_serial when ' ' then e.contract_no else e.deal_asso_serial end ) as asset_code, e.contract_no  as inter_code,' 'as market_no,e.contract_name as asset_short_name,e.contract_name as asset_full_name,e.sub_code2 as asset_sub_type,
       e.curr_type as curr_type, case when q.pay_freq is null then ' ' when q.pay_freq ='T' then '1' else '2' end as pay_interest_type,' ' as profit_type,sub_code,l.account_asset_flag cal_direction,e.maturity_date as end_date
from tbinstext e left join tbinstrate q on e.contract_no = q.busin_no and q.leg_no=1 and q.version_no =0
left join tbbusintype l on e.busin_class = l.busin_class
where e.unit_trade_flag='1' and e.status!='3' and e.busin_type ='93' and (e.sub_code ='1' or (e.sub_code='2' and e.source_trade_flag='1')))v,
(select min(ori_value_date) value_date, contract_no  from tbinstext where unit_trade_flag='1' and status!='3' and busin_type ='93' and (sub_code ='1' or (sub_code='2' and source_trade_flag='1')) group by contract_no) m
where v.inter_code=m.contract_no
union all
select e.bank_no as bank_no,e.busin_type as asset_type,(case e.deal_asso_serial when ' ' then e.contract_no else e.deal_asso_serial end ) as asset_code, e.contract_no  as inter_code,' 'as market_no,e.contract_name as asset_short_name,e.contract_name as asset_full_name,y.stock_type as asset_sub_type,
       e.curr_type as curr_type, case when q.pay_freq is null then ' ' when q.pay_freq ='T' then '1' else '2' end as pay_interest_type,' ' as profit_type,sub_code,l.account_asset_flag cal_direction,e.value_date as value_date,e.maturity_date as end_date
from tbinstext e left join tbinstrate q on e.contract_no = q.busin_no and q.leg_no=1 and q.version_no =0
left join tbbondproperty y on e.inter_code = y.inter_code
left join tbbusintype l on e.busin_class = l.busin_class
where e.source_trade_flag='1' and e.unit_trade_flag='1' and e.status!='3' and e.busin_type = '33'
union
select e.bank_no as bank_no, e.busin_type as asset_type, (case e.deal_asso_serial when ' ' then e.contract_no else e.deal_asso_serial end ) as asset_code,  e.contract_no  as inter_code, ' ' as market_no, e.contract_name as asset_short_name,e.contract_name as asset_full_name, ' ' as asset_sub_type,
       e.curr_type as curr_type, ' ' as pay_interest_type, ' ' as profit_type, sub_code, l.account_asset_flag cal_direction, e.value_date as value_date, e.maturity_date_adj as end_date
  from tbinstext e  left join tbbusintype l on e.busin_class = l.busin_class
 where e.source_trade_flag = '1' and e.unit_trade_flag = '1' and e.status != '3' and e.busin_type in ('92')
union
select e.bank_no as bank_no, e.busin_type as asset_type, (case e.deal_asso_serial when ' ' then e.contract_no else e.deal_asso_serial end ) as asset_code,  e.contract_no  as inter_code, ' ' as market_no, e.contract_name as asset_short_name,e.contract_name as asset_full_name, ' ' as asset_sub_type,
       e.curr_type as curr_type, ' ' as pay_interest_type, ' ' as profit_type, sub_code, l.account_asset_flag cal_direction, e.trans_date as value_date, e.maturity_date_adj as end_date
  from tbinstext e  left join tbbusintype l on e.busin_class = l.busin_class
 where e.source_trade_flag = '1' and e.unit_trade_flag = '1' and e.status != '3' and e.busin_type in ('B1', 'BA', 'B2', 'BB', 'B3', 'BC')
with read only
/

comment on table VASSETINFO is 'vassetinfo鍩烘湰淇℃伅瑙嗗浘
'
/

comment on column VASSETINFO.BANK_NO is '閾惰缂栧彿'
/

comment on column VASSETINFO.ASSET_TYPE is '璧勪骇绫诲瀷'
/

comment on column VASSETINFO.ASSET_CODE is '璧勪骇浠ｇ爜'
/

comment on column VASSETINFO.INTER_CODE is '璧勪骇鍐呯爜'
/

comment on column VASSETINFO.MARKET_NO is '娴侀€氬競鍦猴紙浜ゆ槗甯傚満锛'
/

comment on column VASSETINFO.ASSET_SHORT_NAME is '璧勪骇绠€绉'
/

comment on column VASSETINFO.ASSET_FULL_NAME is '璧勪骇鍏ㄧО'
/

comment on column VASSETINFO.ASSET_SUB_TYPE is '璧勪骇瀛愮被鍨'
/

comment on column VASSETINFO.CURR_TYPE is '甯佺'
/

comment on column VASSETINFO.PAY_INTEREST_TYPE is '浠樻伅绫诲瀷'
/

comment on column VASSETINFO.PROFIT_TYPE is '鏀剁泭绫诲瀷'
/

comment on column VASSETINFO.SUB_CODE is '涓氬姟缁嗗垎鐮'
/

comment on column VASSETINFO.CAL_DIRECTION is '璧勪骇璐熷€烘爣蹇'
/

