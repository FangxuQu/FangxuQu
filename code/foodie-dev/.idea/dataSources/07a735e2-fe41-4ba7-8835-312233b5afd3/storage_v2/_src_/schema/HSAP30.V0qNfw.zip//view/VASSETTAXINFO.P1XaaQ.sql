create view VASSETTAXINFO as
select t.inter_code,c.is_tax,t.bond_code as asset_code,t.stock_type as stock_type from tbbondproperty t ,tbbondtax c where t.stock_type=c.stock_type
union all
select t.inter_code,case when is_guaranteed = '1' then '1' else '0' end as is_tax ,fund_code as asset_code ,' 'as stock_type from  tbfund t
union all
select t.inter_code,case when is_guaranteed = '1' then '1' else '0' end as is_tax, object_code as asset_code,' 'as stock_type from tbassetplan t
union all
select t.inter_code,case when is_guaranteed = '1' then '1' else '0' end as is_tax, object_code as asset_code ,' 'as stock_type from tbnonstandard t
union all
select e.contract_no as inter_code ,'0' as is_tax, e.contract_no as asset_code,' ' as stock_type from tbinstext e where e.version_no=0
and e.source_trade_flag='1' and e.unit_trade_flag='1' and e.status!='3' and e.sub_code != '1'
with read only
/

