create view VMARKETINFO as
select ta_code as market_code, ta_name as market_name, prd_type from tbtainfo
/

