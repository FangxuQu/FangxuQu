create view VPRDRIGHT as
select '1' as data_type,virtual_combi_no as code,inter_virtual_combi as inter_code from tbvirtualcombi
  union all
  select '2' as data_type,branch_code as code,branch_path as inter_code from tsys_branch
  union all
  select '3' as data_type,user_id as code,inter_prd_code as inter_code from tbuserprdright
with read only
/

