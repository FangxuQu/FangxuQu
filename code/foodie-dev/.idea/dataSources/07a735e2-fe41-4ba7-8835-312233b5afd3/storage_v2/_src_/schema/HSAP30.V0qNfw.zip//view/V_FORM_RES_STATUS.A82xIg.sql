create view V_FORM_RES_STATUS as
select
    resstatus.uuid    as resstatusuuid,
    resstatus.resuuid as resuuid,
    resstatus.processversionid,
    resstatus.processnodeid,
    resstatus.resstatus,
    resreg.formid,
    resreg.resid,
    resreg.resname,
    resreg.restype
from
    jbpm4_ext_form_resstatus resstatus,
    jbpm4_ext_form_resreg resreg
where
    resstatus.resuuid = resreg.uuid
with read only
/

