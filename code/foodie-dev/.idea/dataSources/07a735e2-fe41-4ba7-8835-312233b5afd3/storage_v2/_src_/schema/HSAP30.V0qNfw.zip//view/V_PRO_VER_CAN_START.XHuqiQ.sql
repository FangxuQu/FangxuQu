create view V_PRO_VER_CAN_START as
select
pro.dbid_ as prodbid,
pro.process_id,
pro.process_name,
protype.dbid_ as protypeid,
protype.type_name,
ver.dbid_ as versiondbid,
ver. version,
ver.state,
ver.description as verdesc,
veropr.typecode as startertypecode,
veropr.code as startercode,
pro.can_human_start as can_human_start,
pro.ext_biz_type as ext_biz_type,
pro.sort_index as sort_index,
pro.description as process_desc
from
jbpm4_ext_pro pro
inner join jbpm4_ext_pt_tran protypemap on pro.dbid_ = protypemap.process_id
inner join jbpm4_ext_process_type protype on protypemap.type_id = protype.dbid_
inner join jbpm4_ext_ver ver on(
pro.dbid_ = ver.process_
and ver.state = 2
)
left outer join jbpm4_ext_ver_opr veropr on veropr.version_id = ver.dbid_
with read only
/

