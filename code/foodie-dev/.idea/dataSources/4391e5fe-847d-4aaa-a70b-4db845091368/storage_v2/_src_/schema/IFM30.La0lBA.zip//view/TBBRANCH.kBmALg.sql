create view TBBRANCH as
select  branch_path  internal_branch,
   branch_code  branch_no,
   branch_name ,
   short_name ,
   parent_code  up_branch,
   branch_level,
   ' '         branch_kind,
   ' '         branch_trans,
   remark     reserve1
from
   tsys_branch
/

