create view TBDICT as
select
   a.dict_entry_code  hs_key,
   a.dict_entry_name  key_name,
   b.dict_item_code   val,
   b.dict_item_name   prompt,
   a.ctrl_flag        kernal_flag,
   a.kind_code        belong_type
from
   tsys_dict_entry  a, tsys_dict_item b where a.dict_entry_code = b.dict_entry_code
/

