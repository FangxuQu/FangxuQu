create view TBUSERBRANCH as
select
    user_id ,branch_code branch_no
from
   tsys_branch_user
/

