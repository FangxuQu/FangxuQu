create view VERRMONITOR as
select
   a.trans_date,
   '000000' ta_code,
   '??' ta_name,
   '000000' prd_code,
   '????' prd_name,
   a.client_no,
   a.sys_amt amt,
   a.host_amt other_amt,
   0 vol,
   0 other_vol,
   b.prompt err_msg,
   '1' err_type,
   a.to_host_serial  to_host_serial
from
   tbbkcompdetail a,
   tbdict b
   where a.unequa_flag = b.val
   and b.hs_key = 'K_ZWBP'
union
select
   a.comp_date trans_date,
   a.ta_code,
   d.ta_name,
   a.prd_code,
   c.prd_name,
   a.client_no,
   0 amt,
   0 other_amt,
   a.vol,
   a.ta_vol other_vol,
   b.prompt err_msg,
   '2' err_type,
   ' ' to_host_serial
from
   tbshareerr a,
   tbdict b,
   tbproduct c,
   tbtainfo d
where
   a.unequa_flag = b.val
   and b.hs_key = 'K_FEBP'
   and a.ta_code = d.ta_code
   and a.prd_code = c.prd_code
/

