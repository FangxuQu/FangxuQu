create view VMARKETINFO as
SELECT
    ta_code AS market_code,
    ta_name AS market_name,
    prd_type
FROM
    tbtainfo
UNION
SELECT
    ta_code AS market_code,
    ta_name AS market_name,
    '3'     AS prd_type
FROM
    tbmetalcompany
/

