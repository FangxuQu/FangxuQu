create view VPAYMENT as
select
   a.clear_date,
   a.prd_code,
   a.ta_code,
   b.bank_acc_up out_account,
   b.bank_acc_down in_account,
   a.cfm_amt,
   a.charge,
   a.red_amt,
   a.div_amt,
   a.refund_amt,
   other_in other_amt,
   a.red_amt + a.div_amt + a.refund_amt tot_amt,
   a.trans_date,
   a.square_date,
   a.curr_type
from
   tbpayment a left join tbprdbankacc b on (a.prd_code = b.prd_code)
/

