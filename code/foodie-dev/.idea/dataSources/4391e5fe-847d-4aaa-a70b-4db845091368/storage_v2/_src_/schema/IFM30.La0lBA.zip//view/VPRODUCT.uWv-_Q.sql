create view VPRODUCT as
select
   prd_code,
   model_flag,
   prd_type,
   prd_name,
   prd_name2,
   ta_code
from
   tbproduct
/

