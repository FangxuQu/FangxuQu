create view VRISKERR as
select
   a.trans_date,
   a.ta_code,
   b.trans_name,
   serial_no,
   d.ta_name,
   a.prd_code,
   c.prd_name,
   client_no,
   in_client_no,
   bank_acc,
   asset_acc,
   amt,
   vol,
   a.summary
from
   tbtransreq a,
   tbtrans b,
   tbproduct c,
   tbtainfo d
where
   a.monitor_flag = '1'
   AND a.status NOT IN ('2', '3', '4')
   AND a.trans_code = b.trans_code
   AND a.prd_code = c.prd_code
   AND a.ta_code = d.ta_code
UNION
select
   a.trans_date,
   a.ta_code,
   b.trans_name,
   serial_no,
   d.ta_name,
   a.prd_code,
   c.prd_name,
   client_no,
   in_client_no,
   bank_acc,
   asset_acc,
   amt,
   vol,
   a.summary
from
   tbhistransreq a,
   tbtrans b,
   tbproduct c,
   tbtainfo d
where
   a.monitor_flag = '1'
   AND a.status NOT IN ('2', '3', '4')
   AND a.trans_code = b.trans_code
   AND a.prd_code = c.prd_code
   AND a.ta_code = d.ta_code
/

