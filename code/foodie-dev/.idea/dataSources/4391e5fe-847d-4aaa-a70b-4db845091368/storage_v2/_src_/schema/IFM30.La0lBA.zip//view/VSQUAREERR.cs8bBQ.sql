create view VSQUAREERR as
select
   clear_date,
   0 square_date,
   serial_no,
   d.ta_code,
   ta_name,
   d.prd_code,
   prd_name,
   client_no,
   bank_acc,
   busin_code,
   d.reserve1 trans_name,
   amt
from
   tbsquare d,
   tbproduct c,
   tbtainfo b,
   tbsysarg a
where
   d.ta_code = b.ta_code
   AND d.prd_code = c.prd_code
   AND d.clear_date < a.init_date
UNION
select
   clear_date,
   square_date,
   serial_no,
   d.ta_code,
   ta_name,
   d.prd_code,
   prd_name,
   client_no,
   bank_acc,
   busin_code,
   d.reserve1 trans_name,
   amt
from
  tbhissquare d,
   tbproduct c,
   tbtainfo b
where
   d.ta_code = b.ta_code
   AND d.prd_code = c.prd_code
   AND d.clear_date < square_date
/

