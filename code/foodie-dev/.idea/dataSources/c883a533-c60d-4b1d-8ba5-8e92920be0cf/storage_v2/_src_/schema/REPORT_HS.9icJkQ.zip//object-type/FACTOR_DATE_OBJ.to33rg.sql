create TYPE             "FACTOR_DATE_OBJ"                                          IS OBJECT (
	factor_id      VARCHAR2(100),
	start_date     DATE,
	end_date       DATE,
	days           NUMBER(14,6),
	max_drawndown  NUMBER(30,14)
);
/

