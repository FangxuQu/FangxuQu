create TYPE             "FACTOR_VALUE_OBJ"                                          IS OBJECT (
	  fac_id      VARCHAR2(32),
	  start_date    date,
	  end_date     date
	)
/

