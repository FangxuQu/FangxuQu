create TYPE             "INDICATOR_VALUE_OBJ"                                          IS OBJECT (
  test_id      VARCHAR2(32),
  object_id    VARCHAR2(32),
  ind_name     VARCHAR2(64),
  ind_value    NUMBER(30,14),
  value_type   VARCHAR2(6) --normal, light, medium, heavy
)
/

