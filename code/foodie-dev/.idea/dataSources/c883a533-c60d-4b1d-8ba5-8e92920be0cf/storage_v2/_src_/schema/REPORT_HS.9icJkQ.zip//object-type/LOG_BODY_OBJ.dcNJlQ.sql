create TYPE             "LOG_BODY_OBJ"                                          IS OBJECT(
  LOG_INFO          VARCHAR2(4000),     --日志信息，最大长度4000
  LOG_DETAIL_INFO   CLOB,               --日志明细信息（如具体的SQL代码段，查询结果数据），CLOB类型，长度不限量
  SCRIPT_LINE       NUMBER(9),          --写入日志语句在SQL脚本中的代码行数
  SQL_CODE          VARCHAR2(32),       --数据库错误代码
  SQL_ERRM          VARCHAR2(2000)      --数据库错误消息
)
/

