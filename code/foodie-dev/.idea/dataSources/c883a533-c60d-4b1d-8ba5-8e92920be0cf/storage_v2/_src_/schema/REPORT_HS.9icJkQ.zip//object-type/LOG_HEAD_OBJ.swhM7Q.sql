create TYPE             "LOG_HEAD_OBJ"                                          IS OBJECT(
  --日志消息头部信息（通常一个存储过程、函数中的所有日志的头部信息都相同）
  SCRIPT_NAME       VARCHAR2(100),  --package.存储过程,package.函数
  ANCESTORS_NAME    VARCHAR2(640),  --祖宗们的名字（太爷爷、爷爷、爸爸调用层级关系）
  PAGE_ID           VARCHAR2(50),   --页面ID
  ELEMENT_ID        VARCHAR2(50),   --页面元素ID
  SCRIPT_PARAMS     VARCHAR2(4000), --存储过程或函数的参数，建议json格式，最大长度4000，若参数超出4000，那么放入LOG_BODY_RECORD.log_detail_info中
  START_TIME        TIMESTAMP(6),   --存储过程或函数的执行开始时间
  CREATE_USER       VARCHAR2(20),   --登录WEB系统的用户ID
  CREATE_DEPT       VARCHAR2(32)    --登录WEB系统的用户所在部门
)
/

