create TYPE             "PROD_CCSL_OBJ"                                          IS OBJECT (
    prod_id           VARCHAR2(32),
    prod_name         VARCHAR2(200),
    ccsl              NUMBER(30,14)
)
/

