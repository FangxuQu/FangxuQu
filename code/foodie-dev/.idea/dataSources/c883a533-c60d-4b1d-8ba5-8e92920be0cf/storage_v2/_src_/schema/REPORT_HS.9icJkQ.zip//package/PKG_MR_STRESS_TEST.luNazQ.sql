create PACKAGE PKG_MR_STRESS_TEST IS
  --AUTHOR         -  Jiaoxujin
  --CREATION DATE  -  2019-09-26
  --SERVICE NAME   -  兆尹科技-资管事业部
  --PROJECT NAME   -  邮储压力测试
  --DESCRIPTION    -  市场风险压力测试计算包，包括因子最大变化值、情景价格的计算

  --数组容量最大128
  TYPE TYPE_ARRAY_128 IS VARRAY(128) OF VARCHAR2(32);

  TYPE NUMBER_ARRY IS TABLE OF NUMBER(30,14);

  --Spring datasource validationQuery 验证package的时效性
  FUNCTION FUNC_PKG_VALIDATION RETURN DATE;

  --取债券修正久期
  FUNCTION FUNC_GETBONDDUR(f_id   IN varchar2, --资产代码（债券代码）
                           f_date IN varchar2  --基准日期
  ) RETURN NUMBER;

  --取债券计息基础天数
  FUNCTION FUNC_GETDAYSFORBASIS(f_id   IN varchar2--债券代码
  )  RETURN NUMBER;

  --取债券剩余期限
  FUNCTION FUNC_GETBONDEDAYS( f_id   IN varchar2, --债券代码
                              f_date IN varchar2, --基准日期
                              f_flag IN NUMBER    --标记【1：剩余存续期限 2：短期剩余期限】
  )  RETURN NUMBER;

  --取某日债券对应曲线的收益率，采用曲线插值
  FUNCTION FUNC_GETBONDFACHANGE(fac_id        in varchar2,  --因子代码
                                bond_days     in number,    --债券剩余期限
                                sc_date       in date       --时间
  ) RETURN NUMBER;

  --久期计算测试
  --FUNCTION func_get_duration_bycf_test RETURN VARCHAR2;

  --通过到期收益率计算全价,需要未来现金流及对应的年化剩余期限
  FUNCTION FUNC_PRICEBYYTM(
    in_fwdCf_array IN NUMBER_ARRY,
    in_fwdEy_array IN NUMBER_ARRY,
    in_ytm         IN NUMBER,
    in_payFreq     IN NUMBER)
  RETURN NUMBER;

  --通过股票资产代码和压测基准日期获取beta系数
  FUNCTION FUNC_GETBETA(in_sharesid      IN VARCHAR2, --股票资产代码
                        in_dealdate      IN VARCHAR2, --压测基准日期
                        p_ancestors_name IN VARCHAR2 DEFAULT null
  ) RETURN NUMBER;

  --根据未来现金流计算久期、修正久期、凸性(固定利率)
  FUNCTION FUNC_GET_FIDURATION_BYCF(
    in_ytm       IN NUMBER,
    in_fwdCf     IN NUMBER_ARRY,
    in_fwdEy     IN NUMBER_ARRY,
    in_irPayFreq IN NUMBER
  )
  RETURN TYPE_ARRAY_128;

  --根据未来现金流计算久期、修正久期、凸性(浮动付息债算法)
  FUNCTION FUNC_GET_FLDURATION_BYCF(
    in_ytm       IN NUMBER,
    in_fwdCf     IN NUMBER_ARRY,
    in_fwdEy     IN NUMBER_ARRY,
    in_irPayFreq IN NUMBER
  )
  RETURN TYPE_ARRAY_128;

  --计算计息基础天数
/*  FUNCTION func_calc_basis_days(
    in_payDateBegin   IN VARCHAR2,
    in_vdate          IN VARCHAR2,
    in_mdate          IN VARCHAR2,
    in_firstPayDate   IN VARCHAR2,
    in_basis          IN VARCHAR2,
    in_calMethod      IN VARCHAR2
  )
  RETURN NUMBER;*/

  --根据因子ID(复数)和情景起止时间，返回因子的最大变化值和因子匹配资产类型信息的列表
  PROCEDURE P_GET_FACTOR_MAXDRAWDOWN2(p_factor_ids        IN VARCHAR2,   --多个因子用半角逗号隔开
                                      p_beginDate         IN DATE,       --情景开始日期
                                      p_endDate           IN DATE,       --情景结束日期
                                      p_factor_cur        OUT PKG_STRESS_TEST_COMM.cur_out,
                                      p_calc_maxdrawndown IN VARCHAR2 DEFAULT 'true'); --是否在本过程内同步计算因子波动值

  --市场风险压力测试指标计算主存储过程
  PROCEDURE P_MARKET_STRESS_TEST(p_test_id IN VARCHAR2); --压力测试代码

  --市场风险压力测试保存指标计算结果
  PROCEDURE P_SAVE_CALC_RESULT(p_test_id        IN VARCHAR2,  --压力测试代码
                               p_scene_id       IN VARCHAR2,  --情景代码
                               p_start_date     IN DATE,      --情景开始日期
                               p_end_date       IN DATE,      --情景结束日期
                               p_base_date      IN VARCHAR2,  --压力测试基准日期
                               p_query_sql      IN VARCHAR2,  --查询资产信息的SQL语句
                               p_asset_type     IN VARCHAR2,  --资产类型（01-债券,02-基金,03-股票,0401-外汇即期,0402-外汇远期掉期,05-利率互换,06-其它）
                               p_de_flag        IN VARCHAR2,  --风险因子历史数据为空时异常处理标记：01 风险因子变化（率）返回0；02 风险因子变化（率）返回null
                               p_ancestors_name IN VARCHAR2 DEFAULT null);

END PKG_MR_STRESS_TEST;
/

