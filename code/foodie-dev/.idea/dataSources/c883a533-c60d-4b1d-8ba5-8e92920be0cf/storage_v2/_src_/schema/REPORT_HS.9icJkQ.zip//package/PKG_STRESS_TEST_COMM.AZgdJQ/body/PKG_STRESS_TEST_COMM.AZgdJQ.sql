create PACKAGE BODY PKG_STRESS_TEST_COMM IS
  --AUTHOR         -  Jiaoxujin
  --CREATION DATE  -  2019-10-11
  --SERVICE NAME   -  兆尹科技-资管事业部
  --PROJECT NAME   -  邮储压力测试
  --DESCRIPTION    -  定义共通目的涵数、存储过程、对象等。

  --Spring datasource validationQuery 验证package的时效性
  FUNCTION FUNC_PKG_VALIDATION RETURN DATE AS
  BEGIN
    RETURN SYSDATE;
  END;

  --比较字段的值与参数是否相等，并返回结果'true'或'false'
  FUNCTION FUNC_VARCHAR_FILTER(in_field  IN VARCHAR2, in_param  IN VARCHAR2)
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-10-08
    * SERVICE NAME   -  兆尹科技-资管事业部
    *
    * PROCEDURE NAME :FUNC_VARCHAR_FILTER
    *
    * DESCRIPTION    :比较字段的值与参数是否相等，并返回结果'true'或'false'
    *
    * Parameters :
    *  in_field        IN  字段
    *  in_param        IN  参数
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER:
    * DATE:
    * DEVELOPER:
    * DESCRIPTION:
    *****************************************************************************/
    RETURN VARCHAR2 AS
    v_result              VARCHAR2(5);
  BEGIN

    IF in_param IS NOT NULL AND LENGTH(LTRIM(RTRIM(in_param))) > 0 AND in_param <> 'null' AND in_param <> 'NULL' THEN
      IF in_param = in_field THEN
        v_result := 'true';
      ELSE
        v_result := 'false';
      END IF;
    ELSE
      v_result := 'true';
    END IF;

    RETURN v_result;
  EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.put_line('this error message is from function PKG_STRESS_TEST_COMM.FUNC_VARCHAR_FILTER.');
       DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       RETURN null;
  END;

  --两个时间段进行交集判断，优先返回参数时间段内的起止时间
  FUNCTION FUNC_DATE_MIX(in_field_start IN DATE,
                         in_field_end   IN DATE,
                         in_param_start IN DATE,
                         in_param_end   IN DATE,
                         in_type        IN VARCHAR2)
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-10-08
    * SERVICE NAME   -  兆尹科技-资管事业部
    *
    * PROCEDURE NAME :FUNC_DATE_MIX
    *
    * DESCRIPTION    :两个时间段进行交集判断，优先返回参数时间段内的起止时间
    *
    * Parameters :
    *  in_field_start      IN  开始时间字段
    *  in_field_end        IN  截止时间字段
    *  in_param_start      IN  开始时间参数（情景开始日期）
    *  in_param_end        IN  截止时间参数（情景截止日期）
    *  in_type             IN  返回混合后的日期类型，传值start或end
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER:
    * DATE:
    * DEVELOPER:
    * DESCRIPTION:
    *****************************************************************************/
    RETURN DATE AS
    v_joined_start_date       DATE;
    v_joined_end_date         DATE;
    v_mix_start_date          DATE := in_param_start;
    v_mix_end_date            DATE := in_param_end;
  BEGIN

    IF in_type IS NOT NULL AND LENGTH(LTRIM(RTRIM(in_type))) > 0 THEN
      v_joined_start_date := nvl(in_field_start, in_param_start);
      v_joined_end_date := nvl(in_field_end, in_param_end);

      IF v_joined_start_date > v_mix_start_date THEN
        IF v_joined_start_date > v_mix_end_date THEN
          --不在压测范围内的因子排除
          v_mix_start_date := NULL;
        ELSE
          v_mix_start_date := v_joined_start_date;
        END IF;
      END IF;

      IF v_joined_end_date < v_mix_end_date THEN
        IF v_joined_end_date < v_mix_start_date THEN
          --不在压测范围内的因子排除
          v_mix_end_date := NULL;
        ELSE
          v_mix_end_date := v_joined_end_date;
        END IF;
      END IF;

      IF 'start' = in_type OR 'START' = in_type THEN
        RETURN v_mix_start_date;
      ELSE
        RETURN v_mix_end_date;
      END IF;
    END IF;

    RETURN NULL;
  EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.put_line('this error message is from function PKG_STRESS_TEST_COMM.FUNC_DATE_MIX.');
       DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       RETURN null;
  END;

  --获取资产评级名称，如：AAA+
  FUNCTION FUNC_ASSET_GRADE_NAME(in_grade IN VARCHAR2)
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-09-30
    * SERVICE NAME   -  兆尹科技-资管事业部
    *
    * PROCEDURE NAME :FUNC_ASSET_GRADE_NAME
    *
    * DESCRIPTION    :获取资产评级名称，如：AAA
    *
    * Parameters :
    *  in_grade           IN  资产评级代码，如：80
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER:
    * DATE:
    * DEVELOPER:
    * DESCRIPTION:
    *****************************************************************************/
    RETURN VARCHAR2 AS
    v_result              VARCHAR2(200);
    v_log_head            LOG_HEAD_OBJ;
  BEGIN
    PKG_LOG.P_SET_LOG_HEAD(v_log_head, 'PKG_STRESS_TEST_COMM.FUNC_ASSET_GRADE_NAME', '{"in_grade": "'|| in_grade || '"}');

    IF in_grade IS NULL OR LENGTH(TRIM(in_grade)) = 0 THEN
      RETURN null;
    END IF;

    --若查不到，走异常，返回null
    with t1 as
     (select a.item_code, row_number() over(order by a.item_code) as rowno
        from sys_datadict_list a
       where a.dict_code = 'ST_BOND_GRADE'
         and a.item_value = in_grade)
    select t1.item_code into v_result
      from t1
     where t1.rowno = 1;

    RETURN v_result;
  EXCEPTION
    WHEN OTHERS THEN
       --DBMS_OUTPUT.put_line('this error message is from function FUNC_ASSET_GRADE_NAME.');
       --DBMS_OUTPUT.put_line('in_grade IS: ' || in_grade);
       --DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       --DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       PKG_LOG.WARN(v_log_head, '没有获取到资产评级名称', DBMS_UTILITY.format_error_backtrace, SQLCODE, SQLERRM);
       RETURN null;
  END;

  --获取资产类型的名称
  FUNCTION FUNC_ASSET_TYPE_NAME(in_type1 IN VARCHAR2, in_type2 IN VARCHAR2 := 'default', in_type3 IN VARCHAR2 := 'default')
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-09-30
    * SERVICE NAME   -  兆尹科技-资管事业部
    *
    * PROCEDURE NAME :FUNC_ASSET_TYPE_NAME
    *
    * DESCRIPTION    :获取资产类型的名称
    *
    * Parameters :
    *  in_type1           IN  一级资产类型代码
    *  in_type2           IN  二级资产类型代码
    *  in_type3           IN  三级资产类型代码
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER:
    * DATE:
    * DEVELOPER:
    * DESCRIPTION:
    *****************************************************************************/
    RETURN VARCHAR2 AS
    v_result              VARCHAR2(200);
    v_dict_code2          VARCHAR2(50);  --二级字典
    v_dict_code3          VARCHAR2(50);  --三级字典
    v_type2               VARCHAR2(50);
    v_type3               VARCHAR2(50);
    v_log_head            LOG_HEAD_OBJ;
  BEGIN
    PKG_LOG.P_SET_LOG_HEAD(v_log_head, 'PKG_STRESS_TEST_COMM.FUNC_ASSET_TYPE_NAME',
                           '{"in_type1": "'|| in_type1 || '", "in_type2": "'||
                           in_type2 || '", "in_type3": "'|| in_type3 || '"}');

    CASE
      WHEN 'default' <> in_type2 AND 'default' <> in_type3 THEN
        --HE WANT 3
        IF in_type2 IS NULL OR LENGTH(LTRIM(RTRIM(in_type2))) = 0 OR
           in_type3 IS NULL OR LENGTH(LTRIM(RTRIM(in_type3))) = 0 THEN
          RETURN NULL;
        ELSE
          v_type2 := in_type2;
          v_type3 := in_type3;
        END IF;
      WHEN 'default' <> in_type2 THEN
        --HE WANT 2
        IF in_type2 IS NULL OR LENGTH(LTRIM(RTRIM(in_type2))) = 0 THEN
          RETURN NULL;
        ELSE
          v_type2 := in_type2;
        END IF;
      ELSE
        --HE WANT 1
        IF in_type1 IS NULL OR LENGTH(LTRIM(RTRIM(in_type1))) = 0 THEN
          RETURN NULL;
        END IF;
    END CASE;

    IF 'default' = in_type2 THEN
      v_type2 := NULL;
    END IF;

    IF 'default' = in_type3 THEN
      v_type3 := NULL;
    END IF;

    CASE
      WHEN in_type1 IS NOT NULL AND v_type2 IS NOT NULL AND v_type3 IS NOT NULL
           AND LENGTH(LTRIM(RTRIM(in_type1))) > 0
           AND LENGTH(LTRIM(RTRIM(v_type2))) > 0
           AND LENGTH(LTRIM(RTRIM(v_type3))) > 0
      THEN
        --找不到的话直接走异常，返回null
        select b.dict_code into v_dict_code2
          from sys_datadict_list_link b
         where b.linked_dict_code = 'PINAN_ASSET_TYPE' --一级字典
           and rtrim(b.linked_item_code) = in_type1 --一级编码
           and b.item_code = v_type2;  --二级编码

        --找不到的话直接走异常，返回null
        select b.dict_code into v_dict_code3
          from sys_datadict_list_link b
         where b.linked_dict_code = v_dict_code2 --二级字典
           and rtrim(b.linked_item_code) = v_type2   --二级编码
           and b.item_code = v_type3;  --三级编码

        select a.item_value into v_result
          from sys_datadict_list a
         where a.dict_code = v_dict_code3    --三级字典
           and a.item_code = v_type3;  --三级编码

      WHEN in_type1 IS NOT NULL AND v_type2 IS NOT NULL
           AND LENGTH(LTRIM(RTRIM(in_type1))) > 0
           AND LENGTH(LTRIM(RTRIM(v_type2))) > 0
      THEN
        --找不到的话直接走异常，返回null
        select b.dict_code into v_dict_code2
          from sys_datadict_list_link b
         where b.linked_dict_code = 'PINAN_ASSET_TYPE' --一级字典
           and rtrim(b.linked_item_code) = in_type1 --一级编码
           and b.item_code = v_type2;  --二级编码

        select a.item_value into v_result
          from sys_datadict_list a
         where a.dict_code = v_dict_code2 --二级字典
             and a.item_code = v_type2;  --二级编码

      WHEN in_type1 IS NOT NULL AND LENGTH(LTRIM(RTRIM(in_type1))) > 0 THEN
        --找不到的话直接走异常，返回null
        select a.item_value into v_result
          from sys_datadict_list a
         where a.dict_code='PINAN_ASSET_TYPE'
           and a.item_code = in_type1;
    END CASE;

    RETURN v_result;
  EXCEPTION
    WHEN OTHERS THEN
       --DBMS_OUTPUT.put_line('this error message is from function FUNC_ASSET_TYPE_NAME.');
       --DBMS_OUTPUT.put_line('in_type1=' || in_type1 || ', in_type2=' || in_type2 || ', in_type3=' || in_type3);
       --DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       --DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       PKG_LOG.WARN(v_log_head, '没有获取到资产类型的名称', DBMS_UTILITY.format_error_backtrace, SQLCODE, SQLERRM);
       RETURN null;
  END;

  --将clob字符串转换成TABLE类型
  FUNCTION FUNC_SPLIT_CLOB(in_object_ids IN CLOB, in_delimiter IN VARCHAR2 DEFAULT ',')
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-10-30
    * SERVICE NAME   -  兆尹科技-资管事业部
    * PROJECT_NAME   -  邮储压力测试
    *
    * PROCEDURE NAME :FUNC_SPLIT_CLOB
    *
    * DESCRIPTION    :将clob字符串转换成TABLE类型
    *
    * Parameters :
    *  in_object_ids        IN  多个用半角逗号隔开的字符串
    *  in_delimiter         IN  分隔符，默认为半角逗号
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER:
    * DATE:
    * DEVELOPER:
    * DESCRIPTION:
    *****************************************************************************/
    RETURN OBJECT_ID_ARRAY AS

    v_object_array  OBJECT_ID_ARRAY := OBJECT_ID_ARRAY();
    v_object_ids    CLOB := in_object_ids;
    v_delimiter     CLOB := TO_CLOB(in_delimiter);
    v_len           NUMBER := 0;
    v_n             NUMBER;
    v_str           VARCHAR2(32767);
  BEGIN
     DBMS_LOB.APPEND(DEST_LOB => v_object_ids,SRC_LOB =>v_delimiter);

     LOOP
          v_n := DBMS_LOB.INSTR(LOB_LOC => v_object_ids,PATTERN => v_delimiter);
          v_str:= TRIM(DBMS_LOB.SUBSTR(LOB_LOC => v_object_ids,AMOUNT => v_n-1,OFFSET => 1));

      EXIT WHEN v_str IS NULL;
          v_object_array.EXTEND;
          v_object_array(v_object_array.COUNT) :=  v_str;
          v_len := LENGTH(v_object_array(v_object_array.COUNT)) + DBMS_LOB.GETLENGTH(v_delimiter) + v_len;
          DBMS_LOB.ERASE(LOB_LOC => v_object_ids, AMOUNT => v_len);
     END LOOP;

     RETURN v_object_array;
  EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.put_line('this error message is from function PKG_STRESS_TEST_COMM.FUNC_SPLIT_CLOB.');
       DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       RETURN null;
  END FUNC_SPLIT_CLOB;

  --判断指定的字符串是否存在于字符串数组中
  FUNCTION FUNC_CONTAINS_ITEM(in_str_array    IN OBJECT_ID_ARRAY,
                              in_str_item     IN VARCHAR2)
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-09-10
    * SERVICE NAME   -  兆尹科技-资管事业部
    *
    * PROCEDURE NAME :FUNC_CONTAINS_ITEM
    *
    * DESCRIPTION    :判断指定的字符串是否存在于字符串数组中
    *
    * Parameters :
    *  in_str_array           IN  字符串数组
    *  in_str_item            IN  字符串
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER:
    * DATE:
    * DEVELOPER:
    * DESCRIPTION:
    *****************************************************************************/
    RETURN INTEGER AS
    v_result              INTEGER := 0;
  BEGIN
    IF in_str_array IS NULL OR in_str_array.count = 0 THEN
      RETURN 1;
    END IF;

    --数组的长度用count
    FOR i IN 1..in_str_array.count LOOP
      IF in_str_item = in_str_array(i) THEN
        v_result := 1;
        EXIT;
      END IF;
    END LOOP;

    RETURN v_result;
  EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.put_line('this error message is from function PKG_STRESS_TEST_COMM.FUNC_CONTAINS_ITEM.');
       DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       RETURN null;
  END;

  --将字符串数组转换为逗号分隔的clob，按地址传输，调用者必须释放clob变量的缓存：dbms_lob.freetemporary(v_result);
  FUNCTION FUNC_ARRAY_TO_CLOB(in_str_array IN OBJECT_ID_ARRAY)
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-12-03
    * SERVICE NAME   -  兆尹科技-资管事业部
    *
    * PROCEDURE NAME :FUNC_ARRAY_TO_CLOB
    *
    * DESCRIPTION    :将字符串数组转换为逗号分隔的clob
    *
    * Parameters :
    *  in_str_array           IN  字符串数组
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER:
    * DATE:
    * DEVELOPER:
    * DESCRIPTION:
    *****************************************************************************/
    RETURN CLOB AS
    v_result              CLOB := empty_clob();
  BEGIN
    IF in_str_array IS NULL OR in_str_array.count = 0 THEN
      RETURN null;
    END IF;

    dbms_lob.createtemporary(v_result,true);

    FOR i IN 1..in_str_array.count LOOP
      dbms_lob.append(v_result, in_str_array(i) || ',');
    END LOOP;

    dbms_lob.trim(v_result, dbms_lob.getlength(v_result) - 1);
    --dbms_lob.freetemporary(v_result); --不能释放，请调用者释放
    RETURN v_result;
  EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.put_line('this error message is from function PKG_STRESS_TEST_COMM.FUNC_ARRAY_TO_CLOB.');
       DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       dbms_lob.freetemporary(v_result);
       RETURN empty_clob();
  END;

  --获取产品（复数）的持仓数量
  FUNCTION FUNC_GET_PROD_CCSL(in_object_ids IN CLOB,
                              in_base_date  IN DATE,
                              in_ccsl_flag  IN VARCHAR2)
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-10-30
    * SERVICE NAME   -  兆尹科技-资管事业部
    * PROJECT_NAME   -  邮储压力测试
    *
    * PROCEDURE NAME :FUNC_GET_PROD_CCSL
    *
    * DESCRIPTION    :获取产品（复数）的持仓数量列表，以管道形式返回结果
    *
    * Parameters :
    *  in_object_ids        IN  产品组/产品ID，多个用半角逗号隔开
    *  in_base_date         IN  压测基准时间
    *  in_ccsl_flag         IN  持仓数量标记，0：只返回持仓为0的产品，
    *                           1：只返回持仓>0的产品，
    *                           2：全部返回
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER:
    * DATE:
    * DEVELOPER:
    * DESCRIPTION:
    *****************************************************************************/
    RETURN PROD_CCSL_TABLE PIPELINED AS

    v_object_ids             OBJECT_ID_ARRAY := FUNC_SPLIT_CLOB(in_object_ids);
    v_min_ccsl               NUMBER(22,6) := case in_ccsl_flag
                                               when '0' then 0
                                               when '1' then 0.000001
                                               else 0
                                             end;
    v_max_ccsl               NUMBER(22,6) := case in_ccsl_flag
                                               when '0' then 0
                                               when '1' then 9999999999999999
                                               else 9999999999999999
                                             end;

    CURSOR c_prod_ccsl IS
    with bo as
     (select c.object_id,
             c.element_id,
             to_number(c.param_value) as ccsl,
             row_number() over(partition by c.object_id, c.element_id order by in_base_date - c.cdate) as rowno
        from STT_STAT_ELEMENT c
       where FUNC_CONTAINS_ITEM(v_object_ids, c.object_id) = 1
         and in_base_date - c.cdate between 0 and v_max_base_deviation --找不到基准日的持仓数据，可以往前几天再找一找
         and c.element_id is not null
         and c.dict_code = 'SHARE_AMT' --组合资产估值
         and nvl(to_number(c.param_value), 0) > 0),
    b as
     (select bo.object_id, sum(bo.ccsl) as ccsl
        from bo
       where bo.rowno = 1
       group by bo.object_id)
    select a.object_id as prod_id,
           a.object_name as prod_name,
           nvl(b.ccsl, 0) as ccsl
      from (select object_id, object_name
              from STT_OBJECT
             where FUNC_CONTAINS_ITEM(v_object_ids, object_id) = 1) a
      left join b
        on a.object_id = b.object_id
     where nvl(b.ccsl, 0) between v_min_ccsl and v_max_ccsl;

    v_log_head               LOG_HEAD_OBJ;
  BEGIN
      PKG_LOG.P_SET_LOG_HEAD(v_log_head, 'PKG_STRESS_TEST_COMM.FUNC_GET_PROD_CCSL',
                             '{"in_object_ids": "'|| trim(dbms_lob.substr(in_object_ids,3600)) || '", "in_base_date": "'||
                             to_char(in_base_date,'YYYY-MM-DD') || '", "in_ccsl_flag": "'|| in_ccsl_flag || '"}');

      FOR r_prod IN c_prod_ccsl LOOP
        PIPE ROW(PROD_CCSL_OBJ(r_prod.prod_id, r_prod.prod_name, r_prod.ccsl));
      END LOOP;

    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.put_line('this error message is from function PKG_STRESS_TEST_COMM.FUNC_GET_PROD_CCSL.');
       DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       PKG_LOG.ERROR(v_log_head, '获取产品（复数）的持仓数量列表出错', DBMS_UTILITY.format_error_backtrace, SQLCODE, SQLERRM);
       RETURN;
  END;

  --根据资产类型+评级获取最匹配的因子代码（多个）
  FUNCTION FUNC_GET_FACTORS(in_type1      IN VARCHAR2,
                            in_type2      IN VARCHAR2,
                            in_type3      IN VARCHAR2,
                            in_grade      IN VARCHAR2)
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-09-28
    * SERVICE NAME   -  兆尹科技-资管事业部
    *
    * PROCEDURE NAME :FUNC_GET_FACTORS
    *
    * DESCRIPTION    :根据资产类型+评级获取最匹配的因子代码（多个）
    *                 因为不同的因子作用于不同的时间段
    *                 评级找不到的话，取最近的评级，其中等级低的优先（编码更小）
    *
    * Parameters :
    *  in_type1               IN  资产一级分类
    *  in_type2               IN  资产二级分类
    *  in_type3               IN  资产三级分类
    *  in_grade               IN  资产评级
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER:
    * DATE:
    * DEVELOPER:
    * DESCRIPTION:
    *****************************************************************************/
    RETURN FACTOR_VALUE_TABLE AS

    c_match_factors          cur_out;
    v_type1                  VARCHAR2(50) := NULL;
    v_type2                  VARCHAR2(50) := NULL;
    v_type3                  VARCHAR2(50) := NULL;
    v_fac_id                 VARCHAR2(50) := NULL;
    v_start_date             DATE;
    v_end_date               DATE;
    v_fac_list               FACTOR_VALUE_TABLE := FACTOR_VALUE_TABLE();
    v_log_head               LOG_HEAD_OBJ;
    
  BEGIN
    PKG_LOG.P_SET_LOG_HEAD(v_log_head, 'PKG_STRESS_TEST_COMM.FUNC_GET_FACTORS',
                           '{"in_type1": "'|| in_type1 || '", "in_type2": "'|| in_type2 ||
                           '", "in_type3": "'|| in_type3 || '", "in_grade": "'|| in_grade || '"}');

    IF in_type1 IS NULL OR LENGTH(LTRIM(RTRIM(in_type1))) = 0 THEN
      RETURN NULL;
    ELSE
      v_type1 := in_type1;
    END IF;

    IF in_type2 IS NOT NULL AND LENGTH(LTRIM(RTRIM(in_type2))) > 0 THEN
      v_type2 := in_type2;
    END IF;

    IF in_type3 IS NOT NULL AND LENGTH(LTRIM(RTRIM(in_type3))) > 0 THEN
      v_type3 := in_type3;
    END IF;

    IF in_grade IS NOT NULL AND LENGTH(LTRIM(RTRIM(in_grade))) > 0 THEN
      
      OPEN c_match_factors FOR
      --参数type1,type2,type3,grade分别为：F01,B05,02,80
      with t1 as (
        select a.type_1,
           a.type_2,
           a.type_3,
           a.fac_id,
           a.start_date,
           a.end_date,
           a.grade,
           '0' as isFake
        from stt_type_fac_ref a
        union
        --将评级参数数据补入
        select b.type_1,
           b.type_2,
           b.type_3,
           null as fac_id,
           null as start_date,
           null as end_date,
           in_grade as grade,
           '1' as isFake
        from stt_type_fac_ref b
      ),
      t2 as (
      select distinct
           t1.type_1,
           t1.type_2,
           t1.type_3,
           case
           when t1.type_1 = v_type1 and t1.type_2 = v_type2 and t1.type_3 = v_type3 then
            600
           when t1.type_1 = v_type1 and t1.type_2 = v_type2 then
            400
           when t1.type_1 = v_type1 then
            200
           else
            0
           end as typeScore,
           t1.grade,
           t1.fac_id, t1.start_date, t1.end_date,
           dense_rank() over(partition by t1.type_1, t1.type_2, t1.type_3 order by t1.grade) as mapGrade,
           t1.isFake
        from t1
      ),
      t3 as (
      select distinct t2.type_1, t2.type_2, t2.type_3, t2.mapGrade as paramMapGrade
        from t2
       where t2.grade = in_grade
         and t2.typeScore > 0
      ),
      t4 as (
      select t2.*, t3.paramMapGrade
        from t2, t3
        where t2.type_1 = t3.type_1
         and nvl(t2.type_2,0) = nvl(t3.type_2,0)
         and nvl(t2.type_3,0) = nvl(t3.type_3,0)
      --order by t2.type_1, t2.type_2, t2.type_3, t2.mapgrade
      ),
      t5 as (
      select t4.type_1,
           t4.type_2,
           t4.type_3,
           t4.fac_id,
           t4.start_date,
           t4.end_date,
           t4.typeScore,
           abs(decode(sign(t4.paramMapGrade - t4.mapGrade),
                -1,
                t4.paramMapGrade - t4.mapGrade - 0.1,
                t4.paramMapGrade - t4.mapGrade)) as gradeScore
        from t4
       where t4.isFake = '0'
      )
      select t6.fac_id,t6.start_date,t6.end_date
        from --若资产类型+评级对应多个因子，那么因子的总得分应该是一样的
           (select t5.fac_id,
               t5.start_date,
               t5.end_date,
               dense_rank() over(order by t5.typeScore + 150 - t5.gradeScore desc) as rowno
            from t5) t6
       where t6.rowno = 1
         and t6.fac_id is not null;
    ELSE
      OPEN c_match_factors FOR
      with t1 as
       (select a.type_1,
               a.type_2,
               a.type_3,
               case
                 when a.type_1 = v_type1 and a.type_2 = v_type2 and a.type_3 = v_type3 then
                  600
                 when a.type_1 = v_type1 and a.type_2 = v_type2 then
                  400
                 when a.type_1 = v_type1 then
                  200
                 else
                  0
               end as typeScore,
               a.grade,
               a.fac_id,
               a.start_date,
               a.end_date
          from stt_type_fac_ref a),
      t2 as
       (select t1.fac_id,
               t1.start_date,
               t1.end_date,
               dense_rank() over(order by t1.typeScore desc) as rowno
          from t1 where t1.typeScore > 0)
      select fac_id,start_date,end_date from t2
       where t2.rowno = 1
         and t2.fac_id is not null;
    END IF;

    LOOP
      FETCH c_match_factors INTO v_fac_id, v_start_date, v_end_date;
      EXIT WHEN c_match_factors%NOTFOUND;

      v_fac_list.extend;
      v_fac_list(v_fac_list.last) := FACTOR_VALUE_OBJ(v_fac_id, v_start_date, v_end_date);
    END LOOP;

    IF v_fac_list.Count = 0 THEN
      PKG_LOG.WARN(v_log_head, '根据资产类型+评级没有获取到最匹配的因子代码');
    END IF;

    RETURN v_fac_list;
  EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.put_line('this error message is from function PKG_STRESS_TEST_COMM.FUNC_GET_FACTORS.');
       DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       PKG_LOG.ERROR(v_log_head, '根据资产类型+评级获取最匹配的因子代码时出错', DBMS_UTILITY.format_error_backtrace, SQLCODE, SQLERRM);
       RETURN null;
  END;

  --根据因子代码+因子起止时间+债券剩余期限获取因子曲线数据
  FUNCTION FUNC_GET_CURVE_DATA(in_factor_id     IN VARCHAR2,
                               in_start_date    IN DATE,
                               in_end_date      IN DATE,
                               in_remain_period IN NUMBER)
  /******************************************************************************
   * AUTHOR         -  Jiaoxujin
   * CREATION DATE  -  2019-09-29
   * SERVICE NAME   -  兆尹科技-资管事业部
   *
   * PROCEDURE NAME :FUNC_GET_CURVE_DATA
   *
   * DESCRIPTION    :根据因子代码+因子起止时间+债券剩余期限获取因子曲线数据
   *                 支持如下三种案例：
   *                 1.单值因子，返回TWO_DIMENSIONAL_ARRAY(1)，内容为情景起止日期的两条数据，用半角逗号隔开；后期版本会返回情景区间内的所有日的数据
   *                 2.曲线因子+债券剩余期限，返回TWO_DIMENSIONAL_ARRAY(1)，内容为情景起止日期的债券收益率对应剩余期限的折算值，
   *                                          用半角逗号隔开；后期版本会返回情景区间内所有日的数据
   *                 3.曲线因子，返回TWO_DIMENSIONAL_ARRAY(N)，N为债券收益率曲线横坐标的个数（即所有剩余期限），
   *                             每个数组项的内容为情景起止日期的债券收益率值，后期版本会返回情景区间内所有日的数据
   *
   * Parameters :
   *  in_factor_id            IN  因子ID
   *  in_start_date           IN  因子开始日期
   *  in_end_date             IN  因子结束日期
   *  in_remain_period        IN  债券剩余期限，可选参数
   ******************************************************************************
   * POSSIBLE ERROR CONDITIONS :
   ******************************************************************************
   * CHANGE LOG
   ******************************************************************************
   * CHANGE NUMBER:
   * DATE:
   * DEVELOPER:
   * DESCRIPTION:
   *****************************************************************************/
  RETURN TWO_DIMENSIONAL_ARRAY AS
    --开关常量，是否只查询返回期末及期初数据？1:是，0:返回因子时间区间内的所有日的数据
    v_just_sedata              CHAR(1) := '1';
    v_se_field                 VARCHAR2(32);

    v_ftr_value_struct         VARCHAR2(50) := null;
    v_input_value              stt_factor_ext.input_value%type;
    v_condition_ext            stt_factor_ext.condition_ext%type;
    v_table_name               stt_ext_config.table_name%type;
    v_select_column            stt_ext_config.select_column%type;
    v_select_criteria          stt_ext_config.select_criteria%type;
    v_date_period              stt_ext_config.date_period%type;
    v_input_column             stt_ext_config.input_column%type;

    v_xvalue                   VARCHAR2(32);
    v_curve_date               DATE;
    v_value                    NUMBER(30,14);
    v_start_date_end           DATE := in_start_date + PKG_STRESS_TEST_COMM.v_max_mst_days - 1;
    v_end_date_start           DATE := in_end_date - PKG_STRESS_TEST_COMM.v_max_mst_days + 1;

    v_want_fields_alias        VARCHAR2(256);
    v_ext_sql                  VARCHAR2(16000);
    v_data_buffer              OBJECT_ID_ARRAY := OBJECT_ID_ARRAY();
    v_prev_key_point           VARCHAR2(10);  --债券关键年限点
    v_remain_period            NUMBER(30,14) := in_remain_period;
    v_result_data_array        TWO_DIMENSIONAL_ARRAY := TWO_DIMENSIONAL_ARRAY();

    --查询因子外部表数据
    c_fetch_ext_data           cursor_type;

    --找到因子相关的外部曲线表信息
    CURSOR c_factor_condition IS
    select b.ftr_id, b.ftr_value_struct, c.input_value, c.condition_ext, d.table_name,
           d.select_column, d.select_criteria, d.date_period, d.input_column
    from stt_factor b, stt_factor_ext c, stt_ext_config d
    where b.ftr_id = c.ftr_id
     and c.config_id = d.config_id
     and b.eff_status = '01'
     and c.eff_status = 'E'
     and b.ftr_id = in_factor_id;

    v_log_head                 LOG_HEAD_OBJ;
  BEGIN
    PKG_LOG.P_SET_LOG_HEAD(v_log_head, 'PKG_STRESS_TEST_COMM.FUNC_GET_CURVE_DATA',
                           '{"in_factor_id": "'|| in_factor_id ||
                           '", "in_start_date": "'|| to_char(in_start_date, 'YYYY-MM-DD') ||
                           '", "in_end_date": "'|| to_char(in_end_date, 'YYYY-MM-DD') ||
                           '", "in_remain_period": '|| in_remain_period || '}');

    FOR r_factor_cond IN c_factor_condition LOOP
      EXIT WHEN c_factor_condition%NOTFOUND;
      v_ftr_value_struct := r_factor_cond.ftr_value_struct;
      v_input_value := r_factor_cond.input_value;
      v_condition_ext := r_factor_cond.condition_ext;
      IF v_condition_ext IS NOT NULL AND LENGTH(LTRIM(RTRIM(v_condition_ext))) > 0 THEN
        v_condition_ext := v_condition_ext || ' and';
      END IF;
      v_table_name := r_factor_cond.table_name;
      v_select_column := r_factor_cond.select_column;
      v_select_criteria := nvl(r_factor_cond.select_criteria, '1=1');
      v_date_period := r_factor_cond.date_period;
      v_input_column := r_factor_cond.input_column;
      EXIT;
    END LOOP;

    IF v_ftr_value_struct IS NOT NULL THEN
      --单值
      IF v_ftr_value_struct = '01' THEN
        v_want_fields_alias := 'TO_CHAR(xvalue) AS xvalue, null as curve_date, value';
      --曲线
      ELSE
        v_want_fields_alias := 'xvalue, curve_date, value';
      END IF;

      IF v_start_date_end > in_end_date THEN
        v_start_date_end := in_end_date;
      END IF;

      IF v_end_date_start < in_start_date THEN
        v_end_date_start := in_start_date;
      END IF;

      v_ext_sql := 'with t1 as (
                      select ext_tbl.* [sedata] [distance1]
                        from (select ' || v_select_column || ' from ' || v_table_name || '
                       where ' || v_select_criteria || '
                         and ((' || v_date_period || ' between to_date(''' ||
                         to_char(in_start_date, 'YYYY-MM-DD') || ''', ''YYYY-MM-DD'')
                         and to_date(''' || to_char(v_start_date_end, 'YYYY-MM-DD') || ''', ''YYYY-MM-DD'')) or
                         (' || v_date_period || ' between to_date(''' ||
                         to_char(v_end_date_start, 'YYYY-MM-DD') || ''', ''YYYY-MM-DD'')
                         and to_date(''' || to_char(in_end_date, 'YYYY-MM-DD') || ''', ''YYYY-MM-DD'')))
                         and ' || v_input_column || ' = ''' || v_input_value || ''') ext_tbl
                    )
                    [distance2]
                    select ' || v_want_fields_alias || '[distance4] from t1
                     where ' || v_condition_ext || ' [distance3]
                     order by xvalue, curve_date, value';

      --只查询返回期末及期初数据
      IF v_just_sedata = '1' THEN
        --单值
        IF v_ftr_value_struct = '01' THEN
          v_se_field := 'xvalue';
        --曲线
        ELSE
          v_se_field := 'curve_date';
        END IF;

        --为什么要取两天的数据？因为要算两个折算值，并且要期末折算值 - 期初折算值
        v_ext_sql := REPLACE(v_ext_sql, '[sedata]', ', dense_rank() over(order by decode(length(' ||
                             v_se_field || '), 10, to_date(' || v_se_field || ', ''YYYY-MM-DD''), ' || v_se_field || ') - to_date(''' ||
                             to_char(in_start_date, 'YYYY-MM-DD') || ''', ''YYYY-MM-DD'')) as s
                             , dense_rank() over(order by to_date(''' ||
                             to_char(in_end_date, 'YYYY-MM-DD') || ''', ''YYYY-MM-DD'')  -
                             decode(length(' || v_se_field || '), 10, to_date(' || v_se_field || ', ''YYYY-MM-DD''), ' || v_se_field || ')) as e');

        --s=1 or e = 1即表示只取期初和期末的数据，去除该限制条件则返回每天的数据
        v_ext_sql := REPLACE(v_ext_sql, '[distance3]', '(s = 1 or e = 1) [distance3]');
      ELSE
        v_ext_sql := REPLACE(v_ext_sql, '[sedata]');
      END IF;

      --只找债券剩余期限最近的两个关键点的数据
      --IF v_remain_period IS NOT NULL AND v_remain_period > 0 THEN
      IF v_remain_period IS NOT NULL THEN
        v_ext_sql := REPLACE(v_ext_sql, '[distance1]', ', row_number() over(partition by curve_date, sign(to_number(xvalue) - ' ||
        v_remain_period || ') order by abs(to_number(xvalue) - ' || v_remain_period || ')) as lrdistance,
        row_number() over(partition by curve_date order by abs(to_number(xvalue) - ' || v_remain_period || ')) as distance');
        v_ext_sql := REPLACE(v_ext_sql, '[distance2]', ',t2 as (');
        v_ext_sql := REPLACE(v_ext_sql, '[distance4]', ', distance');
        v_ext_sql := REPLACE(v_ext_sql, '[distance3]', ' and to_number(lrdistance) = 1)
           ,t3 as (
             select * from t2 where to_number(distance) = 1
           )
           ,t4 as (
             select * from t2 where to_number(distance) > 1
           )
           select ' || v_remain_period || ' as xvalue,
                  t3.curve_date as curve_date,
                  case
                    when t4.xvalue is null then t3.value
                    when (' || v_remain_period || ' >= to_number(t3.xvalue) and ' || v_remain_period || ' <= to_number(t4.xvalue)) OR
                         (' || v_remain_period || ' >= to_number(t4.xvalue) and ' || v_remain_period || ' <= to_number(t3.xvalue)) then
                      decode(' || v_remain_period || ', to_number(t3.xvalue), t3.value, to_number(t4.xvalue), t4.value,
                             t3.value +
                            (t4.value - t3.value) * (' || v_remain_period || ' - to_number(t3.xvalue)) /
                            (to_number(t4.xvalue) - to_number(t3.xvalue)))
                    else null
                  end as value
             from t3 left join t4
               on t3.curve_date = t4.curve_date');
      ELSE
        v_ext_sql := REPLACE(v_ext_sql, '[distance1]');
        v_ext_sql := REPLACE(v_ext_sql, '[distance2]');
        v_ext_sql := REPLACE(v_ext_sql, '[distance3]');
        v_ext_sql := REPLACE(v_ext_sql, '[distance4]');
      END IF;

      --DBMS_OUTPUT.put_line('v_ext_sql: ' || v_ext_sql);
      open c_fetch_ext_data for v_ext_sql;

      LOOP
        FETCH c_fetch_ext_data INTO v_xvalue, v_curve_date, v_value;
        EXIT WHEN C_FETCH_EXT_DATA%NOTFOUND;

        --设置数值数组(逗号隔开)：利率、汇率、收益率、指数等

        --无指定资产的剩余期限时
        --IF v_ftr_value_struct = '02' AND (v_remain_period IS NULL OR v_remain_period <= 0) THEN
        IF v_ftr_value_struct = '02' AND v_remain_period IS NULL THEN
          IF v_prev_key_point IS NULL THEN
            v_prev_key_point := v_xvalue;
          END IF;

          IF v_prev_key_point <> v_xvalue THEN
            v_result_data_array.extend;
            v_result_data_array(v_result_data_array.last) := v_data_buffer;

            --重新new一个对象结果一样，说明上面数组赋值时不是按地址赋值的
            --v_data_buffer := OBJECT_ID_ARRAY();
            v_data_buffer.delete;
            v_prev_key_point := v_xvalue;
          END IF;
        END IF;

        v_data_buffer.extend;
        v_data_buffer(v_data_buffer.last) := v_value;
      END LOOP;

      IF v_data_buffer IS NOT NULL AND v_data_buffer.count > 0 THEN
        v_result_data_array.extend;
        v_result_data_array(v_result_data_array.last) := v_data_buffer;
      END IF;
    END IF;

    --just for test
    /*FOR i IN 1..v_result_data_array.count LOOP
      FOR j IN 1..v_result_data_array(i).count LOOP
        DBMS_OUTPUT.put(v_result_data_array(i)(j));
        IF j < v_result_data_array(i).count THEN
          DBMS_OUTPUT.put(',');
        END IF;
      END LOOP;
      DBMS_OUTPUT.put_line('-');
    END LOOP;*/

    IF v_result_data_array.COUNT = 0 THEN
      PKG_LOG.INFO(v_log_head, '没有获取到因子的外部行情数据', TO_CLOB(CONCAT(CONCAT('{"v_ext_sql": "', v_ext_sql), '"}')));
    END IF;

    RETURN v_result_data_array;
  EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.put_line('v_ext_sql: ' || v_ext_sql);
       DBMS_OUTPUT.put_line('this error message is from function PKG_STRESS_TEST_COMM.FUNC_GET_CURVE_DATA.');
       DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       PKG_LOG.ERROR(v_log_head, '获取因子曲线数据时出错', DBMS_UTILITY.format_error_backtrace, SQLCODE, SQLERRM);
       RETURN null;
  END;

  --最大回撤计算函数
  FUNCTION FUNC_GET_MAXDRAWDOWN(in_data       IN OBJECT_ID_ARRAY,
                                in_calc_type  IN CHAR)
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-09-27
    * SERVICE NAME   -  兆尹科技-资管事业部
    *
    * PROCEDURE NAME :FUNC_GET_MAXDRAWDOWN
    *
    * DESCRIPTION    :最大回撤计算
    *                 目前简单运算，即采用公式：[期末-期初]/期初
    *                 后期可能在本函数中调用由JAVA代码组成的Oracle函数
    *                 在该函数中调用matlib生成的jar包中的maxdrawdown(in_data,'geometric')函数，
    *                 或者调用相关网络服务接口(如:python restful api接口)进行最大回撤的计算并返回结果。
    *
    * Parameters :
    *  in_data                IN  数据数组，如：每天的股票指数值
    *  in_calc_type           IN  计算类型，1:计算最大回撤值，其它:计算最大回撤比例
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER:
    * DATE:
    * DEVELOPER:
    * DESCRIPTION:
    *****************************************************************************/
    RETURN NUMBER AS
    v_result              NUMBER(30,14) := null;
    v_start_value         NUMBER(30,14);
    v_end_value           NUMBER(30,14);
  BEGIN
    IF in_data IS NOT NULL AND in_data.count > 1 THEN
      v_start_value := to_number(in_data(1));
      v_end_value := to_number(in_data(in_data.last));

      IF in_calc_type IS NOT NULL AND in_calc_type = '1' THEN
        v_result := v_end_value - v_start_value;
      ELSIF v_start_value <> 0 THEN
        v_result := (v_end_value - v_start_value) / v_start_value;
      END IF;
    END IF;

    RETURN v_result;
  EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.put_line('this error message is from function PKG_STRESS_TEST_COMM.FUNC_GET_MAXDRAWDOWN.');
       DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       RETURN null;
  END;

  --获取产品（复数）对应的因子的信息（包括有无因子波动值）
  FUNCTION FUNC_GET_FACTOR_MAXDRAWDOWN(
      in_object_ids     IN CLOB,
      in_scene_id       IN VARCHAR2,
      in_base_date      IN DATE,
      in_drawndown_flag IN VARCHAR2,
      in_is_one_row     IN VARCHAR2 DEFAULT '0'
  )
  /******************************************************************************
    * AUTHOR         -  Jiaoxujin
    * CREATION DATE  -  2019-10-30
    * SERVICE NAME   -  兆尹科技-资管事业部
    * PROJECT_NAME   -  邮储压力测试
    *
    * PROCEDURE NAME :FUNC_GET_FACTOR_MAXDRAWDOWN
    *
    * DESCRIPTION    :获取产品（复数）对应的因子的信息（包括有无因子波动值）
    *
    * Parameters :
    *  in_object_ids        IN  产品组/产品ID，多个用半角逗号隔开
    *  in_scene_id          IN  情景ID
    *  in_base_date         IN  压测基准时间
    *  in_drawndown_flag    IN  因子波动值类型 0:只返回波动为0的因子（即无因子行情数据）
    *                           1:只返回有因子波动值的因子 2:返回持仓不为0资产对应的所有因子
    *  in_is_one_row        IN  是否只返回一条数据，0:不是，1：是
    ******************************************************************************
    * POSSIBLE ERROR CONDITIONS :
    ******************************************************************************
    * CHANGE LOG
    ******************************************************************************
    * CHANGE NUMBER: 1
    * DATE:          2019-11-27
    * DEVELOPER:     Jiaoxujin
    * DESCRIPTION:   增加情景ID参数，替换掉情景起止日期字段，并用情景中选择的因子分类过滤因子
    *****************************************************************************/
    RETURN FACTOR_MAX_DRAWDOWN_TABLE PIPELINED AS

    v_object_ids             OBJECT_ID_ARRAY := FUNC_SPLIT_CLOB(in_object_ids);
    v_scene_start_date       DATE; --情景开始日期
    v_scene_end_date         DATE; --情景截止日期

    CURSOR c_asset_type_grade IS
    --找到持仓大于0的资产
    with bo as
     (select c.object_id,
             c.element_id,
             to_number(c.param_value) as ccsl,
             row_number() over(partition by c.object_id, c.element_id order by in_base_date - c.cdate) as rowno
        from STT_STAT_ELEMENT c
       where FUNC_CONTAINS_ITEM(v_object_ids, c.object_id) = 1
         and in_base_date - c.cdate between 0 and v_max_base_deviation --找不到基准日的持仓数据，可以往前几天再找一找
         and c.element_id is not null
         and c.dict_code = 'SHARE_AMT' --组合资产估值
         and nvl(to_number(c.param_value), 0) > 0),
    --找到持仓大于0的资产的类型
    d as
     (select b.object_id, e.element_id, e.type_1, e.type_2, e.type_3
        from stt_element e,
             --在基准日附近资产大于0的资产们
             (select bo.object_id, bo.element_id from bo where bo.rowno = 1) b
       where e.element_id = b.element_id),
    --找到债券资产的评级
    f as
     (select object_id,
             element_id,
             param_value as credit_grade,
             row_number() over(partition by object_id, element_id order by in_base_date - cdate) as rowno
        from stt_stat_element
       where FUNC_CONTAINS_ITEM(v_object_ids, object_id) = 1
         and in_base_date - cdate between 0 and v_max_base_deviation --找不到基准日的持仓数据，可以往前几天再找一找
         and param_code = 'GRADE_ORDER'
         and (element_id like 'F01%' or element_id like 'F17%'))
    --最后找到持仓大于0的资产的类型和评级（其中只有部分资产有评级）
    select distinct
           d.type_1,
           d.type_2,
           d.type_3,
           f.credit_grade
      from d
      left join f
        on d.object_id = f.object_id
       and d.element_id = f.element_id
       and f.rowno = 1
     where d.type_1 is not null
        or d.type_2 is not null
        or d.type_3 is not null;

    v_fac_list               FACTOR_VALUE_TABLE := FACTOR_VALUE_TABLE(); --单次资产类型获取到的因子
    v_factor_list            FACTOR_VALUE_TABLE := FACTOR_VALUE_TABLE(); --去重后的因子

    v_scene_factor_ids       OBJECT_ID_ARRAY := OBJECT_ID_ARRAY();  --情景的因子ID们
    v_factor_id_array        OBJECT_ID_ARRAY := OBJECT_ID_ARRAY();
    c_factors                cur_out;

    v_type1                  VARCHAR2(50);
    v_type2                  VARCHAR2(50);
    v_type3                  VARCHAR2(50);
    v_grade                  VARCHAR2(100);
    v_assetTypeName1         VARCHAR2(200);
    v_assetTypeName2         VARCHAR2(200);
    v_assetTypeName3         VARCHAR2(200);
    v_gradeName              VARCHAR2(200);

    v_factor_id              VARCHAR2(32);
    v_ftr_name               VARCHAR2(200);
    v_ftr_value_struct       VARCHAR2(50);
    v_ftr_value_struct_name  VARCHAR2(200);
    v_factor_type            VARCHAR2(100);
    v_factor_type2           VARCHAR2(100);
    v_factor_type_name       VARCHAR2(200);
    v_factor_type_name2      VARCHAR2(200);
    v_start_date             DATE;
    v_end_date               DATE;
    v_days                   NUMBER(14,6);
    v_max_drawndown          NUMBER(30,14);

    v_groupNo                VARCHAR2(200);

    v_exists_count           INTEGER := 0;
    v_need_return            CHAR(1) := '0';
    v_log_head               LOG_HEAD_OBJ;
  BEGIN
    --in_object_ids参数记录可能不完整，因为它有可能超过3600长度
    PKG_LOG.P_SET_LOG_HEAD(v_log_head, 'PKG_STRESS_TEST_COMM.FUNC_GET_FACTOR_MAXDRAWDOWN',
                           '{"in_object_ids": "'|| trim(dbms_lob.substr(in_object_ids,3600)) ||
                           '", "in_scene_id": "'|| in_scene_id ||
                           '", "in_base_date": "'|| to_char(in_base_date, 'YYYY-MM-DD') ||
                           '", "in_drawndown_flag": "'|| in_drawndown_flag ||
                           '", "in_is_one_row": "'|| in_is_one_row || '"}');

    --根据情景ID查找情景起止日期
    BEGIN
      select t.start_date, t.end_date into v_scene_start_date, v_scene_end_date
        from stt_scene t
       where t.eff_status = '01'
         and t.scene_id = in_scene_id;

      EXCEPTION WHEN NO_DATA_FOUND THEN
        PKG_LOG.WARN(v_log_head, '没有找到情景[' || in_scene_id || ']的起止日期，无法获取产品的因子信息（及波动值）',
                     TO_CLOB(CONCAT(CONCAT('{"in_object_ids": "',in_object_ids), '"}')));
        RETURN;
    END;

    --查询情景因子
    select f.ftr_id bulk collect into v_scene_factor_ids from stt_scene_factor f where f.scene_id = in_scene_id;

    IF v_scene_factor_ids.COUNT = 0 THEN
      PKG_LOG.WARN(v_log_head, '没有找到情景[' || in_scene_id || ']的任何因子，终止产品的因子信息（及波动值）的获取',
                   TO_CLOB(CONCAT(CONCAT('{"in_object_ids": "',in_object_ids), '"}')));
      RETURN;
    END IF;

    --根据资产类型和等级获取所有因子
    FOR r_asset IN c_asset_type_grade LOOP
      v_fac_list := FUNC_GET_FACTORS(r_asset.type_1, r_asset.type_2, r_asset.type_3, r_asset.credit_grade);

      FOR k IN 1..v_fac_list.count LOOP
        SELECT COUNT(fac_id) INTO v_exists_count
          FROM table(cast(v_factor_list as FACTOR_VALUE_TABLE))
         WHERE fac_id = v_fac_list(k).fac_id;

        IF v_exists_count = 0 THEN
          v_factor_list.extend;
          v_factor_list(v_factor_list.last) := FACTOR_VALUE_OBJ(v_fac_list(k).fac_id, v_fac_list(k).start_date, v_fac_list(k).end_date);
        END IF;
      END LOOP;
    END LOOP;

    --将因子装入OBJECT_ID_ARRAY
    FOR i IN 1..v_factor_list.count LOOP
      --过滤掉不是情景因子的因子
      IF FUNC_CONTAINS_ITEM(v_scene_factor_ids, v_factor_list(i).fac_id) <> 1 THEN
        CONTINUE;
      END IF;

      v_factor_id_array.delete;
      v_factor_id_array.EXTEND;
      v_factor_id_array(v_factor_id_array.last) := v_factor_list(i).fac_id;

      --OPEN c_factors;
      P_GET_FACTOR_MAXDRAWDOWN(v_factor_id_array, v_scene_start_date, v_scene_end_date, c_factors);

      LOOP
        FETCH c_factors into v_type1,v_type2,v_type3,v_grade,v_assetTypeName1,v_assetTypeName2,v_assetTypeName3,v_gradeName,
                             v_factor_id,v_ftr_name,v_ftr_value_struct,v_ftr_value_struct_name,v_factor_type,v_factor_type2,
                             v_factor_type_name,v_factor_type_name2,v_start_date,v_end_date,v_days,v_max_drawndown,v_groupNo;
        EXIT WHEN c_factors%NOTFOUND;

        CASE
          WHEN in_drawndown_flag = '0' AND NVL(v_max_drawndown,0) = 0 THEN
            v_need_return := '1';
          WHEN in_drawndown_flag = '1' AND v_max_drawndown IS NOT NULL THEN
            v_need_return := '1';
          WHEN in_drawndown_flag = '2' THEN
            v_need_return := '1';
          ELSE
            v_need_return := '0';
        END CASE;

        IF v_need_return = '1' THEN
          PIPE ROW(FACTOR_MAX_DRAWDOWN_OBJ(v_factor_id,
                                           v_ftr_name,
                                           v_ftr_value_struct,
                                           v_ftr_value_struct_name,
                                           v_factor_type,
                                           v_factor_type2,
                                           v_factor_type_name,
                                           v_factor_type_name2,
                                           v_start_date,
                                           v_end_date,
                                           v_days,
                                           v_max_drawndown));
          IF in_is_one_row = '1' THEN
            CLOSE c_factors;
            RETURN;
          END IF;
        END IF;
      END LOOP;

      CLOSE c_factors;
    END LOOP;

    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.put_line('this error message is from function PKG_STRESS_TEST_COMM.FUNC_GET_FACTOR_MAXDRAWDOWN.');
       DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
       DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
       PKG_LOG.ERROR(v_log_head, '获取产品（复数）对应的因子的信息（包括有无因子波动值）时出错',
                     DBMS_UTILITY.format_error_backtrace, SQLCODE, SQLERRM);
       RETURN;
  END;

  --设置因子们的波动值
  PROCEDURE P_SET_FACTORS_MAXDRAWNDOWN(in_has_assets_type   IN CHAR,              --因子是否有资产类型，0:无，1:有
                                       in_factor_list       IN OUT FACTOR_DATE_TABLE,
                                       in_assets_changed    IN OUT CHAR) IS
    v_factor_count            INTEGER;
    v_curve_data_first        TWO_DIMENSIONAL_ARRAY := TWO_DIMENSIONAL_ARRAY();  --第一个不为空的因子的行情数据
    v_curve_data_last         TWO_DIMENSIONAL_ARRAY := TWO_DIMENSIONAL_ARRAY();  --最后一个不为空的因子的行情数据
    v_curve_data              TWO_DIMENSIONAL_ARRAY;
    v_first_factor_id         VARCHAR2(32);
    v_first_start_date        DATE;
    v_first_end_date          DATE;
    v_last_factor_id          VARCHAR2(32);
    v_last_end_date           DATE;
    v_keypoint_count          SMALLINT;
    v_valid_count             SMALLINT; --有效数据条数，因子行情数据至少需要2天（即2条）数据才有效，才能计算maxdrawndown
    v_factor_index            INTEGER;

    v_max_drawndown           NUMBER(30,14) := NULL;
    v_factors_clob            CLOB := empty_clob();
    v_log_head                LOG_HEAD_OBJ;
  BEGIN
    PKG_LOG.P_SET_LOG_HEAD(v_log_head, 'PKG_STRESS_TEST_COMM.P_SET_FACTORS_MAXDRAWNDOWN',
                           '{"in_has_assets_type": "'|| in_has_assets_type ||
                           '", "in_factor_list": "in_factor_list为集合对象，请从LOG_DETAIL_INFO字段中获取详细信息'||
                           '", "in_assets_changed": "'|| in_assets_changed || '"}');

    dbms_lob.createtemporary(v_factors_clob,true);
    dbms_lob.append(v_factors_clob,'{"in_factor_list": [');
    FOR i IN in_factor_list.FIRST .. in_factor_list.LAST LOOP
      dbms_lob.append(v_factors_clob,'{');
      dbms_lob.append(v_factors_clob,'"factor_id": "' || in_factor_list(i).factor_id || '", ');
      dbms_lob.append(v_factors_clob,'"start_date": "' || to_char(in_factor_list(i).start_date, 'YYYY-MM-DD') || '", ');
      dbms_lob.append(v_factors_clob,'"end_date": "' || to_char(in_factor_list(i).end_date, 'YYYY-MM-DD') || '"');
      dbms_lob.append(v_factors_clob,'},');
    END LOOP;
    dbms_lob.trim(v_factors_clob, dbms_lob.getlength(v_factors_clob) - 1);
    dbms_lob.append(v_factors_clob,']}');

    --DBMS_OUTPUT.put_line ('v_factors_clob: ' || trim(dbms_lob.substr(v_factors_clob,3600)));

    --有资产类型因子们的波动值设置
    IF in_has_assets_type = '1' THEN
      v_factor_count := in_factor_list.COUNT;

      IF v_factor_count > 0 THEN
        v_factor_index := in_factor_list.FIRST;
        WHILE v_factor_index IS NOT NULL LOOP --AND in_factor_list.COUNT >= v_factor_index LOOP
          --不在压测范围内的因子排除
          IF in_factor_list(v_factor_index).start_date IS NULL OR in_factor_list(v_factor_index).end_date IS NULL THEN
            --Remove this item
            in_factor_list.delete(v_factor_index);
            --Added by JIAOXUJIN on 2019-11-18,集合delete()之后并没有清除相关的索引，但是却禁止了那个索引的访问
            v_factor_index := in_factor_list.next(v_factor_index);
            CONTINUE;
          END IF;

          v_curve_data := FUNC_GET_CURVE_DATA(in_factor_list(v_factor_index).factor_id, in_factor_list(v_factor_index).start_date, in_factor_list(v_factor_index).end_date, null);

          IF v_curve_data IS NOT NULL AND v_curve_data.COUNT > 0 THEN
            IF in_assets_changed = '1' THEN
              --按地址赋值，所以不能这样直接赋值
              --v_curve_data_first := v_curve_data;
              v_curve_data_first.delete();
              FOR k IN 1..v_curve_data.count LOOP
                v_curve_data_first.extend;
                v_curve_data_first(v_curve_data_first.last) := v_curve_data(k);
              END LOOP;

              v_first_factor_id := in_factor_list(v_factor_index).factor_id;
              v_first_start_date := in_factor_list(v_factor_index).start_date;
              v_first_end_date := in_factor_list(v_factor_index).end_date;
              in_assets_changed := '0';
            ELSE
              v_curve_data_last.delete();
              FOR k IN 1..v_curve_data.count LOOP
                v_curve_data_last.extend;
                v_curve_data_last(v_curve_data_last.last) := v_curve_data(k);
              END LOOP;

              v_last_factor_id := in_factor_list(v_factor_index).factor_id;
              v_last_end_date := in_factor_list(v_factor_index).end_date;
            END IF;

            --曲线因子无特定债券剩余期限时，返回每组关键点的数据
            IF v_curve_data.COUNT > 1 THEN
              v_valid_count := 0;
              FOR i IN 1..v_curve_data.count LOOP
                IF v_curve_data(i) IS NOT NULL AND v_curve_data(i).count > 1 THEN
                  v_max_drawndown := nvl(v_max_drawndown, 0) + FUNC_GET_MAXDRAWDOWN(v_curve_data(i), '1');
                  v_valid_count := v_valid_count + 1;
                END IF;
              END LOOP;

              --对于【债券收益率曲线】类的风险因子：风险因子的变化值 =（所有关键年限点的期末值- 期初值）的平均。
              IF v_valid_count > 0 THEN
                v_max_drawndown := v_max_drawndown / v_valid_count;
              END IF;
            ELSE
              v_max_drawndown := FUNC_GET_MAXDRAWDOWN(v_curve_data(1), '2');
            END IF;

            --每个因子各自的maxDrawndown
            in_factor_list(v_factor_index).max_drawndown := v_max_drawndown;
            --in_factor_list(v_factor_index).start_date := v_first_start_date;
            --in_factor_list(v_factor_index).end_date := v_last_end_date;
            --in_factor_list(v_factor_index).days := round(v_last_end_date - v_first_start_date, 6),;
          END IF;

          --一类资产类型+评级对应多个因子的情况，需要计算因子合并情况下的最大回撤，期末因子的尾值 - 期初因子的初值
          IF v_factor_count > 1 AND v_factor_index = v_factor_count THEN  --最后一个因子时处理
            --版本更新时：应该连接所有因子的数据，而不只是首尾两个因子的数据，实现起来也不难。

            v_max_drawndown := null;
            v_keypoint_count := 0;
            IF v_curve_data_last.COUNT > 1 AND v_curve_data_first.COUNT > 1 THEN
              FOR i IN 1..v_curve_data_last.count LOOP
                --风险：要确保（每天的关键点个数一致），每个因子的关键点个数一致
                --FUNC_GET_CURVE_DATA目前没有返回横坐标keypoint数据，后期若修改返回了，则在此以横坐标相等的数据进行拼接
                IF v_curve_data_first.COUNT >= i THEN --以第一个因子的关键点个数为基准，实为以关键点最少的因子的关键点个数为准
                  v_max_drawndown := nvl(v_max_drawndown, 0) + FUNC_GET_MAXDRAWDOWN(v_curve_data_first(i) MULTISET UNION v_curve_data_last(i), '1');
                  v_keypoint_count := v_keypoint_count + 1;
                END IF;
              END LOOP;

              v_max_drawndown := v_max_drawndown / v_keypoint_count;
            ELSIF v_curve_data_last.COUNT > 0 AND v_curve_data_first.COUNT > 0 THEN
              IF v_curve_data_last.COUNT > 1 OR v_curve_data_first.COUNT > 1 THEN
                --推测为债券
                v_max_drawndown := FUNC_GET_MAXDRAWDOWN(v_curve_data_first(1) MULTISET UNION v_curve_data_last(1), '1');
              ELSE
                --推测为非债券
                v_max_drawndown := FUNC_GET_MAXDRAWDOWN(v_curve_data_first(1) MULTISET UNION v_curve_data_last(1), '2');
              END IF;
            ELSIF v_curve_data_first.COUNT > 0 THEN
              IF v_curve_data_first.COUNT > 1 THEN
                --推测为债券
                v_valid_count := 0;
                FOR i IN 1..v_curve_data_first.count LOOP
                  --至少需要2条数据（横坐标超过1个）
                  IF v_curve_data_first(i) IS NOT NULL AND v_curve_data_first(i).count > 1 THEN
                    v_max_drawndown := nvl(v_max_drawndown, 0) + FUNC_GET_MAXDRAWDOWN(v_curve_data_first(i), '1');
                    v_valid_count := v_valid_count + 1;
                  END IF;
                END LOOP;

                IF v_valid_count > 0 THEN
                  v_max_drawndown := v_max_drawndown / v_valid_count;
                END IF;
              ELSE
                --推测为非债券
                v_max_drawndown := FUNC_GET_MAXDRAWDOWN(v_curve_data_first(1), '2');
              END IF;

              --只有一个因子有行情数据
              v_last_factor_id := in_factor_list(v_factor_index).factor_id;
              v_last_end_date := v_first_end_date;
            ELSE
              PKG_LOG.WARN(v_log_head, '所有因子的行情数据均为空', v_factors_clob);
            END IF;

            --添加一条复合因子的maxDrawndown
            IF v_first_factor_id <> v_last_factor_id THEN
              in_factor_list.extend;
              in_factor_list(in_factor_list.last) := FACTOR_DATE_OBJ(v_first_factor_id || ',' || v_last_factor_id,
                                                                   v_first_start_date,
                                                                   v_last_end_date,
                                                                   round(v_last_end_date - v_first_start_date, 6),
                                                                   v_max_drawndown);
            END IF;
          END IF;

          v_factor_index := in_factor_list.next(v_factor_index);
        END LOOP;
      END IF;
    --无资产类型因子们的波动值设置
    ELSE
      FOR v_index IN in_factor_list.FIRST .. in_factor_list.LAST LOOP
        v_curve_data := FUNC_GET_CURVE_DATA(in_factor_list(v_index).factor_id, in_factor_list(v_index).start_date, in_factor_list(v_index).end_date, null);
        IF v_curve_data IS NOT NULL AND v_curve_data.COUNT > 0 THEN
          in_factor_list(v_index).max_drawndown := FUNC_GET_MAXDRAWDOWN(v_curve_data(1), '1');
        END IF;
      END LOOP;
    END IF;

    dbms_lob.freetemporary(v_factors_clob);
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('this error message is from procedure PKG_STRESS_TEST_COMM.P_SET_FACTORS_MAXDRAWNDOWN.');
      DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
      DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
      dbms_lob.trim(v_factors_clob, dbms_lob.getlength(v_factors_clob) - 1);
      dbms_lob.append(v_factors_clob, ', "format_error_backtrace": "' || DBMS_UTILITY.format_error_backtrace || '"}');
      PKG_LOG.ERROR(v_log_head, '设置因子们的波动值时出错', v_factors_clob, SQLCODE, SQLERRM);
      dbms_lob.freetemporary(v_factors_clob);
  END P_SET_FACTORS_MAXDRAWNDOWN;

  --根据因子ID(复数)和情景起止时间，返回因子的最大回撤和因子匹配资产类型信息的列表
  PROCEDURE P_GET_FACTOR_MAXDRAWDOWN(p_factor_ids        IN OBJECT_ID_ARRAY,   --因子ID字符串数组
                                     p_beginDate         IN DATE,             --情景开始日期
                                     p_endDate           IN DATE,             --情景结束日期
                                     p_factor_cur        OUT cur_out,
                                     p_calc_maxdrawndown IN VARCHAR2 DEFAULT 'true') IS --是否在本过程内同步计算因子波动值
    v_assets_changed          CHAR(1) := '0';
    v_asset_list              ASSETS_TYPE_TABLE := ASSETS_TYPE_TABLE();
    v_factor_list             FACTOR_DATE_TABLE := FACTOR_DATE_TABLE();
    v_fac_id_clob             CLOB := FUNC_ARRAY_TO_CLOB(p_factor_ids); --按地址传输

    cursor c_assets_type is
    select distinct
           a.type_1,
           a.type_2,
           a.type_3,
           a.grade
      from stt_type_fac_ref a
     where FUNC_CONTAINS_ITEM(p_factor_ids, a.fac_id) = 1;

    v_log_head                LOG_HEAD_OBJ;
  BEGIN
    PKG_LOG.P_SET_LOG_HEAD(v_log_head, 'PKG_STRESS_TEST_COMM.P_GET_FACTOR_MAXDRAWDOWN',
                           '{"p_factor_ids": "p_factor_ids为集合对象，请从LOG_DETAIL_INFO字段中获取详细信息"'||
                           ', "p_beginDate": "'|| to_char(p_beginDate, 'YYYY-MM-DD') || '"' ||
                           ', "p_endDate": "' || to_char(p_endDate, 'YYYY-MM-DD') || '"' ||
                           ', "p_calc_maxdrawndown": "' || p_calc_maxdrawndown || '"}');
    v_fac_id_clob := concat('{"p_factor_ids": "', v_fac_id_clob);
    dbms_lob.append(v_fac_id_clob, '"}');

    --按资产类型+评级遍历，因子与资产类型+评级，多对多关系
    FOR r_assets_type IN c_assets_type LOOP
      v_assets_changed := '1';

      select FACTOR_DATE_OBJ(a.fac_id,
                             FUNC_DATE_MIX(a.start_date, a.end_date, p_beginDate, p_endDate, 'start'),
                             FUNC_DATE_MIX(a.start_date, a.end_date, p_beginDate, p_endDate, 'end'),
                             --加不加case判断，结果竟然都是一样的
                             CASE
                               WHEN FUNC_DATE_MIX(a.start_date, a.end_date, p_beginDate, p_endDate, 'end') IS NULL OR
                                    FUNC_DATE_MIX(a.start_date, a.end_date, p_beginDate, p_endDate, 'start') IS NULL
                                 THEN
                                   NULL
                               ELSE
                                 round(FUNC_DATE_MIX(a.start_date, a.end_date, p_beginDate, p_endDate, 'end')-
                                       FUNC_DATE_MIX(a.start_date, a.end_date, p_beginDate, p_endDate, 'start'), 6)
                             END, null)
             bulk collect into v_factor_list
        from stt_type_fac_ref a
       where a.type_1 = r_assets_type.type_1
         and (a.type_2 = r_assets_type.type_2 or r_assets_type.type_2 is null)
         and (a.type_3 = r_assets_type.type_3 or r_assets_type.type_3 is null)
         and (a.grade = r_assets_type.grade or r_assets_type.grade is null)
       order by nvl(a.start_date, to_date('18000101', 'YYYYMMDD')), a.fac_id;   --可能因子没有配置起止时间

      --just for test
/*      FOR i IN 1..v_factor_list.count LOOP
        DBMS_OUTPUT.put('factor_id: ' || v_factor_list(i).factor_id || ', ');
        DBMS_OUTPUT.put('start_date: ' || v_factor_list(i).start_date || ', ');
        DBMS_OUTPUT.put('end_date: ' || v_factor_list(i).end_date || ', ');
        DBMS_OUTPUT.put('days: ' || v_factor_list(i).days || ', ');
        DBMS_OUTPUT.put('max_drawndown: ' || v_factor_list(i).max_drawndown);
        DBMS_OUTPUT.put_line('');
      END LOOP;*/

      IF v_factor_list IS NOT NULL AND v_factor_list.COUNT > 0 THEN
        --有资产类型因子们的波动值设置
        IF p_calc_maxdrawndown = 'true' THEN
          P_SET_FACTORS_MAXDRAWNDOWN('1', v_factor_list, v_assets_changed);
        END IF;

        v_asset_list.extend;
        v_asset_list(v_asset_list.last) := ASSETS_TYPE_OBJ(r_assets_type.type_1, r_assets_type.type_2,
                                                           r_assets_type.type_3, r_assets_type.grade, v_factor_list);
      END IF;
    END LOOP;

    --汇率类的因子不在资产类型匹配因子映射表中
    select FACTOR_DATE_OBJ(s.ftr_id, p_beginDate, p_endDate, round(p_endDate - p_beginDate, 6), null)
           bulk collect into v_factor_list
      from STT_FACTOR_TIPS s
     where (
             (s.dict_code = 'FTR_RSK_TYPE_03' and s.tips_value = 'Mrk02') or
             (s.dict_code = 'FTR_RSK_TYPE2' and s.tips_value = 'Mrk0102')
           )
       and FUNC_CONTAINS_ITEM(p_factor_ids, s.ftr_id) = 1;

    IF v_factor_list IS NOT NULL AND v_factor_list.COUNT > 0 THEN
      --无资产类型因子们的波动值设置
      IF p_calc_maxdrawndown = 'true' THEN
        P_SET_FACTORS_MAXDRAWNDOWN('0', v_factor_list, v_assets_changed);
      END IF;

      v_asset_list.extend;
      v_asset_list(v_asset_list.last) := ASSETS_TYPE_OBJ(null, null, null, null, v_factor_list);
    END IF;

    OPEN p_factor_cur FOR
    --直接查询嵌套表，消除嵌套
    with t1 as (
      select d.type_1, d.type_2, d.type_3, d.grade,
             FUNC_ASSET_TYPE_NAME(d.type_1) as assetTypeName1,
             FUNC_ASSET_TYPE_NAME(d.type_1, d.type_2) as assetTypeName2,
             FUNC_ASSET_TYPE_NAME(d.type_1, d.type_2, d.type_3) as assetTypeName3,
             FUNC_ASSET_GRADE_NAME(d.grade) as gradeName,
             f.factor_id, f.start_date, f.end_date, f.days, f.max_drawndown
        from table(cast(v_asset_list as assets_type_table)) d, table(d.factors) f
       where f.start_date is not null
         and f.end_date is not null
    ),
    t2 as (
      select x.ftr_id,
             x.ftr_name,
             x.ftr_value_struct,
             x.ftrValueStructName,
             x.factorType,
             x.factorTypeName,
             y.factorType2,
             y.factorTypeName2
      from
      (select a.ftr_id, a.ftr_name, a.ftr_value_struct, sdl.item_value as ftrValueStructName, d.factorType, d.factorTypeName
         from stt_factor a
         left join (select distinct b.ftr_id,
                                    b.tips_value as factorType,
                                    c.item_value as factorTypeName
                      from stt_factor_tips b
                      left join sys_datadict_list c
                        on b.dict_code = c.dict_code
                       and b.tips_value = c.item_code
                     where b.dict_code = 'FTR_RSK_TYPE_03') d
           on a.ftr_id = d.ftr_id
         left join sys_datadict_list sdl on sdl.item_code = a.ftr_value_struct and sdl.dict_code='VALUE_STRUCT'
        where FUNC_CONTAINS_ITEM(p_factor_ids, a.ftr_id) = 1
        ) x
      left join
      (select a.ftr_id,
              a.ftr_name,
              b.tips_value as factorType2,
              c.item_value as factorTypeName2
        from stt_factor a, stt_factor_tips b, sys_datadict_list c
       where a.ftr_id = b.ftr_id
         and b.dict_code = c.dict_code
         and b.tips_value = c.item_code
         and b.dict_code = 'FTR_RSK_TYPE2') y
        on x.ftr_id = y.ftr_id
    )
    select t1.type_1, t1.type_2, t1.type_3, t1.grade,
           t1.assetTypeName1, t1.assetTypeName2, t1.assetTypeName3, t1.gradeName,
           t1.factor_id, t2.ftr_name, t2.ftr_value_struct, t2.ftrValueStructName, t2.factorType, t2.factorType2,
           t2.factorTypeName, t2.factorTypeName2,
           t1.start_date, t1.end_date, t1.days, t1.max_drawndown,
           --dense_rank() over(partition by t1.type_1, t1.type_2, t1.type_3, t1.grade order by t1.start_date) as groupNo,
           ora_hash(nvl(t1.type_1, '') || '~' || nvl(t1.type_2, '') || '~' || nvl(t1.type_3, '') || '~' || nvl(t1.grade, '')) as groupNo
      from t1 left join t2    --因为t1中有组合因子ID
        on t1.factor_id = t2.ftr_id
     order by t1.type_1, t1.type_2, t1.type_3, t1.grade, t1.start_date;

    dbms_lob.freetemporary(v_fac_id_clob);
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('this error message is from procedure PKG_STRESS_TEST_COMM.P_GET_FACTOR_MAXDRAWDOWN.');
      DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
      DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);

      dbms_lob.trim(v_fac_id_clob, dbms_lob.getlength(v_fac_id_clob) - 1);
      dbms_lob.append(v_fac_id_clob, ', "format_error_backtrace": "' || DBMS_UTILITY.format_error_backtrace || '"}');
      PKG_LOG.ERROR(v_log_head, '根据因子ID(复数)和情景起止时间，返回因子的最大回撤和因子匹配资产类型信息的列表时出错', v_fac_id_clob, SQLCODE, SQLERRM);
      dbms_lob.freetemporary(v_fac_id_clob);
  END P_GET_FACTOR_MAXDRAWDOWN;

  --根据资产类型+评级+因子（们），获取一条因子波动值
  PROCEDURE P_ASSET_FACTOR_MAXDRAWDOWN2(
    in_type1        IN VARCHAR2,
    in_type2        IN VARCHAR2,
    in_type3        IN VARCHAR2,
    in_grade        IN VARCHAR2,
    in_factor_list  IN VARCHAR2,--factorId,factor_start_date,factor_end_date~factorId,factor_start_date,factor_end_date
    p_factor_cur    OUT cur_out
  )  IS
    v_factor_id               VARCHAR2(32);
    v_start_date              DATE;
    v_end_date                DATE;
    v_prop_index              INTEGER;
    v_factor_list             FACTOR_DATE_TABLE := FACTOR_DATE_TABLE();

    CURSOR c_factor_list IS
    SELECT REGEXP_SUBSTR(in_factor_list, '[^~]+', 1, LEVEL, 'i') AS factor
      FROM DUAL
    CONNECT BY LEVEL <= LENGTH(in_factor_list) - LENGTH(REGEXP_REPLACE(in_factor_list, ',', '')) + 1;
  BEGIN
    FOR r_factor IN c_factor_list LOOP
      EXIT WHEN c_factor_list%NOTFOUND OR r_factor.factor IS NULL OR LENGTH(TRIM(r_factor.factor)) = 0;
      v_prop_index := 1;

      DECLARE
        CURSOR c_factor_props IS
        SELECT REGEXP_SUBSTR(r_factor.factor, '[^,]+', 1, LEVEL, 'i') AS factor_prop
          FROM DUAL
        CONNECT BY LEVEL <= LENGTH(r_factor.factor) - LENGTH(REGEXP_REPLACE(r_factor.factor, ',', '')) + 1;
      BEGIN
        FOR r_prop IN c_factor_props LOOP
          EXIT WHEN c_factor_props%NOTFOUND OR r_prop.factor_prop IS NULL OR LENGTH(TRIM(r_prop.factor_prop)) = 0;

          IF v_prop_index = 1 THEN
            v_factor_id := r_prop.factor_prop;
          ELSIF v_prop_index = 2 THEN
            v_start_date := TO_DATE(r_prop.factor_prop, 'YYYY-MM-DD');
          ELSE
            v_end_date := TO_DATE(r_prop.factor_prop, 'YYYY-MM-DD');
          END IF;
          v_prop_index := v_prop_index + 1;
        END LOOP;

        v_factor_list.extend;
        v_factor_list(v_factor_list.last) := FACTOR_DATE_OBJ(v_factor_id, v_start_date, v_end_date,
                                                             round(v_end_date - v_start_date, 6), null);
      END;
    END LOOP;

    P_ASSET_FACTOR_MAXDRAWDOWN(in_type1, in_type2, in_type3, in_grade, v_factor_list, p_factor_cur);

  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('this error message is from procedure PKG_STRESS_TEST_COMM.P_ASSET_FACTOR_MAXDRAWDOWN2.');
      DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
      DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
  END P_ASSET_FACTOR_MAXDRAWDOWN2;

  --根据资产类型+评级+因子（们），获取一条因子波动值
  PROCEDURE P_ASSET_FACTOR_MAXDRAWDOWN(
    in_type1        IN VARCHAR2,
    in_type2        IN VARCHAR2,
    in_type3        IN VARCHAR2,
    in_grade        IN VARCHAR2,
    in_factor_list  IN OUT FACTOR_DATE_TABLE,
    p_factor_cur    OUT cur_out
  ) IS
    v_has_assets_type         CHAR(1);
    v_assets_changed          CHAR(1) := '1'; --没写错，不要改

  BEGIN
    IF in_type1 IS NULL AND in_type2 IS NULL AND in_type3 IS NULL THEN
      v_has_assets_type := '0';
    ELSE
      v_has_assets_type := '1';
    END IF;

    --in_factor_list按地址传输
    P_SET_FACTORS_MAXDRAWNDOWN(v_has_assets_type, in_factor_list, v_assets_changed);

    OPEN p_factor_cur FOR
    select in_type1 as type_1, in_type2 as type_2, in_type3 as type_3, in_grade as grade,
           f.factor_id, f.start_date, f.end_date, f.days, f.max_drawndown
      from table(in_factor_list) f
     where f.start_date is not null
       and f.end_date is not null;

  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('this error message is from procedure PKG_STRESS_TEST_COMM.P_ASSET_FACTOR_MAXDRAWDOWN.');
      DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
      DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
  END P_ASSET_FACTOR_MAXDRAWDOWN;

END PKG_STRESS_TEST_COMM;
/

