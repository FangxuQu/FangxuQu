create PROCEDURE CREATE_STAT_ELEMENT_MONTHSAPCE(in_month IN VARCHAR2, in_space_path IN VARCHAR2)
  /**********************************************************************************
   * AUTHOR         -  Jiaoxujin
   * CREATION DATE  -  2019-09-06
   * SERVICE NAME   -  兆尹科技-资管事业部
   *
   * PROCEDURE NAME :CREATE_STAT_ELEMENT_MONTHSAPCE
   *
   * DESCRIPTION :   每月底启动一次，创建‘元素统计项表’下个月的数据表空间及索引表空间
   *                 分区索引表空间默认和分区表空间相同
   * Parameters :
   *   in_month      IN  待创建数据表空间的月份  例：201903
   *   in_space_path IN  表空间数据文件的目录位置
   *
   * CALLING PROCEDURE :
   *
   ***********************************************************************************
   * POSSIBLE ERROR CONDITIONS :
   ***********************************************************************************
   * CHANGE LOG
   ***********************************************************************************
   * CHANGE NUMBER:
   * DATE:
   * DEVELOPER:
   * DESCRIPTION:
   **********************************************************************************/
  AS
  v_month                VARCHAR2(6) := NVL(in_month, TO_CHAR(ADD_MONTHS(sysdate, 1), 'YYYYMM'));
  v_space_path           VARCHAR2(128) := NVL(in_space_path, '/home/oracle/app/oracle/oradata/TAMS2/');
  v_space_path_name      VARCHAR2(160);

  v_inta                 NUMBER;         --判断某表空间是否存在的变量
  v_new_space_name       VARCHAR2(100);
  v_max_month_data       VARCHAR2(10);
  v_sql_data_text        VARCHAR2(600);
  v_space_created        CHAR(1) := '0';
BEGIN

  BEGIN
      v_new_space_name := 'STAT_ELEMENT_' || v_month;
      v_space_path_name := v_space_path || v_new_space_name || '.dbf';

      v_sql_data_text := 'CREATE BIGFILE TABLESPACE ' || v_new_space_name || '
                          DATAFILE ''' || v_space_path_name || '''
                          SIZE 128M
                          AUTOEXTEND ON NEXT 64M
                          NOLOGGING
                          DEFAULT NOCOMPRESS
                          ONLINE
                          EXTENT MANAGEMENT LOCAL AUTOALLOCATE
                          SEGMENT SPACE MANAGEMENT AUTO';

      -- 判断表空间是否已经存在,表空间名区分大小写
      --若缺少权限，编译不过
      --grant select on sys.sm$ts_avail to stress_test;
      --SELECT COUNT(1) INTO v_inta FROM sys.sm$ts_avail a WHERE a.tablespace_name = v_new_space_name;

      -- 如果不存在,则创建表空间
      IF v_inta = 0 THEN
        EXECUTE IMMEDIATE v_sql_data_text;
        DBMS_OUTPUT.put_line ('New Table Space: ' || v_new_space_name || 'Has been created.');
      END IF;

      --删除最大表分区
      v_sql_data_text := 'alter table STT_STAT_ELEMENT drop partition STAT_ELEMENT_MAX';
      EXECUTE IMMEDIATE v_sql_data_text;
      DBMS_OUTPUT.put_line ('partition STAT_ELEMENT_MAX has been droped.');

      --给表增加参数指定月份的分区
      v_max_month_data:= TO_CHAR(ADD_MONTHS(TO_DATE(v_month, 'YYYYMM'), 1), 'YYYYMMDD');

      v_sql_data_text := 'alter table STT_STAT_ELEMENT ' ||
                         'add partition ' || v_new_space_name || ' values less than (to_date('''|| v_max_month_data || ''', ''YYYYMMDD'')) tablespace ' || v_new_space_name;
      EXECUTE IMMEDIATE v_sql_data_text;
      DBMS_OUTPUT.put_line ('New Table Space: ' || v_new_space_name || 'Has been added to table[STT_STAT_ELEMENT].');

      --添加最大表分区
      v_sql_data_text := 'alter table STT_STAT_ELEMENT ' ||
                         'add partition STAT_ELEMENT_MAX values less than (MAXVALUE) tablespace STAT_ELEMENT_MAX';
      EXECUTE IMMEDIATE v_sql_data_text;
      DBMS_OUTPUT.put_line ('partition STAT_ELEMENT_MAX has been added.');

      v_space_created := '1';
      COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      DBMS_OUTPUT.put_line('this error message is from procedure CREATE_STAT_ELEMENT_MONTHSAPCE.');
      DBMS_OUTPUT.put_line('Create table space [' || v_new_space_name || '] failed.');
      DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
      DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
  END;

  --超前入库的数据会发生吗？若绝对不会有，则以下逻辑可不考虑，可删除相关代码
  --将最大表分区中的参数月份的数据转移到临时表
  IF v_space_created = '1' THEN
      execute immediate 'TRUNCATE TABLE STT_STAT_ELEMENT_TEMP';
      insert into STT_STAT_ELEMENT_TEMP
      select * from STT_STAT_ELEMENT where to_char(cdate, 'YYYYMM') = in_month;
      DBMS_OUTPUT.put_line ('Inserted ' || SQL%ROWCOUNT || 'rows into STT_STAT_ELEMENT_TEMP, if inserted rows > 0 that means time incorrect data found.');
      delete from STT_STAT_ELEMENT where to_char(cdate, 'YYYYMM') = in_month;  -- delete from max space [STAT_ELEMENT_MAX]
      insert into STT_STAT_ELEMENT
      select * from STT_STAT_ELEMENT_TEMP;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.put_line('this error message is from procedure CREATE_STAT_ELEMENT_MONTHSAPCE.');
    DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
    DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
END CREATE_STAT_ELEMENT_MONTHSAPCE;
/

