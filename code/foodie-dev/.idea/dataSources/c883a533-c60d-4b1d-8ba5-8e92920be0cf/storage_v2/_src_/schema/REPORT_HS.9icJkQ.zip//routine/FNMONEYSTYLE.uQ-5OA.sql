create FUNCTION "FNMONEYSTYLE" 
 (
   fNumber float,
   strType varchar2
 ) return varchar2 
 as
   ReturnValue varchar2(4000):=0;
 begin
     
   --千分
   IF strType = '1' THEN --千分 无小数点
     SELECT SUBSTR
     (
       TRIM(DECODE(fNumber,0,'0.00',TO_CHAR(fNumber,'999,999,999,999,999.99')))
       ,1
       ,LENGTH(TRIM(DECODE(fNumber,0,'0.00',TO_CHAR(fNumber,'999,999,999,999,999.99'))))-3
     ) INTO ReturnValue
     FROM DUAL;
   END IF;
   
   IF strType = '2' THEN --千分 两位小数点
     SELECT TRIM(DECODE(fNumber,0,'0.00',TO_CHAR(fNumber,'999,999,999,999,999.99'))) INTO ReturnValue 
     FROM DUAL;
   END IF;
   
   IF strType = '5' THEN --千分 两位小数点 去掉.00
     SELECT REPLACE
     (
       TRIM(DECODE(fNumber,0,'0.00',TO_CHAR(fNumber,'999,999,999,999,999.99')))
       ,'.00'
       ,''
     ) INTO ReturnValue 
     FROM DUAL;
   END IF;
   
   --非千分
   IF strType = '3' THEN --四位小数
     SELECT TRIM(DECODE(fNumber,0,'0.0000',TO_CHAR(fNumber,'9999999999999999999999999.9999'))) INTO ReturnValue 
     FROM DUAL;
   END IF;
   
   IF strType = '4' THEN  --去掉.00
     SELECT REPLACE
     (
     TRIM(DECODE(fNumber,0,'0.00',TO_CHAR(fNumber,'9999999999999999999999999.99')))
     ,'.00'
     ,''
     ) INTO ReturnValue
     FROM DUAL;
   END IF;
   dbms_output.put_line(ReturnValue);
   return(ReturnValue);
end FnMoneyStyle;
 
 --function测试结果：
 --SELECT FnMoneyStyle(30000.123,'1') FROM DUAL--返回结果：30,000
 --SELECT FnMoneyStyle(30000.123,'2') FROM DUAL--返回结果：30,000.12
 --SELECT FnMoneyStyle(30000.123,'3') FROM DUAL--返回结果：30000.1230
 --SELECT FnMoneyStyle(30000.123,'4') FROM DUAL--返回结果：30000.12
 --SELECT FnMoneyStyle(30000.123,'5') FROM DUAL--返回结果：30,000.12


/

