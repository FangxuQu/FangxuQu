create FUNCTION "FUN_GETPRIN" (prodId IN varchar2,cdate IN date) RETURN NUMBER

AS

v_int_prin number(30,14);

BEGIN

  select int_prin_amt into  v_int_prin from (select rownum, t.int_prin_amt  from (SELECT p.int_prin_amt FROM fin_cash_plan p
         where p.mdate>cdate and( p.cash_type ='02' or p.cash_type ='03' ) and p.finprod_id = prodId order by p.mdate desc)t
  WHERE rownum =1);

RETURN v_int_prin ;

END fun_getPrin;


/

