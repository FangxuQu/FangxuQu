create function getLastInvesDays(valuedate in date,prodid in varchar) return int as days int;
begin 

select tianshucha into days from (
    select 
        valuedate - nvl(t2.bonus_dealt_date,t1.vdate) as tianshucha
    from rep_prod_info t1 
    left join rep_prod_bonus_register t2 
        on t1.prod_id =t2.prod_id and t2.bonus_dealt_date <= valuedate
    WHERE 1=1
        and t1.prod_id = prodid
    order by t2.bonus_dealt_date desc
)
where rownum =1

;
return days;
end;
/

