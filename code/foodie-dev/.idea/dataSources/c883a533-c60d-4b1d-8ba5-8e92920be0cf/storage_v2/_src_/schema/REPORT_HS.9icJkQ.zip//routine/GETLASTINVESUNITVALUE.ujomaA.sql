create function getLastInvesUnitValue(valuedate in date,prodid in varchar) return number as unitvalue number;
begin 
select nvl(ri.unit_value,0) into unitvalue from (
    select * from(
        select 
            nvl(t2.bonus_dealt_date,t1.vdate) lastInvestDay
        from rep_prod_info t1 
        left join rep_prod_bonus_register t2 
            on t1.prod_id =t2.prod_id and t2.bonus_dealt_date <= valuedate
        WHERE 1=1
            and t1.prod_id = prodid
        order by t2.bonus_dealt_date desc
    )
    where rownum =1
)lid
left join rep_prod_index ri on ri.prod_id = prodid and ri.value_date = lid.lastInvestDay
;
return unitvalue;
end;
/

