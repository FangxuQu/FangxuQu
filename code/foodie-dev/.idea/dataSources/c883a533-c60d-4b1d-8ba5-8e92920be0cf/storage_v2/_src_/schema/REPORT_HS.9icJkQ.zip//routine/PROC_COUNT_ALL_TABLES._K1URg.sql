create PROCEDURE proc_count_all_tables(
in_table_prefix IN VARCHAR2,
o_stat_cursor  OUT SYS_REFCURSOR)
/**
 * Author: Jiaoxujin
 * Date: 2019-08-21
 */
IS
  v_table varchar2(60);
  v_num number;
  v_sum number;
  v_tbl_count_list  tbl_stat_table := tbl_stat_table();
begin
  v_sum :=0;
  for idx in (select * from user_tables order by table_name) loop
    v_table := idx.table_name;
    execute immediate 'select count(*) from ' || v_table into v_num;
    --dbms_output.put_line(v_table || ' count is: ' || v_num);
    v_sum := v_sum + v_num;

    IF in_table_prefix IS NULL OR INSTR(v_table, in_table_prefix) = 1 THEN
      v_tbl_count_list.EXTEND;
      v_tbl_count_list(v_tbl_count_list.LAST) := tbl_stat_obj(v_table, v_num);
    END IF;
  end loop;
  --dbms_output.put_line(v_sum);

  OPEN o_stat_cursor FOR
  select t.*
  FROM TABLE(CAST(v_tbl_count_list AS tbl_stat_table)) t
  order by t.rows_count desc;
end proc_count_all_tables;
/

