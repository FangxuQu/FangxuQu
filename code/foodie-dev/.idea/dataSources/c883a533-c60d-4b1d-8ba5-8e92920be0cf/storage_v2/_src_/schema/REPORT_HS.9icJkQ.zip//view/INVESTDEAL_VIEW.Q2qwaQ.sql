create view INVESTDEAL_VIEW as
SELECT DEAL.SETTLE_DATE DEALDATE,
       deal.trade_amt AMT,
       deal.prin_amt PRIN_AMT,
       DEAL.PS,
       DECODE(DEAL.PS,'T01',DEAL.YIELD,'T02',DEAL.YIELD,'T03',DEAL.YIELD,'T39',DEAL.YIELD,'T23',decode(TOTALDEAL.ps, 'T07', DEAL.YIELD)) END_RATE,
       DEAL.TRADE_ID CONTRACT_CODE,
       nvl(DEALADD.PORTFOLIO_ID, TOTALDEAL.PORTFOLIO_ID) PROD_ID, /*产品代码*/
       DEAL.COUNTER_ID,
       DEAL.FINPROD_ID,
       DEAL.Update_Time
       ,deal.trade_id
       ,deal.p_trade_id
  FROM TRD_PRODUCT_DEAL DEAL
  LEFT JOIN TRD_FIN_PRODUCT_DEAL_TOTAL TOTALDEAL
    on deal.TOTLE_TRADE_ID = TOTALDEAL.TOTLE_TRADE_ID
  LEFT JOIN TRD_PRODUCT_DEAL_ADD DEALADD
    ON DEALADD.TRADE_ID = DEAL.TRADE_ID
 WHERE 1 = 1
   AND DEAL.BUSI_TYPE = '02'
   AND DEAL.TRADE_STATUS = '01'
   /*只接入原始交易数据*/
   --and nvL(deal.p_trade_id, 'NOREV') = 'NOREV'
   /*根据交割日和接口接入时间接入数据*/
   --AND NVL(deal.UPDATE_TIME,deal.CREATE_TIME) >= #{interfDate,jdbcType=TIMESTAMP}
	and not exists ( 
		/*已有撤销交易则原交易不查出*/
        select 1 from trd_product_deal deal2 where deal2.p_trade_id = deal.trade_id
    )
  union all

  /*计划类资产*/
  SELECT
     DEAL.SETTLE_DATE DEALDATE,
     deal.trade_amt AMT,
     deal.prin_amt PRIN_AMT,
     DEAL.PS,
     DECODE(DEAL.PS,'T23',DECODE(TOTALDEAL.PS,'T07',DEAL.YIELD)) END_RATE,
     DEAL.TRADE_ID CONTRACT_CODE,
     nvl(DEALADD.PORTFOLIO_ID, TOTALDEAL.PORTFOLIO_ID) PROD_ID, /*产品代码*/
     DEAL.COUNTER_ID ,
       DEAL.FINPROD_ID,
       DEAL.Update_Time
       ,deal.trade_id
       ,deal.p_trade_id
  FROM TRD_PRODUCT_DEAL DEAL
    LEFT JOIN TRD_FIN_PRODUCT_DEAL_TOTAL TOTALDEAL
    on deal.TOTLE_TRADE_ID = TOTALDEAL.TOTLE_TRADE_ID
    LEFT JOIN TRD_PRODUCT_DEAL_ADD DEALADD
    ON DEALADD.TRADE_ID = DEAL.TRADE_ID
  WHERE 1=1
    /*过滤项目类资产、计划类资产、基金重复项*/
    AND DEAL.BUSI_TYPE     IN( '07','09','06')
    AND DEAL.FINPROD_TYPE2 = 'F17'
    AND DEAL.TRADE_STATUS = '01'
    /*只接入原始交易数据*/
    --and nvL(deal.p_trade_id,'NOREV') = 'NOREV'
    /*根据交割日和接口接入时间接入数据*/
    --AND NVL(deal.UPDATE_TIME,deal.CREATE_TIME) >= #{interfDate,jdbcType=TIMESTAMP}
	and not exists ( 
		/*已有撤销交易则原交易不查出*/
        select 1 from trd_product_deal deal2 where deal2.p_trade_id = deal.trade_id
    )
	
   UNION ALL
   /*存款类资产、拆借类资产*/
    SELECT DEAL.SETTLE_DATE DEALDATE,
     deal.trade_amt AMT,
     deal.prin_amt PRIN_AMT,
     DEAL.PS,
     PRD.INT_RATE AS END_RATE,
     DEAL.TRADE_ID CONTRACT_CODE,
     nvl(DEALADD.PORTFOLIO_ID, TOTALDEAL.PORTFOLIO_ID) PROD_ID, /*产品代码*/
     DEAL.COUNTER_ID,
       DEAL.FINPROD_ID,
       DEAL.Update_Time
       ,deal.trade_id
       ,deal.p_trade_id
  FROM TRD_PRODUCT_DEAL DEAL
    LEFT JOIN TRD_FIN_PRODUCT_DEAL_TOTAL TOTALDEAL
    on deal.TOTLE_TRADE_ID = TOTALDEAL.TOTLE_TRADE_ID
    LEFT JOIN FIN_TRADE_PRODUCT PRD
    ON DEAL.TRADE_ID = PRD.FINPROD_ID and PRD.BRANCH = 0
    LEFT JOIN TRD_PRODUCT_DEAL_ADD DEALADD
    ON DEALADD.TRADE_ID = DEAL.TRADE_ID
    WHERE 1=1
    and deal.BUSI_TYPE in( '03','01')
    AND DEAL.TRADE_STATUS = '01'
    /*只接入原始交易数据*/
    --and nvL(deal.p_trade_id,'NOREV') = 'NOREV'
    /*根据交割日和接口接入时间接入数据*/
   --AND NVL(deal.UPDATE_TIME,deal.CREATE_TIME) >= #{interfDate,jdbcType=TIMESTAMP}
	and not exists ( 
		/*已有撤销交易则原交易不查出*/
        select 1 from trd_product_deal deal2 where deal2.p_trade_id = deal.trade_id
    )
	
    UNION ALL
   /*回购交易*/
  SELECT DEAL.SETTLE_DATE DEALDATE,
     deal.trade_amt AMT,
     deal.prin_amt PRIN_AMT,
     DEAL.PS,
     PRD.INT_RATE AS END_RATE,
     DEAL.TRADE_ID CONTRACT_CODE,
     nvl(DEALADD.PORTFOLIO_ID, TOTALDEAL.PORTFOLIO_ID) PROD_ID, /*产品代码*/
     DEAL.COUNTER_ID,
       DEAL.FINPROD_ID,
       DEAL.Update_Time
       ,deal.trade_id
       ,deal.p_trade_id
  FROM TRD_PRODUCT_DEAL DEAL
    LEFT JOIN TRD_FIN_PRODUCT_DEAL_TOTAL TOTALDEAL
    on deal.TOTLE_TRADE_ID = TOTALDEAL.TOTLE_TRADE_ID
    LEFT JOIN FIN_TRADE_PRODUCT PRD
    ON DEAL.TRADE_ID = PRD.FINPROD_ID  and PRD.BRANCH = 0
    LEFT JOIN TRD_PRODUCT_DEAL_ADD DEALADD
    ON DEALADD.TRADE_ID = DEAL.TRADE_ID
  WHERE 1=1
    and deal.BUSI_TYPE in( '04','05')
    AND DEAL.TRADE_STATUS = '01'
    /*只接入原始交易数据*/
    --and nvL(deal.p_trade_id,'NOREV') = 'NOREV'
    /*根据交割日和接口接入时间接入数据*/
    --AND NVL(deal.UPDATE_TIME,deal.CREATE_TIME) >= #{interfDate,jdbcType=TIMESTAMP}
	and not exists ( 
		/*已有撤销交易则原交易不查出*/
        select 1 from trd_product_deal deal2 where deal2.p_trade_id = deal.trade_id
    )
	
   union all
   /*基金资产*/
   SELECT DEAL.SETTLE_DATE DEALDATE,
     deal.trade_amt AMT,
     deal.prin_amt PRIN_AMT,
     DEAL.PS,
     NULL END_RATE,
     DEAL.TRADE_ID CONTRACT_CODE,
     nvl(DEALADD.PORTFOLIO_ID, TOTALDEAL.PORTFOLIO_ID) PROD_ID, /*产品代码*/
     DEAL.COUNTER_ID,
       DEAL.FINPROD_ID,
       DEAL.Update_Time
       ,deal.trade_id
       ,deal.p_trade_id
  FROM TRD_PRODUCT_DEAL DEAL
    LEFT JOIN TRD_FIN_PRODUCT_DEAL_TOTAL TOTALDEAL
    on deal.TOTLE_TRADE_ID = TOTALDEAL.TOTLE_TRADE_ID
    LEFT JOIN TRD_PRODUCT_DEAL_ADD DEALADD
    ON DEALADD.TRADE_ID = DEAL.TRADE_ID
  WHERE 1 =1
    AND DEAL.BUSI_TYPE IN( '06','07')
    AND DEAL.TRADE_STATUS = '01'
    /*过滤货基中的计划类资产净值型*/
    and deal.FINPROD_TYPE2 = 'F06'
    /*只取确认数据*/
    AND DEAL.PS IN ('T01','T02','T05','T19','T11','T12')
    --and nvL(deal.p_trade_id,'NOREV') = 'NOREV'
    /*根据交割日和接口接入时间接入数据*/
    --AND NVL(deal.UPDATE_TIME,deal.CREATE_TIME) >= #{interfDate,jdbcType=TIMESTAMP}
	and not exists ( 
		/*已有撤销交易则原交易不查出*/
        select 1 from trd_product_deal deal2 where deal2.p_trade_id = deal.trade_id
    )
	
    union
   /*债权类、权益类(项目)资产交易*/
    SELECT DEAL.SETTLE_DATE DEALDATE,
     deal.trade_amt AMT,
     deal.prin_amt PRIN_AMT,
     DEAL.PS,
     /*DECODE(DEAL.PS,'T23',DECODE(TOTALDEAL.PS,'T07',DEAL.YIELD)) END_RATE,*/
	 fccr.yield END_RATE,
     DEAL.TRADE_ID CONTRACT_CODE,
     nvl(DEALADD.PORTFOLIO_ID, TOTALDEAL.PORTFOLIO_ID) PROD_ID, /*产品代码*/
     DEAL.COUNTER_ID,
       DEAL.FINPROD_ID,
       DEAL.Update_Time
       ,deal.trade_id
       ,deal.p_trade_id
  FROM TRD_PRODUCT_DEAL DEAL
    LEFT JOIN TRD_FIN_PRODUCT_DEAL_TOTAL TOTALDEAL
    on deal.TOTLE_TRADE_ID = TOTALDEAL.TOTLE_TRADE_ID
    LEFT JOIN TRD_PRODUCT_DEAL_ADD DEALADD
    ON DEALADD.TRADE_ID = DEAL.TRADE_ID
    LEFT JOIN FIN_PRODUCT PRD
    ON DEAL.FINPROD_ID = PRD.FINPROD_ID
	left join FIN_CASH_INFO fci on DEAL.FINPROD_ID = fci.FINPROD_ID 
        and fci.CASH_TYPE_1 = '02'
        and fci.CASH_TYPE_2 = 'C02'
    left join (/*关联现金流计算规则，取生效的最新的收益率*/
        select 
            t.cash_id,
            t.eff_date,
            t.yield,
            rank() over(partition by t.cash_id order by t.eff_date desc) rank
        from fin_cash_calc_rule t
    ) fccr on fci.cash_id = fccr.cash_id AND fccr.eff_date <= DEAL.TRADE_DATE AND fccr.rank=1
    
    WHERE 1=1
    /*过滤项目类资产*/
    AND DEAL.BUSI_TYPE = '09'
	AND DEAL.FINPROD_TYPE2 = 'F18'
	and not exists ( 
		/*已有撤销交易则原交易不查出*/
        select 1 from trd_product_deal deal2 where deal2.p_trade_id = deal.trade_id
    )
/

