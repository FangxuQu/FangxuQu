create view MST_YIELD_CURVE_INFO_VW as
select a.curve_code AS "CURVE_CODE",
       a.curve_date AS "SERDATE",
       a.curve_date AS "CURVE_DATE",
       a.key_point  AS "XVALUE",
       a.key_point  AS "KEY_POINT",
       a.yield      AS "YIELD",
       a.key_point  AS "KEYVALUE",
       a.yield      AS "VALUE",
       c.item_value AS "DATA"
  from mst_yield_curve_info a
  left join (select d.item_value, b.curve_code
               from sys_datadict_list d, mst_curve_def b
              where d.dict_code = 'VALUATION_SOURCE'
                and d.item_code = b.value_source) c
    on a.curve_code = c.curve_code
/

