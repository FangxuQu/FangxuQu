create TYPE                "ASSETS_TYPE_OBJ"                                          IS OBJECT (
  type_1    VARCHAR2(50),
  type_2    VARCHAR2(50),
  type_3    VARCHAR2(50),
  grade     VARCHAR2(50),
  factors   FACTOR_DATE_TABLE
)
/

