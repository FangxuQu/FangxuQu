create TYPE                "FACTOR_MAX_DRAWDOWN_OBJ"                                          IS OBJECT (
    factor_id              VARCHAR2(32),
    ftr_name               VARCHAR2(200),
    ftr_value_struct       VARCHAR2(50),
    ftr_value_struct_name  VARCHAR2(200),
    factor_type            VARCHAR2(100),
    factor_type2           VARCHAR2(100),
    factor_type_name       VARCHAR2(200),
    factor_type_name2      VARCHAR2(200),
    start_date             DATE,
    end_date               DATE,
    days                   NUMBER(14,6),
    max_drawndown          NUMBER(30,14)
)
/

