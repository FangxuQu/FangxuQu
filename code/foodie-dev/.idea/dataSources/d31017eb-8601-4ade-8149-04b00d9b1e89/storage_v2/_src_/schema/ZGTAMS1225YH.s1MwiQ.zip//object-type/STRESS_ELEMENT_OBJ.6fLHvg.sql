create TYPE                "STRESS_ELEMENT_OBJ"                                          IS OBJECT (
  base_date           DATE,
  analysis_vdate      DATE,
  analysis_mdate      DATE,
  object_id           VARCHAR2(32),
  element_id          VARCHAR2(50),
  ccsl                NUMBER(30,14),
  cdate               DATE,
  rowno               INTEGER
)
/

