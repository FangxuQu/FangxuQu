create TYPE                "TBL_STAT_OBJ"                                          IS OBJECT (
  TABLE_NAME      VARCHAR2(256),
  ROWS_COUNT      INTEGER
)
/

