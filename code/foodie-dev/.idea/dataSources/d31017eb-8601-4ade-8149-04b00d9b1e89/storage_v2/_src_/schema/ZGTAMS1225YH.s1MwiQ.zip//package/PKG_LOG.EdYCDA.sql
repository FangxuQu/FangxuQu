create PACKAGE PKG_LOG IS
  --AUTHOR         -  Jiaoxujin
  --CREATION DATE  -  2019-11-25
  --SERVICE NAME   -  兆尹科技-资管事业部
  --DESCRIPTION    -  日志操作共通

  --Spring datasource validationQuery 验证package的时效性
  FUNCTION FUNC_PKG_VALIDATION RETURN DATE;

  --设置日志共通内容部分（通常一个存储过程或函数内部的log_head信息是一样的）
  PROCEDURE P_SET_LOG_HEAD(
    in_log_head       IN OUT LOG_HEAD_OBJ,
    in_script_name    IN VARCHAR2,
    in_script_params  IN VARCHAR2,
    in_ancestors_name IN VARCHAR2 DEFAULT null, --多个用半角逗号隔开
    in_page_id        IN VARCHAR2 DEFAULT null,
    in_element_id     IN VARCHAR2 DEFAULT null,
    in_create_user    IN VARCHAR2 DEFAULT 'system.oracle',
    in_create_dept    IN VARCHAR2 DEFAULT null
  );

  --记录日志信息到数据库中，可指定log级别，不建议直接调用
  PROCEDURE P_LOG_MSG(in_log_head    IN OUT LOG_HEAD_OBJ,
                      in_log_body    IN LOG_BODY_OBJ,
                      in_log_type    IN CHAR);

  --记录debug级别日志信息到数据库中
  PROCEDURE "DEBUG"(
    in_log_head           IN OUT LOG_HEAD_OBJ,
    in_log_info           IN VARCHAR2,                 --日志信息，最大长度4000
    in_detail_info        IN CLOB DEFAULT null,        --日志明细信息（如具体的SQL代码段，查询结果数据），CLOB类型，长度不限量
    in_sql_code           IN VARCHAR2 DEFAULT null,    --数据库错误代码
    in_sql_errm           IN VARCHAR2 DEFAULT null,    --数据库错误消息
    in_script_line        IN NUMBER DEFAULT 0          --写入日志语句在SQL脚本中的代码行数
  );

  --记录info级别日志信息到数据库中
  PROCEDURE "INFO"(
    in_log_head           IN OUT LOG_HEAD_OBJ,
    in_log_info           IN VARCHAR2,                 --日志信息，最大长度4000
    in_detail_info        IN CLOB DEFAULT null,        --日志明细信息（如具体的SQL代码段，查询结果数据），CLOB类型，长度不限量
    in_sql_code           IN VARCHAR2 DEFAULT null,    --数据库错误代码
    in_sql_errm           IN VARCHAR2 DEFAULT null,    --数据库错误消息
    in_script_line        IN NUMBER DEFAULT 0          --写入日志语句在SQL脚本中的代码行数
  );

  --记录warn级别日志信息到数据库中
  PROCEDURE "WARN"(
    in_log_head           IN OUT LOG_HEAD_OBJ,
    in_log_info           IN VARCHAR2,                 --日志信息，最大长度4000
    in_detail_info        IN CLOB DEFAULT null,        --日志明细信息（如具体的SQL代码段，查询结果数据），CLOB类型，长度不限量
    in_sql_code           IN VARCHAR2 DEFAULT null,    --数据库错误代码
    in_sql_errm           IN VARCHAR2 DEFAULT null,    --数据库错误消息
    in_script_line        IN NUMBER DEFAULT 0          --写入日志语句在SQL脚本中的代码行数
  );

  --记录error级别日志信息到数据库中
  PROCEDURE "ERROR"(
    in_log_head           IN OUT LOG_HEAD_OBJ,
    in_log_info           IN VARCHAR2,                 --日志信息，最大长度4000
    in_detail_info        IN CLOB DEFAULT null,        --日志明细信息（如具体的SQL代码段，查询结果数据），CLOB类型，长度不限量
    in_sql_code           IN VARCHAR2 DEFAULT null,    --数据库错误代码
    in_sql_errm           IN VARCHAR2 DEFAULT null,    --数据库错误消息
    in_script_line        IN NUMBER DEFAULT 0          --写入日志语句在SQL脚本中的代码行数
  );

END PKG_LOG;
/

