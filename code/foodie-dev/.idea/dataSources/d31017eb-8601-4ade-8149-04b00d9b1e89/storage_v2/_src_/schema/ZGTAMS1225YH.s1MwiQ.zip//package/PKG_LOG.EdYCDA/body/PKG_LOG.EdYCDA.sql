create PACKAGE BODY PKG_LOG IS
  --AUTHOR         -  Jiaoxujin
  --CREATION DATE  -  2019-11-25
  --SERVICE NAME   -  兆尹科技-资管事业部
  --DESCRIPTION    -  日志操作共通

  --日志级别 0:DEBUG, 1:INFO, 2:WARN, 3:ERROR
  v_log_level constant INTEGER := 1;

  --Spring datasource validationQuery 验证package的时效性
  FUNCTION FUNC_PKG_VALIDATION RETURN DATE AS
  BEGIN
    RETURN SYSDATE;
  END;


  --设置日志共通内容部分（通常一个存储过程或函数内部的log_head信息是一样的）
  PROCEDURE P_SET_LOG_HEAD(
    in_log_head       IN OUT LOG_HEAD_OBJ,
    in_script_name    IN VARCHAR2,
    in_script_params  IN VARCHAR2,
    in_ancestors_name IN VARCHAR2 DEFAULT null,  --多个用半角逗号隔开
    in_page_id        IN VARCHAR2 DEFAULT null,
    in_element_id     IN VARCHAR2 DEFAULT null,
    in_create_user    IN VARCHAR2 DEFAULT 'system.oracle',
    in_create_dept    IN VARCHAR2 DEFAULT null) IS
  BEGIN
    in_log_head := LOG_HEAD_OBJ(in_script_name, in_ancestors_name, in_page_id, in_element_id,
                                in_script_params, systimestamp, in_create_user, in_create_dept);
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('this error message is from procedure PKG_LOG.P_SET_LOG_HEAD.');
      DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
      DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
  END P_SET_LOG_HEAD;


  --记录日志信息到数据库中，可指定log级别，不建议直接调用
  PROCEDURE P_LOG_MSG(in_log_head    IN OUT LOG_HEAD_OBJ,
                      in_log_body    IN LOG_BODY_OBJ,
                      in_log_type    IN CHAR) IS
    v_start_time    STT_SCRIPT_LOG.START_TIME%TYPE := systimestamp;
    v_create_user   STT_SCRIPT_LOG.CREATE_USER%TYPE := 'log_default';
    v_info_type     STT_SCRIPT_LOG.INFO_TYPE%TYPE := '0';   --默认debug级别

    /*必须要使用自治事务，否则commit会影响调用程序事务*/
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    IF in_log_head IS NOT NULL AND in_log_head.SCRIPT_NAME IS NOT NULL THEN
      IF in_log_body IS NOT NULL AND  in_log_body.LOG_INFO IS NOT NULL THEN
        IF in_log_head.START_TIME IS NOT NULL THEN
          v_start_time := in_log_head.START_TIME;
        END IF;

        IF in_log_head.CREATE_USER IS NOT NULL THEN
          v_create_user := in_log_head.CREATE_USER;
        END IF;

        IF in_log_type IS NOT NULL THEN
          v_info_type := in_log_type;
        END IF;

        --插入日志数据
        INSERT INTO STT_SCRIPT_LOG
          (LOG_ID,
           SCRIPT_NAME,
           ANCESTORS_NAME,
           PAGE_ID,
           ELEMENT_ID,
           SCRIPT_PARAMS,
           START_TIME,
           LOG_INFO,
           LOG_DETAIL_INFO,
           INFO_TYPE,
           SCRIPT_LINE,
           SQL_CODE,
           SQL_ERRM,
           CREATE_USER,
           CREATE_DEPT,
           CREATE_TIME)
        VALUES
          (sys_guid(),
           in_log_head.SCRIPT_NAME,
           in_log_head.ANCESTORS_NAME,
           in_log_head.PAGE_ID,
           in_log_head.ELEMENT_ID,
           in_log_head.SCRIPT_PARAMS,
           v_start_time,
           in_log_body.LOG_INFO,
           in_log_body.LOG_DETAIL_INFO,
           v_info_type,
           in_log_body.SCRIPT_LINE,
           in_log_body.SQL_CODE,
           in_log_body.SQL_ERRM,
           v_create_user,
           in_log_head.CREATE_DEPT,
           systimestamp);

        COMMIT;
      ELSE
        RAISE_APPLICATION_ERROR(-20992, '未设置LOG_BODY。');
      END IF;
    ELSE
      RAISE_APPLICATION_ERROR(-20991, '未设置LOG_HEAD。');
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('this error message is from procedure PKG_LOG.P_LOG_MSG.');
      DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
      DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
  END P_LOG_MSG;


  --记录debug级别日志信息到数据库中
  PROCEDURE "DEBUG"(
    in_log_head           IN OUT LOG_HEAD_OBJ,
    in_log_info           IN VARCHAR2,                 --日志信息，最大长度4000
    in_detail_info        IN CLOB DEFAULT null,        --日志明细信息（如具体的SQL代码段，查询结果数据），CLOB类型，长度不限量
    in_sql_code           IN VARCHAR2 DEFAULT null,    --数据库错误代码
    in_sql_errm           IN VARCHAR2 DEFAULT null,    --数据库错误消息
    in_script_line        IN NUMBER DEFAULT 0          --写入日志语句在SQL脚本中的代码行数
  ) IS
    v_log_body            LOG_BODY_OBJ;  --日志内容
  BEGIN
    IF v_log_level < 1 THEN
      v_log_body := LOG_BODY_OBJ(in_log_info, in_detail_info, in_script_line, in_sql_code, in_sql_errm);

      P_LOG_MSG(in_log_head, v_log_body, '0');
    END IF;
  END "DEBUG";


  --记录info级别日志信息到数据库中
  PROCEDURE "INFO"(
    in_log_head           IN OUT LOG_HEAD_OBJ,
    in_log_info           IN VARCHAR2,                 --日志信息，最大长度4000
    in_detail_info        IN CLOB DEFAULT null,        --日志明细信息（如具体的SQL代码段，查询结果数据），CLOB类型，长度不限量
    in_sql_code           IN VARCHAR2 DEFAULT null,    --数据库错误代码
    in_sql_errm           IN VARCHAR2 DEFAULT null,    --数据库错误消息
    in_script_line        IN NUMBER DEFAULT 0          --写入日志语句在SQL脚本中的代码行数
  ) IS
    v_log_body            LOG_BODY_OBJ;  --日志内容
  BEGIN
    IF v_log_level < 2 THEN
      v_log_body := LOG_BODY_OBJ(in_log_info, in_detail_info, in_script_line, in_sql_code, in_sql_errm);

      P_LOG_MSG(in_log_head, v_log_body, '1');
    END IF;
  END "INFO";


  --记录warn级别日志信息到数据库中
  PROCEDURE "WARN"(
    in_log_head           IN OUT LOG_HEAD_OBJ,
    in_log_info           IN VARCHAR2,                 --日志信息，最大长度4000
    in_detail_info        IN CLOB DEFAULT null,        --日志明细信息（如具体的SQL代码段，查询结果数据），CLOB类型，长度不限量
    in_sql_code           IN VARCHAR2 DEFAULT null,    --数据库错误代码
    in_sql_errm           IN VARCHAR2 DEFAULT null,    --数据库错误消息
    in_script_line        IN NUMBER DEFAULT 0          --写入日志语句在SQL脚本中的代码行数
  ) IS
    v_log_body            LOG_BODY_OBJ;  --日志内容
  BEGIN
    IF v_log_level < 3 THEN
      v_log_body := LOG_BODY_OBJ(in_log_info, in_detail_info, in_script_line, in_sql_code, in_sql_errm);

      P_LOG_MSG(in_log_head, v_log_body, '2');
    END IF;
  END "WARN";


  --记录error级别日志信息到数据库中
  PROCEDURE "ERROR"(
    in_log_head           IN OUT LOG_HEAD_OBJ,
    in_log_info           IN VARCHAR2,                 --日志信息，最大长度4000
    in_detail_info        IN CLOB DEFAULT null,        --日志明细信息（如具体的SQL代码段，查询结果数据），CLOB类型，长度不限量
    in_sql_code           IN VARCHAR2 DEFAULT null,    --数据库错误代码
    in_sql_errm           IN VARCHAR2 DEFAULT null,    --数据库错误消息
    in_script_line        IN NUMBER DEFAULT 0          --写入日志语句在SQL脚本中的代码行数
  ) IS
    v_log_body            LOG_BODY_OBJ;  --日志内容
  BEGIN
    v_log_body := LOG_BODY_OBJ(in_log_info, in_detail_info, in_script_line, in_sql_code, in_sql_errm);

    P_LOG_MSG(in_log_head, v_log_body, '3');
  END "ERROR";

END PKG_LOG;
/

