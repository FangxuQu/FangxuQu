create PACKAGE PKG_STRESS_TEST_COMM IS
  --AUTHOR         -  Jiaoxujin
  --CREATION DATE  -  2019-10-11
  --SERVICE NAME   -  兆尹科技-资管事业部
  --PROJECT NAME   -  邮储压力测试
  --DESCRIPTION    -  定义共通目的涵数、存储过程、对象等，通常不涉及到业务功能。

  v_max_asset_deviation     INTEGER := 140; --偏离资产价值统计日期的最大允许天数(寻找汇率数据用)

  v_max_base_deviation      INTEGER := 15; --偏离基准日的最大允许天数

  v_max_mst_days            INTEGER := 15; --获取因子行情数据时，最大偏移天数
  
  v_default_grade           VARCHAR2(10) := '85'; --默认资产评级AA的值-20191226 by sunhui

  type cur_out is ref cursor;

  type cursor_type IS REF CURSOR;

  --Oracle12c 支持
  --Oracle Database 11g Enterprise Edition Release 11.2.0.1.0 支持
  --Oracle Database 11g Enterprise Edition Release 11.2.0.4.0 不支持
  --TYPE OBJECT_ID_ARRAY IS TABLE OF VARCHAR2(32);

  --二维数组
  --TYPE TWO_DIMENSIONAL_ARRAY IS TABLE OF OBJECT_ID_ARRAY INDEX BY BINARY_INTEGER;
  TYPE TWO_DIMENSIONAL_ARRAY IS TABLE OF OBJECT_ID_ARRAY;

  --Spring datasource validationQuery 验证package的时效性
  FUNCTION FUNC_PKG_VALIDATION RETURN DATE;

  --比较字段的值与参数是否相等，并返回结果'true'或'false'
  FUNCTION FUNC_VARCHAR_FILTER(in_field  IN VARCHAR2, in_param  IN VARCHAR2) RETURN VARCHAR2;

  --两个时间段进行交集判断，优先返回参数时间段内的起止时间
  FUNCTION FUNC_DATE_MIX(in_field_start IN DATE,
                         in_field_end   IN DATE,
                         in_param_start IN DATE,
                         in_param_end   IN DATE,
                         in_type        IN VARCHAR2) RETURN DATE;

  --获取资产评级名称，如：AAA+
  FUNCTION FUNC_ASSET_GRADE_NAME(in_grade IN VARCHAR2) RETURN VARCHAR2;

  --获取资产类型的名称
  FUNCTION FUNC_ASSET_TYPE_NAME(in_type1 IN VARCHAR2, in_type2 IN VARCHAR2 := 'default', in_type3 IN VARCHAR2 := 'default') RETURN VARCHAR2;

  --将clob字符串转换成TABLE类型
  FUNCTION FUNC_SPLIT_CLOB(in_object_ids IN CLOB, in_delimiter IN VARCHAR2 DEFAULT ',') RETURN OBJECT_ID_ARRAY;

  --判断指定的字符串是否存在于字符串数组中
  FUNCTION FUNC_CONTAINS_ITEM(in_str_array IN OBJECT_ID_ARRAY, in_str_item IN VARCHAR2) return INTEGER;

  --将字符串数组转换为逗号分隔的clob，按地址传输，调用者必须释放clob变量的缓存：dbms_lob.freetemporary(v_result);
  FUNCTION FUNC_ARRAY_TO_CLOB(in_str_array IN OBJECT_ID_ARRAY) RETURN CLOB;

  --获取产品（复数）的持仓数量
  FUNCTION FUNC_GET_PROD_CCSL(in_object_ids IN CLOB,
                              in_base_date  IN DATE,
                              in_ccsl_flag  IN VARCHAR2) RETURN PROD_CCSL_TABLE PIPELINED;

  --根据资产类型+评级获取最匹配的因子代码（多个）
  FUNCTION FUNC_GET_FACTORS(in_type1 IN VARCHAR2,
                            in_type2 IN VARCHAR2,
                            in_type3 IN VARCHAR2,
                            in_grade IN VARCHAR2) RETURN FACTOR_VALUE_TABLE;

  --根据因子代码+因子起止时间+债券剩余期限获取因子曲线数据
  --支持如下三种案例：
  --1.单值因子，返回返回TWO_DIMENSIONAL_ARRAY(1)，内容为情景起止日期的两条数据，用半角逗号隔开；后期版本会返回情景区间内的所有日的数据
  --2.曲线因子+债券剩余期限，返回返回TWO_DIMENSIONAL_ARRAY(1)，内容为情景起止日期的债券收益率对应剩余期限的折算值，
  --                         用半角逗号隔开；后期版本会返回情景区间内所有日的数据
  --3.曲线因子，返回返回TWO_DIMENSIONAL_ARRAY(N)，N为债券收益率曲线横坐标的个数（即所有剩余期限），
  --            每个数组项的内容为情景起止日期的债券收益率值，用半角逗号隔开；后期版本会返回情景区间内所有日的数据
  FUNCTION FUNC_GET_CURVE_DATA(in_factor_id     IN VARCHAR2,  --因子ID
                               in_start_date    IN DATE,      --因子开始日期
                               in_end_date      IN DATE,      --因子结束日期
                               in_remain_period IN NUMBER     --债券剩余期限，可选参数
  ) RETURN TWO_DIMENSIONAL_ARRAY;

  --最大回撤计算函数
  FUNCTION FUNC_GET_MAXDRAWDOWN(in_data IN OBJECT_ID_ARRAY,   --数据数组,如：每天的股票指数值
                                in_calc_type IN CHAR          --计算类型，1:计算最大回撤值，其它:计算最大回撤比例
  ) RETURN NUMBER;

  --获取产品（复数）对应的因子的信息（包括有无因子波动值）
  FUNCTION FUNC_GET_FACTOR_MAXDRAWDOWN(
      in_object_ids     IN CLOB,
      in_scene_id       IN VARCHAR2,
      in_base_date      IN DATE,
      in_drawndown_flag IN VARCHAR2,
      in_is_one_row     IN VARCHAR2 DEFAULT '0'
  ) RETURN FACTOR_MAX_DRAWDOWN_TABLE PIPELINED;

  --设置因子们的波动值
  PROCEDURE P_SET_FACTORS_MAXDRAWNDOWN(in_has_assets_type   IN CHAR,--因子是否有资产类型，0:无，1:有
                                       in_factor_list       IN OUT FACTOR_DATE_TABLE,
                                       in_assets_changed    IN OUT CHAR);--遍历资产类型时，资产类型是否发生变更 0：没变， 1：变了

  --根据因子ID(复数)和情景起止时间，返回因子的最大回撤和因子匹配资产类型信息的列表
  PROCEDURE P_GET_FACTOR_MAXDRAWDOWN(p_factor_ids        IN OBJECT_ID_ARRAY,  --因子ID字符串数组
                                     p_beginDate         IN DATE,            --情景开始日期
                                     p_endDate           IN DATE,            --情景结束日期
                                     p_factor_cur        OUT cur_out,
                                     p_calc_maxdrawndown IN VARCHAR2 DEFAULT 'true'); --是否在本过程内同步计算因子波动值

  --根据资产类型+评级+因子（们），获取一条因子波动值
  PROCEDURE P_ASSET_FACTOR_MAXDRAWDOWN2(
    in_type1        IN VARCHAR2,
    in_type2        IN VARCHAR2,
    in_type3        IN VARCHAR2,
    in_grade        IN VARCHAR2,
    in_factor_list  IN VARCHAR2,--factorId,factor_start_date,factor_end_date~factorId,factor_start_date,factor_end_date
    p_factor_cur    OUT cur_out
  );

  --根据资产类型+评级+因子（们），获取一条因子波动值
  PROCEDURE P_ASSET_FACTOR_MAXDRAWDOWN(
    in_type1        IN VARCHAR2,
    in_type2        IN VARCHAR2,
    in_type3        IN VARCHAR2,
    in_grade        IN VARCHAR2,
    in_factor_list  IN OUT FACTOR_DATE_TABLE,
    p_factor_cur    OUT cur_out
  );

END PKG_STRESS_TEST_COMM;
/

