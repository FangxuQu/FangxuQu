create procedure CALC_INT_BASIS_DAYS(in_basis IN VARCHAR2,
                                                in_pay_date_begin IN DATE,
                                                in_vdate IN DATE,
                                                in_mdate IN DATE,
                                                in_first_pay_date IN DATE,
                                                in_cal_method IN VARCHAR2,
                                                out_days OUT Integer) is
/**********************************************************************************
  * AUTHOR         -  WangKang
  * CREATION DATE  -  2019-10-10
  * SERVICE NAME   -  兆尹科技-资管事业部
  * PROJECT NAME   -  邮储压力测试
  *
  * PACKAGE NAME: CALC_INT_BASIS_DAYS
  *
  * DESCRIPTION: 计算计息基础天数
  *
  * CHANGE LOG
  ***********************************************************************************
  * CHANGE NUMBER:
  * DATE:
  * DEVELOPER:
  * DESCRIPTION:
  **********************************************************************************/  
  v_cou               integer:=0;               --
  v_return_days       integer;                  --返回的计算计息基础天数   
  v_vdate1             date;                    --     
  v_vdate2             date;                    --    
  v_first_pay_date1    date;                    --
  v_first_pay_date2    date;                    --                  
begin
  --如果【计息基础】不为空成立
  IF in_basis IS NOT NULL AND LENGTH(LTRIM(RTRIM(in_basis))) > 0 AND in_basis <> 'null' AND in_basis <> 'NULL' THEN  
    --如果【计息基础】=A/A 
    IF  in_basis = 'A/A' THEN
        --如果付息开始日！=null 且 起息日、到期日！=null 且推算方式不为空成立
        IF in_pay_date_begin IS NOT NULL AND in_vdate IS NOT NULL AND in_mdate IS NOT NULL AND in_cal_method IS NOT NULL THEN           
           --如果【推算方式】=【起息日向后】
           IF in_cal_method = '01' THEN
             loop
               --将起息日期加v_cou年
               select add_months(in_vdate,v_cou*12) into v_vdate1 from dual;  
               select add_months(in_vdate,(v_cou+1)*12) into v_vdate2 from dual; 
               --如果【付息开始日】在区间{【起息日】+i,【起息日】+i+1}年内，则返回true              
               IF in_pay_date_begin >= v_vdate1 AND in_pay_date_begin < v_vdate2 THEN
                 --返回天数
                 select v_vdate2-v_vdate1 into v_return_days from dual; 
                 exit;               
               END IF;                  
               v_cou := v_cou +1;
             end loop;
           --如果【推算方式】=【起息日向前】
           ELSIF in_cal_method = '02' THEN 
             loop
               --将起息日期减v_cou年
               select add_months(in_vdate,-(v_cou+1)*12) into v_vdate1 from dual;  
               select add_months(in_vdate,-v_cou*12) into v_vdate2 from dual; 
               --如果【付息开始日】在区间{【起息日】+i,【起息日】+i+1}年内，则返回true              
               IF in_pay_date_begin >= v_vdate1 AND in_pay_date_begin < v_vdate2 THEN
                 --返回天数
                 select v_vdate2-v_vdate1 into v_return_days from dual; 
                 exit;               
               END IF;                  
               v_cou := v_cou +1;
             end loop;
           --如果【推算方式】=【首次支付日】
           ELSIF in_cal_method = '03'  THEN
             loop
               --将起息日期减v_cou年
               select add_months(in_first_pay_date,v_cou*12) into v_first_pay_date1 from dual;  
               select add_months(in_first_pay_date,(v_cou+1)*12) into v_first_pay_date2 from dual; 
               --如果【付息开始日】在区间{【起息日】+i,【起息日】+i+1}年内，则返回true              
               IF in_pay_date_begin >= v_first_pay_date1 AND in_pay_date_begin < v_first_pay_date2 THEN
                 --返回天数
                 select v_first_pay_date2-v_first_pay_date1 into v_return_days from dual; 
                 exit;               
               END IF;                  
               v_cou := v_cou +1;
             end loop;              
                   
           END IF;
        END IF;  
 
    --如果【计息基础】=A/365  
    ELSIF in_basis ='A/365' THEN 
      v_return_days := 365;
     --如果【计息基础】=A/360 或 【计息基础】=30/360
    ELSIF in_basis ='A/360' OR in_cal_method ='30/360' THEN 
      v_return_days := 360;
    ELSE  
      v_return_days := 365;   

    END IF;  

  END IF;
  

  --将计算天数赋给返回值
  out_days := v_return_days;
EXCEPTION
	WHEN OTHERS THEN
    ROLLBACK;

    DBMS_OUTPUT.put_line('this error message is from procedure P_FLOW_STRESS_TEST.');
    DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
    DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
                                                
end CALC_INT_BASIS_DAYS;
/

