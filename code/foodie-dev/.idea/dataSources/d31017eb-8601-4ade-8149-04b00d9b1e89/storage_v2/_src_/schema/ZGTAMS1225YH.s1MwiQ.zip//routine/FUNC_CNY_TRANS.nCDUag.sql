create FUNCTION FUNC_CNY_TRANS(in_asserts_mount  IN NUMBER,
                                          in_asserts_ccy    IN VARCHAR2,
                                          in_stat_date      IN DATE)
/******************************************************************************
  * AUTHOR         -  Jiaoxujin
  * CREATION DATE  -  2019-09-20
  * SERVICE NAME   -  兆尹科技-资管事业部
  *
  * PROCEDURE NAME :FUNC_CNY_TRANS
  *
  * DESCRIPTION    :将某币种的金额按当时汇率折算成人民币的金额
  *
  * Parameters :
  *  in_asserts_mount           IN  资产价值（资产总额）
  *  in_asserts_ccy             IN  资产币种（外币币种）
  *  in_stat_date               IN  资产价值统计日期
  ******************************************************************************
  * POSSIBLE ERROR CONDITIONS :
  ******************************************************************************
  * CHANGE LOG
  ******************************************************************************
  * CHANGE NUMBER:
  * DATE:
  * DEVELOPER:
  * DESCRIPTION:
  *****************************************************************************/
  RETURN NUMBER AS

  v_max_deviation       INTEGER := 140; --偏离资产价值统计日期的最大允许天数
  v_result              NUMBER(30,14) := 0;
  v_unit                NUMBER(10) := 0;
  v_price               NUMBER(30,14);

  CURSOR c_qp IS
    with t1 as (
        select m.quot_unit, NVL(m.close_price, m.open_price) as price,
               row_number() over (order by trunc(in_stat_date) - m.trade_date) as rowno
          from mst_excharge_quote m
               --若找不到资产价值统计日期的数据，可以往前几天再找一找
         where trunc(in_stat_date) - m.trade_date between 0 and v_max_deviation
           and m.basis_cyy  = in_asserts_ccy
           and m.quot_cyy = 'CNY'
    )
    select quot_unit, price from t1
     where t1.rowno = 1;

   CURSOR c_qp2 IS
    with t1 as (
        select m.quot_unit, NVL(m.close_price, m.open_price) as price,
               row_number() over (order by trunc(in_stat_date) - m.trade_date) as rowno
          from mst_excharge_quote m
         where trunc(in_stat_date) - m.trade_date between 0 and v_max_deviation
           and m.basis_cyy  = 'CNY'
           and m.quot_cyy = in_asserts_ccy
    )
    select quot_unit, price from t1
     where t1.rowno = 1;

BEGIN
    --=mount / quot_unit * close_price
    FOR r_qp IN c_qp LOOP
      EXIT WHEN c_qp%NOTFOUND;
      v_unit := r_qp.quot_unit;
      v_price := r_qp.price;
      EXIT;
    END LOOP;

    IF v_unit IS NULL OR v_unit = 0 THEN
        FOR r_qp IN c_qp2 LOOP
          EXIT WHEN c_qp2%NOTFOUND;
          v_unit := r_qp.quot_unit;
          v_price := r_qp.price;
          EXIT;
        END LOOP;

        IF v_unit > 0 AND v_price > 0 THEN
            --=mount * quot_unit / close_price
            v_result := in_asserts_mount * v_unit / v_price;
        ELSE
            --都没找到怎么办？不转换了，原值返回。
            --DBMS_OUTPUT.put_line('Warning: There are nothing matched exchange rate data in the talbe[MST_EXCHARGE_QUOTE].');
            v_result := in_asserts_mount;
        END IF;

    --如果v_unit>0，那么price一定存在
    ELSE
        v_result := in_asserts_mount / v_unit * v_price;
    END IF;

    RETURN v_result;
EXCEPTION
  WHEN OTHERS THEN
     DBMS_OUTPUT.put_line('this error message is from function FUNC_CNY_TRANS.');
     DBMS_OUTPUT.put_line ('SQLCODE: ' || SQLCODE);
     DBMS_OUTPUT.put_line ('SQLERRM: ' || SQLERRM);
     RETURN null;
END;
/

