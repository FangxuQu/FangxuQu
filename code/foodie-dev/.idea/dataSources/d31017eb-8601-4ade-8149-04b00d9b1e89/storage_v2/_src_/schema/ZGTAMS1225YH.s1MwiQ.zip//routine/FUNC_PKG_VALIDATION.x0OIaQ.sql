create FUNCTION FUNC_PKG_VALIDATION RETURN NUMBER AS
--AUTHOR         -  Jiaoxujin
--CREATION DATE  -  2019-11-07
--SERVICE NAME   -  兆尹科技-资管事业部
--PROJECT NAME   -  邮储压力测试
--DESCRIPTION    -  Spring datasource validationQuery 验证package的时效性
--                  当重新编译下方调用的任一package后，该函数有可能返回null
--                  好像只有被引用（被另一个package调用的package）package重新编译后，该函数在旧的连接session中才返回null

  v_expect_count    INTEGER := 4;  --预期值，有几个package，这就是几。
  v_valid_pkg_count INTEGER := 0;  --验证通过的package数
  v_default_date    DATE := SYSDATE - 1;
BEGIN

  IF PKG_FLOW_STRESS_TEST.FUNC_PKG_VALIDATION > v_default_date THEN
    v_valid_pkg_count := v_valid_pkg_count + 1;
  END IF;

  IF PKG_MR_STRESS_TEST.FUNC_PKG_VALIDATION > v_default_date THEN
    v_valid_pkg_count := v_valid_pkg_count + 1;
  END IF;

  IF PKG_STRESS_TEST_COMM.FUNC_PKG_VALIDATION > v_default_date THEN
    v_valid_pkg_count := v_valid_pkg_count + 1;
  END IF;
  
  IF PKG_LOG.FUNC_PKG_VALIDATION > v_default_date THEN
    v_valid_pkg_count := v_valid_pkg_count + 1;
  END IF;

  IF v_expect_count = v_valid_pkg_count THEN
    RETURN v_valid_pkg_count;
  END IF;

  RETURN NULL;

  EXCEPTION
    WHEN OTHERS THEN
       RETURN null;
END;
/

