create FUNCTION "FUN_GETVAL" (prodId IN varchar2,valdate IN date) RETURN NUMBER

AS

v_valuation number(30,14);

BEGIN

  select valuation into  v_valuation from (select rownum, t.valuation  from (SELECT fpv.valuation FROM FIN_PRODUCT_VALUATION fpv
         where fpv.val_date <= valdate and fpv.finprod_id = prodId order by val_date desc)t
  WHERE rownum =1);

RETURN v_valuation ;

END fun_getVal;


/

