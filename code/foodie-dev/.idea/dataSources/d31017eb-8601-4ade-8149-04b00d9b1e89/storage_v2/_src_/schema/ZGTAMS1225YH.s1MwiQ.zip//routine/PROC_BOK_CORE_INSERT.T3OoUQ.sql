create PROCEDURE "PROC_BOK_CORE_INSERT" (BOOKDATE    IN VARCHAR2,
                                                   O_ERROR     OUT INT,
                                                   O_ERRORINFO OUT VARCHAR2) IS
  V_BOOKDATE VARCHAR2(50);
  V_COUNT    INT;
BEGIN

  V_BOOKDATE := BOOKDATE;

  SELECT COUNT(*)
    INTO V_COUNT
    FROM BOK_CORE T
   WHERE T.ACCOUNTDATE = TO_DATE(V_BOOKDATE, 'yyyy-mm-dd')
     AND T.SUCCESS = '1';
  /* 判断当天记账数据核心系统是否已接收 */
  IF V_COUNT = 0 THEN
    /* 删除当天核心记账数据 */
    DELETE FROM BOK_CORE T
     WHERE T.ACCOUNTDATE = TO_DATE(V_BOOKDATE, 'yyyy-mm-dd')
       AND T.SUCCESS IS NULL
       AND T.CORESEQNO IS NULL;
    COMMIT;
    /* 插入 */
    INSERT INTO BOK_CORE
      (SEQNO,
       XH,
       ACCOUNTDATE,
       ACCOUNTNOD,
       ACCOUNTNOC,
       CNY,
       AMOUNT,
       SEQ,
       PRODSERIESNO,
       PRODSERIESNAME,
       CRDRFG,
       TYPE)
      SELECT BOK_CORE_SEQ.NEXTVAL, T.*
        FROM (SELECT RANK() OVER(ORDER BY PRODSERIESNO, ORDERNO, ACCOUNTNOD, ACCOUNTNOC) XH,
                     T.ACCOUNTDATE,
                     T.ACCOUNTNOD,
                     T.ACCOUNTNOC,
                     T.CNY,
                     T.AMOUNT,
                     RANK() OVER(PARTITION BY PRODSERIESNO ORDER BY PRODSERIESNO, ORDERNO, ACCOUNTNOD, ACCOUNTNOC) SEQ,
                     T.PRODSERIESNO,
                     T.PRODSERIESNAME,
                     T.CRDRFG,
                     T.TYPE
                FROM (SELECT Z.ACCOUNTDATE,
                             DECODE(Z.CRDRFG,
                                    'D',
                                    Z.SUBJECT,
                                    'C',
                                    DECODE(Z.PRODSERIESNO,
                                           '1',
                                           'su',
                                           '9010000239990009')) ACCOUNTNOD,
                             DECODE(Z.CRDRFG,
                                    'D',
                                    DECODE(Z.PRODSERIESNO,
                                           '1',
                                           'su',
                                           '9010000239990009'),
                                    'C',
                                    Z.SUBJECT) ACCOUNTNOC,
                             'CNY' CNY,
                             DECODE(Z.CRDRFG,
                                    'D',
                                    SUM(NVL(Z.DAMOUNT, 0)),
                                    'C',
                                    SUM(NVL(Z.CAMOUNT, 0))) AMOUNT,
                             Z.PRODSERIESNO,
                             DECODE(Z.PRODSERIESNO,
                                    '1',
                                    '非保本',
                                    '2',
                                    '个人保本',
                                    '3',
                                    '单位保本',
                                    '4',
                                    '同业保本',
                                    '5',
                                    '非银保本') PRODSERIESNAME,
                             Z.CRDRFG,
                             DECODE(Z.PRODSERIESNO, '1', 1, 0) TYPE,
                             Z.ORDERNO
                        FROM (SELECT K.BOOK_DATE ACCOUNTDATE,
                                     D.SUBJECT_NO SUBJECT,
                                     D.VOUCH_NUM PSEQNO,
                                     case
                                       when d.cd_flag = 'D' THEN
                                        D.HAPPEN_AMT
                                       ELSE
                                        0
                                     END DAMOUNT,
                                     case
                                       when d.cd_flag = 'C' THEN
                                        D.HAPPEN_AMT
                                       ELSE
                                        0
                                     END CAMOUNT,
                                     /* 获取产品类型（1:非保本   2:个人保本  3:单位保本  4:同业保本  5:非银保本）*/
                                     CASE
                                       WHEN FPA.PROFIT_FLAG = '03' THEN
                                        1
                                       ELSE
                                        CASE
                                          WHEN PFP.TARGET_CUSTOMER_1 = '01' THEN
                                           2
                                          WHEN PFP.TARGET_CUSTOMER_1 = '02' THEN
                                           3
                                          WHEN PFP.TARGET_CUSTOMER_1 = '03' THEN
                                           CASE
                                             WHEN PFP.TARGET_CUSTOMER_2 = '04' THEN
                                              4
                                             ELSE
                                              5
                                           END
                                        END
                                     END PRODSERIESNO,

                                     D.CD_FLAG CRDRFG,
                                     CASE
                                       WHEN D.CD_FLAG = S.BAL_FLAG THEN
                                        0
                                       ELSE
                                        1
                                     END ORDERNO
                                FROM BAN_BOK_VOUCH_DETAIL D
                                LEFT JOIN BAN_BOK_VOUCH_MAIN K
                                  ON K.VOUCH_NUM = D.VOUCH_NUM
                                LEFT JOIN FIN_PRODUCT FP
                                  ON FP.FINPROD_ID = K.BOOKSET_ID
                                LEFT JOIN FIN_PRODUCT_ADD FPA
                                  ON FPA.FINPROD_ID = FP.FINPROD_ID
                                LEFT JOIN PA_FIN_PRODUCT PFP
                                  ON PFP.FINPROD_ID = FP.FINPROD_ID
                                LEFT JOIN BAN_BOK_SUBJECT S
                                  ON S.SUBJECT_NO = D.SUBJECT_NO
                               WHERE D.HAPPEN_DATE = TO_DATE(V_BOOKDATE, 'yyyy-mm-dd')) Z
                      /*排除凭证借贷不平明细（除非保本）*/
                       WHERE (SELECT SUM(DECODE(S.CD_FLAG, 'D', 1, 'C', -1) *
                                         S.HAPPEN_AMT)
                                FROM BAN_BOK_VOUCH_DETAIL S
                               WHERE S.VOUCH_NUM = Z.PSEQNO) = 0
                          or Z.PRODSERIESNO = '1'
                       GROUP BY Z.ACCOUNTDATE,
                                Z.PRODSERIESNO,
                                Z.SUBJECT,
                                Z.CRDRFG,
                                Z.ORDERNO) T
               WHERE T.AMOUNT <> 0
               ORDER BY PRODSERIESNO, ORDERNO) T;

    COMMIT;
    O_ERROR := 0;
  ELSE
    O_ERROR     := 1;
    O_ERRORINFO := V_BOOKDATE || ' 记账数据核心系统已接收！请勿重复发送！';
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    O_ERROR     := 1;
    O_ERRORINFO := SUBSTR(SQLERRM, 0, 200);

END PROC_BOK_CORE_INSERT;


/

