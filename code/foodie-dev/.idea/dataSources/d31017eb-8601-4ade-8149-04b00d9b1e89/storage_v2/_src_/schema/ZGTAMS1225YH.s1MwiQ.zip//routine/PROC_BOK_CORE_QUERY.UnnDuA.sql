create PROCEDURE "PROC_BOK_CORE_QUERY" (BOOKDATE IN VARCHAR2,
                                                TYP      IN VARCHAR2,
                                                O_CURSOR OUT SYS_REFCURSOR) IS
  V_BOOKDATE VARCHAR2(50);
  V_TYPE     VARCHAR2(10);
BEGIN

  V_BOOKDATE := BOOKDATE;
  V_TYPE     := TYP;

  OPEN O_CURSOR FOR
    SELECT LPAD(XH, 6, '0') XH,
           TO_CHAR(ACCOUNTDATE, 'yyyymmdd') ACCOUNTDATE,
           LPAD(ACCOUNTNOD, 20, ' ') ACCOUNTNOD,
           LPAD(ACCOUNTNOC, 20, ' ') ACCOUNTNOC,
           CNY,
           DECODE(INSTR(AMOUNT, '-'), 1, '-', 0) ||
           LPAD(REPLACE(REPLACE(TRIM(TO_CHAR(AMOUNT, '99999999999999.99')),
                                '.',
                                ''),
                        '-',
                        ''),
                17,
                '0') AMOUNT,
           LPAD(SEQ, 8, '0') SEQ,
           LPAD(PRODSERIESNO, 8, ' ') PRODSERIESNO
      FROM BOK_CORE C
     WHERE C.ACCOUNTDATE = TO_DATE(V_BOOKDATE, 'yyyy-mm-dd')
       AND C.TYPE = V_TYPE
     order by to_number(XH);

END PROC_BOK_CORE_QUERY;


/

