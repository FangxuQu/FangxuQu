create view VAL_VW_USERDEPT as
SELECT
    A.USER_NAME                          AS USER_NAME,
    A.REAL_NAME                          AS REAL_NAME,
    A.DEPT_CODE                          AS DEPT_INSTITUTION_CODE,
    NVL(B.DEPT_NAME, C.INSTITUTION_NAME) AS DEPT_INSTITUTION_NAME
FROM
    sys_user A
LEFT JOIN
    sys_department B
ON
    A.DEPT_CODE = B.DEPT_CODE
LEFT JOIN
    sys_institution C
ON
    A.DEPT_CODE = C.INSTITUTION_CODE
/

