create view VIEW_FIN_PRODUCT_RATING_BREACH as
SELECT
    mbcr.o_code              AS ocode,
    mbcr.o_type              AS otype,
    mbcr.o_type AS o_type1,
    NULL AS o_type2,
    NULL AS odistype,
    '01' AS innerouter,
    mbcr.grade_org_id        AS gradeorgid,
    mbcr.grade_date          AS gradedate,
    mbcr.notice_date AS noticedate,
    mbcr.short_long_term     AS shortlongterm,
    mbcr.grade_result        AS mstratingresult01,
    mrm.grade_result_st      AS mstratingresult02,
    mbcr.input_type          AS inputtype,
    mbcr.grade_expectation   AS gradeexpectation,
    mbcr.direction_change    AS directionchange,
    mbcr.issuer_rate_type    AS issuerratetype
FROM
    mst_bond_credit_rating   mbcr
    LEFT JOIN mst_rating_match         mrm ON mbcr.grade_result = mrm.grade_result_or
UNION ALL
SELECT
    micr.o_code            AS ocode,
    micr.o_type            AS otype,
    NULL AS o_type1,
    micr.o_type AS o_type2,
    NULL AS odistype,
    '02' AS innerouter,
    micr.grade_org_id      AS gradeorgid,
    micr.grade_date        AS gradedate,
    NULL AS noticedate,
    NULL AS shortlongterm,
    micr.grade_result      AS mstratingresult01,
    mrm1.grade_result_st   AS mstratingresult02,
    micr.input_type        AS inputtype,
    NULL AS gradeexpectation,
    NULL AS directionchange,
    NULL AS issuerratetype
FROM
    mst_inner_credit_rating   micr
    LEFT JOIN mst_rating_match          mrm1 ON micr.grade_result = mrm1.grade_result_or
/

