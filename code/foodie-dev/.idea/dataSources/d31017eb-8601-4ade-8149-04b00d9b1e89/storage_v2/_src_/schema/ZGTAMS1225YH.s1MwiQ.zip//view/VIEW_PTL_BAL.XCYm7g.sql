create view VIEW_PTL_BAL as
select   psp.cdate              ,/*持仓日期  查询用*/
         psp.finprod_id         ,/*组合持有金融产品代码*/

         pfp.target_customer_1  customertype,/*目标客户一级分类 查询用*/
         fpa.profit_flag        profitFlag,/*收益标识 查询用*/
         nvl((select 'Y'  from pa_trd_product_deal padeal,   trd_product_deal deal,trd_product_deal_add dealadd
          where padeal.trade_id= deal.trade_id and dealadd.trade_id=deal.trade_id and   trade_date<=psp.cdate and deal.finprod_id=ast.finprod_id
          and dealadd.portfolio_id=psp.portfolio_id  and padeal.is_Break='Y' and rownum=1)     ,'N')   isBreak,/*是否违约 */
         ast.trustee_id         hostingbank,/*托管行 标的 查询用*/

         decode(ast.finprod_type2,
                       'F01',
                       '债券',
                       'F02',
                       '正回购',
                       'F04',
                       '正回购',
                       'F03',
                       '逆回购',
                       'F05',
                       '逆回购',
                       'F06',
                       '基金',
                       'F07',
                       '现金',
                       'F22',
                       '现金',
                       'F17',
                       '计划',
                       'F18',
                       '项目',
                       'F15',
                       '衍生品',
                       'F08','拆入',
                       'F25','拆入',
                       'F09','拆出'
         )      assetsType      ,/*资产类型*/
         ast.finprod_type2      assetsTypeCode,/*资产类型代码*/
         ast.finprod_market_id  assetsCode, /*组合持有的资产代码 -- 回购为交易编号*/
         decode(ast.finprod_type2,'F01',ast.finprod_abbr,ast.finprod_name )      assetsName,/*组合持有的资产名称 */

         decode(ast.finprod_type2,'F01',ast.type_5)             bondType, /*债券类型*/
         ast.grade              bondcreditlv, /*债券评级*/
         null       bondDuration, /*债券久期*/
         null       bondRemainingLife, /*债券剩余期限*/

         (case when ast.finprod_type2='F17' and ast.profit_type='02'
                 then ast.yield
                 else ast.rate
                   end)         ticketRate,/*资产票面利率*/
         ast.vdate              assetsVdate, /*资产起息日*/
         ast.mdate              assetsMdate, /*资产到期日*/

         /*资产总额*/
         /*成本总额*/
         /*加权资产利率  利用票面*/

         psp.portfolio_id       portfolioId, /*组合代码*/
         pp.portfolio_name      portfolioName, /*组合名称*/
         pp.vdate               portfolioVdate, /*组合开始日*/
         pp.mdate               portfolioMdate, /*组合结束日*/


         fp2.profit_type        profitType, /*产品收益类型*/
         fri.rate               expectProfitRate, /*产品预期收益率*/

         tpd.trade_id           ,/*交易编号*/
         (case when ast.finprod_type2 = 'F01' then psp.amount*100
               when ast.finprod_type2 in ('F02','F03','F04','F05') then fdp.pledge_number*100
               when ast.finprod_type2 in ('F17','F06') and ast.profit_type=('01') then psp.amount* nvl(fun_getval(ast.finprod_market_id,psp.cdate),1)
                 else psp.amount end) cfgAssets, /*组合持有的资产金额 */
         (SELECT
             sum(case when tpd.finprod_type2 = 'F01' then decode(tpd.ps,
                                                        'T01',nvl(tpd.fprice_amt,0),
                                                        'T02',-1*nvl(tpd.fprice_amt,0),
                                                        'T23',-1*nvl(tpd.prin_amt,0),
                                                        'T03',-1*nvl(tpd.fprice_amt,0),
                                                        'T39',-1*nvl(tpd.fprice_amt,0),0)
                     when tpd.finprod_type2 in('F02','F03','F04','F05') then decode(tpd.ps,
                                                                                    'T01',nvl(tpd.prin_amt,0),
                                                                                    'T07',-1*nvl(tpd.prin_amt,0),0)
                     when tpd.finprod_type2 = 'F06' then decode(tpd.ps,
                                                                'T01',nvl(tpd.trade_amt,0),
                                                                'T02',-1*nvl(tpd.trade_amt,0),
                                                                'T04',nvl(tpd.trade_amt,0),
                                                                'T19',-1*nvl(tpd.trade_amt,0),
                                                                'T11',-1*nvl(tpd.trade_amt,0),
                                                                'T12',nvl(tpd.share_amt,0),
                                                                0)

                     when tpd.finprod_type2 in ('F07','F22') then decode(tpd.ps,
                                                                         'T01',nvl(tpd.trade_amt,0),
                                                                         'T02',-1*nvl(tpd.trade_amt,0),
                                                                         'T38',-1*nvl(tpd.prin_amt,0),0)
                     when tpd.finprod_type2 = 'F15' then 0
                     when tpd.finprod_type2 = 'F17' and ast.profit_type in('01','03')  then decode(tpd.ps,
                                                                                            'T01',nvl(tpd.trade_amt,0),
                                                                                            'T02',-1*nvl(tpd.trade_amt,0),
                                                                                            'T04',nvl(tpd.trade_amt,0),
                                                                                            'T19',-1*nvl(tpd.trade_amt,0),
                                                                                            'T11',-1*nvl(tpd.trade_amt,0),
                                                                                            'T12',nvl(tpd.share_amt,0),0)
                     when tpd.finprod_type2 = 'F17' and ast.profit_type ='02'  then decode(tpd.ps,
                                                                'T01',nvl(tpd.trade_amt,0),
                                                                'T02',-1*nvl(tpd.trade_amt,0),0)
                     when tpd.finprod_type2 = 'F18' then decode(tpd.ps,
                                                                'T01',nvl(tpd.trade_amt,0),
                                                                'T02',-1*nvl(tpd.trade_amt,0),
                                                                'T23',-1*nvl(tpd.prin_amt,0),0)
                     when tpd.finprod_type2 in ('F08','F25') then decode(tpd.ps,
                                                                'T01',nvl(tpd.prin_amt,0),
                                                                'T23',-1*nvl(tpd.prin_amt,0),0)
                     when tpd.finprod_type2 = 'F09' then decode(tpd.ps,
                                                                'T01',nvl(tpd.prin_amt,0),
                                                                'T23',-1*nvl(tpd.prin_amt,0),0)
                     else 0
                       end)
          FROM trd_product_deal tpd
          left join trd_product_deal_add tpda
               on tpd.trade_id=tpda.trade_id
          where tpd.trade_date <= psp.cdate
                and tpda.portfolio_id=psp.portfolio_id
                and tpd.finprod_id=psp.finprod_id
                and tpd.trade_status='01'
                and tpd.is_cancel='N')          as cfgCost,/*配置成本*/

        decode(ast.finprod_type2,'F07',pcp.amount,'F22',pcp.amount)             remainingcash/*剩余现金 组合余额*/

    from PTL_SEC_POSITION psp /*组合持仓信息*/
    --回购质押品金额
    LEFT JOIN (SELECT fdp1.finprod_id,sum(fdp1.pledge_number) pledge_number FROM  fin_deal_pledge fdp1 group by fdp1.finprod_id) fdp
      on psp.finprod_id=fdp.finprod_id
    --组合信息
    left join PTL_PORTFOLIO pp
      on psp.portfolio_id = pp.portfolio_id

      --剩余信息
    left join

    (select pcp1.portfolio_id,pcp1.cdate,pcp1.hoding_type,sum(pcp1.amount) amount
      from PTL_CASH_POSITION pcp1
     where pcp1.hoding_type='03'
     group by pcp1.portfolio_id,pcp1.cdate,pcp1.hoding_type
    ) pcp
      on psp.portfolio_id=pcp.portfolio_id
      and psp.cdate=pcp.cdate

   --组合产品要素信息
  LEFT JOIN Fin_Product_Add fpa
    on psp.portfolio_id = fpa.portfolio_id
  LEFT JOIN fin_product fp2
    on fp2.finprod_id = fpa.finprod_id
  left join FIN_CASH_INFO fci
    on fp2.finprod_id = fci.finprod_id
    and fci.branch = '0'
    and fci.cash_type_2 = 'C02' /*利息*/
  left join FIN_RATE_INFO fri
    on fci.cash_id = fri.cash_id
    and fri.Eff_Date = fp2.vdate
  left join pa_fin_product pfp
    on fp2.finprod_id=pfp.finprod_id

    --资产信息
    left join (select fp.finprod_type2,
                      fp.finprod_id,

                      fp.profit_type,
                      fp.trustee_id,
                      fp.finprod_market_id, /*资产代码*/
                      fri.rate, /*资产预期收益率  票面利率*/

                      fccr.yield,
                      fp.vdate, /*资产起息日*/
                      fp.mdate, /*资产到期日*/
                      fp.finprod_name, /*资产名称*/
                      fp.finprod_abbr,/*资产简称*/
                      fpt.type_5, /*资产一级分类*/
                      (select max(mbcr.grade_result)
                         from MST_BOND_CREDIT_RATING mbcr
                        where mbcr.o_code = fp.finprod_id) grade /*债券评级*/
                 from fin_product fp
                 --现金流
                 left join FIN_CASH_INFO fci
                   on fp.finprod_id = fci.finprod_id
                  and fci.branch = '0'
                  and fci.cash_type_2 = 'C02' /*利息*/
                 --利率信息
                 left join FIN_RATE_INFO fri
                   on fci.cash_id = fri.cash_id
                  and fri.Eff_Date = fp.vdate

                 left join FIN_CASH_CALC_RULE fccr
                  on fci.cash_id=fccr.cash_id
                --产品类型
                 left join FIN_PRODUCT_TYPE fpt
                   on fp.finprod_id = fpt.finprod_id
                 --债券信用
                 --left join MST_BOND_CREDIT_RATING mbcr
                   --on fp.finprod_id = mbcr.o_code

                 where fp.finprod_type2<>'F16'
               union all

               select ftp.finprod_type2,

                      ftp.finprod_id,

                      ftp.profit_type,
                      ftpa.regist_org trustee_id,
                      ftp.finprod_id      finprod_market_id, /*资产代码*/
                      ftp.int_rate   rate,           /*资产预期收益率*/

                      fccr.yield,
                      ftp.vdate, /*资产起息日*/
                      ftp.mdate, /*资产到期日*/
                      ftp.finprod_id      finprod_name, /*资产名称*/
                      ftp.finprod_id      finprod_abbr,/*资产简称*/
                      fpt.type_5, /*资产一级分类*/
                      (select max(mbcr.grade_result)
                         from MST_BOND_CREDIT_RATING mbcr
                        where mbcr.o_code = ftp.finprod_id) grade /*债券评级*/
                 from fin_trade_product ftp
                 left join fin_trade_product_add ftpa
                   on ftp.finprod_id=ftpa.finprod_id
                 --现金流
                 left join FIN_CASH_INFO fci
                   on ftp.finprod_id = fci.finprod_id
                  and fci.branch = '0'
                  and fci.cash_type_2 = 'C02' /*利息*/
                 --利率信息
                 left join FIN_RATE_INFO fri
                   on fci.cash_id = fri.cash_id
                  and fri.Eff_Date = ftp.vdate
                 left join FIN_CASH_CALC_RULE fccr
                  on fci.cash_id=fccr.cash_id
                --产品类型
                 left join FIN_PRODUCT_TYPE fpt
                   on ftp.finprod_id = fpt.finprod_id
                 --债券信用
                 --left join MST_BOND_CREDIT_RATING mbcr
                   --on ftp.finprod_id = mbcr.o_code
                   where ftp.finprod_type2 in ('F01','F02','F03','F04','F05','F06','F07','F15','F17','F18','F08','F09','F22','F25')
                   ) ast
      on psp.finprod_id = ast.finprod_id

    --交易
    left join (select t1.finprod_id,
                      t1.trade_id,
                      t1.trade_date

               from trd_product_deal t1
               left join trd_product_deal_add t2
                 on t1.trade_id=t2.trade_id
                 where t1.trade_status='01'and t1.is_cancel='N' and t1.finprod_type2 in('F02','F03','F04','F05')
                 ) tpd
      on psp.finprod_id=tpd.finprod_id and tpd.trade_date <= psp.cdate
     where ast.finprod_type2 in('F01','F02','F03','F04','F05','F06','F07','F15','F17','F18','F08','F09','F22','F25') and( psp.hoding_type='03' or psp.hoding_type='02' )
           and psp.amount<>0 and psp.amount is not null
union


select
       pt.cdate                      ,/*持仓日期  查询用*/
       null as                       finprod_id,/*组合持有金融产品代码*/

       pt.target_customer_1          customertype,/*目标客户一级分类 查询用*/
       pt.profit_flag                profitFlag,/*收益标识 查询用*/
       'N' as                       isBreak,/*是否违约 */

       pt.trustee_id                 hostingbank,/*托管行 标的 查询用*/
       '现金' as                     assetsType,/*资产类型*/
       null as                       assetsTypeCode,/*资产类型代码*/
       '活期存款' as                 assetsCode, /*组合持有的资产代码 -- 回购为交易编号*/
       null as                       assetsName,/*组合持有的资产名称 */

       null as                       bondType, /*债券类型*/
       null as                       bondcreditlv, /*债券评级*/
       null as                       bondDuration, /*债券久期*/
       null as                       bondRemainingLife, /*债券剩余期限*/

       null as                       ,/*资产票面利率*/
       null as                       assetsVdate, /*资产起息日*/
       null as                       assetsMdate, /*资产到期日*/


       pt.portfolio_id              portfolioId, /*组合代码*/
       pt.portfolio_name             portfolioName, /*组合名称*/
       pt.vdate                      portfolioVdate, /*组合开始日*/
       pt.mdate                      portfolioMdate, /*组合结束日*/

       pt.profit_type               profitType, /*产品收益类型*/
       pt.rate                      expectProfitRate, /*产品预期收益率*/

       null as                      trade_id,/*交易编号*/
       pt.amount                   , /*配置资产   此处为剩余 */
       null as                      cfgCost,/*配置成本*/
       null as                      remainingcash/*剩余现金 组合余额*/


        from (
            SELECT  pcp.cdate,
                    fpa.profit_flag,
                    pfp.target_customer_1,
                    ast.finprod_market_id,

                    ast.finprod_type2,
                    rpd.rep_investor_type,
                    ast.trustee_id,


                    pcp.portfolio_id ,
                    pp.portfolio_name ,
                    pp.vdate ,
                    pp.mdate ,
                    fp.profit_type ,
                    fri.rate rate,
                    pcp.amount

              FROM ptl_cash_position pcp
              LEFT JOIN ptl_portfolio pp
              on pcp.portfolio_id=pp.portfolio_id

              LEFT JOIN Fin_Product_Add fpa
              on pcp.portfolio_id = fpa.portfolio_id
              LEFT JOIN fin_product fp
              on fp.finprod_id = fpa.finprod_id
              and fp.finprod_type2 = 'F16'
              left join pa_fin_product pfp
              on fp.finprod_id=pfp.finprod_id
              left join FIN_CASH_INFO fci
              on fp.finprod_id = fci.finprod_id
              and fci.branch = '0'
              and fci.cash_type_2 = 'C02' /*利息*/
              left join FIN_RATE_INFO fri
              on fci.cash_id = fri.cash_id
              and fri.Eff_Date = fp.vdate


              left join rep_prod_declare rpd
              on fp.finprod_id = rpd.rep_finprod_id

              left join (select fp.finprod_type2,
                                fp.finprod_id,

                                fp.trustee_id,
                                fp.finprod_market_id /*资产代码*/

                          from fin_product fp

                          union all

                          select ftp.finprod_type2,
                                 ftp.finprod_id,

                                 ftpa.regist_org trustee_id,
                                 ftp.finprod_id finprod_market_id /*资产代码*/


                          from fin_trade_product ftp
                          left join fin_trade_product_add ftpa
                          on ftp.finprod_id=ftpa.finprod_id
              ) ast
              on fp.finprod_id = ast.finprod_id and ast.finprod_type2<>'F16'
              where pcp.hoding_type='03' or  pcp.hoding_type='02'
        ) pt
        where  pt.amount <>0
/

